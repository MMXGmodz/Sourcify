package com.metrolist.music.utils

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext

class CanvasVideoStore(context: Context) {
    private val context = context.applicationContext
    internal val preferences = this.context.getSharedPreferences("sourcify_canvas", Context.MODE_PRIVATE)

    fun get(songId: String): Uri? = preferences.getString(songId, null)
        ?.let(Uri::parse)
        ?.takeIf { it.scheme == "content" }

    fun set(songId: String, uri: Uri) {
        require(songId.isNotBlank() && uri.scheme == "content")
        val resolver = context.contentResolver
        val mimeType = resolver.getType(uri)
        require(mimeType == null || mimeType.startsWith("video/"))
        resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val previous = get(songId)
        preferences.edit().putString(songId, uri.toString()).apply()
        if (previous != null && previous != uri) releaseIfUnused(previous)
    }

    fun remove(songId: String) {
        val previous = get(songId)
        preferences.edit().remove(songId).apply()
        previous?.let(::releaseIfUnused)
    }

    private fun releaseIfUnused(uri: Uri) {
        if (preferences.all.values.none { it == uri.toString() }) {
            runCatching {
                context.contentResolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
    }
}

@Composable
fun rememberCanvasVideoUri(songId: String?): Uri? {
    val context = LocalContext.current
    val store = remember(context) { CanvasVideoStore(context) }
    var uri by remember(store, songId) { mutableStateOf(songId?.let(store::get)) }
    DisposableEffect(store, songId) {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == songId) uri = songId?.let(store::get)
        }
        store.preferences.registerOnSharedPreferenceChangeListener(listener)
        onDispose { store.preferences.unregisterOnSharedPreferenceChangeListener(listener) }
    }
    return uri
}
