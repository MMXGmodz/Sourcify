# Projektstatus

Stand: 29. Oktober 2026.

| Bereich | Status dieses Quellcodes |
| --- | --- |
| Android-App | Build und automatisierte Tests vorhanden; Gerätetest der aktuellen Änderungen ausstehend |
| Canvas / Player / Lyrics | Implementiert; aktuelle Android-Änderungen im Changelog |
| Künstlerinfos / Empfehlungen / Credits | Implementiert; abhängig von verfügbaren YouTube-Music-Daten |
| Android-Downloads und Cache | Vorhandene Implementierung weiterverwendet |
| Google-basierter Sourcify-Cloud-Account | In diesem Snapshot kein betriebenes gemeinsames Backend enthalten |
| Geräteübergreifender Sourcify-Cloud-Sync | Nicht als fertig ausgewiesen |
| Windows | In diesem Arbeitsstand kein entsprechender Quellcode oder geprüfter Build vorhanden |
| PS5 / etaHEN / ShadowMount | In diesem Arbeitsstand kein entsprechender Quellcode oder geprüfter Build vorhanden |
| PS5-Hintergrundwiedergabe im Spiel | Nicht implementiert oder auf Hardware bestätigt in diesem Snapshot |

Basis ist der vom Besitzer freigegebene neueste Android-UI-Quellcode. Der früher erwähnte stabile Quellcode vom 8. Oktober wurde nicht wiedergefunden. Spätere, damals separat entwickelte Podcast-/Hörbuch-/Plattform-Funktionen dürfen deshalb nicht allein aus früheren Chat-Berichten als enthalten gelten.

Vorabversionen enthalten eine APK, den passenden Quellcode, Prüfsummen und einen Build-Bericht. Es werden keine Firmware- oder Gerätekompatibilitäten behauptet, die nicht getestet wurden.
