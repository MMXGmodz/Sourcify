#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cache="$root/.deps/ps5-native-app"
mkdir -p "$cache"
archive="$cache/ps5-opengl-sdk-1.0.0.tar.gz"
prefix="$cache/ps5-opengl-sdk-1.0.0/sdk"
if [[ ! -f "$prefix/manifest.sha256" ]]; then
    curl -fL --retry 3 -o "$archive.part" https://github.com/blackbearreloaded/ps5-opengl/releases/download/v1.0.0/ps5-opengl-sdk-1.0.0.tar.gz
    printf '%s  %s\n' f93643c04c843d56143b00951df1f8042ea7706ae9f19e4e9abf158e1ead77c5 "$archive.part" | sha256sum --check --strict
    mv -- "$archive.part" "$archive"
    tar -xzf "$archive" -C "$cache"
fi
(cd "$prefix" && sha256sum --check --strict --quiet manifest.sha256)
printf '%s  %s\n' f4b91f672be037fbac3f82494f1225deaf4c227a03f37ac3ffa56abb213b943f "$prefix/manifest.sha256" | sha256sum --check --strict
checkout="$cache/MkPFS"
revision=6cb8313dfe0c988ac52617794553f343243d3a56
if [[ ! -d "$checkout/.git" ]]; then
    mkdir -p "$checkout"
    git -C "$checkout" init -q
    git -C "$checkout" remote add origin https://github.com/PSBrew/MkPFS.git
    git -C "$checkout" fetch -q --depth 1 origin "$revision"
    git -C "$checkout" checkout -q --detach FETCH_HEAD
fi
[[ $(git -C "$checkout" rev-parse HEAD) == "$revision" ]] || { echo 'MkPFS revision mismatch' >&2; exit 1; }
git -C "$checkout" diff --quiet || { echo 'MkPFS cache modified' >&2; exit 1; }
[[ -x "$checkout/.venv/bin/python" ]] || python3 -m venv "$checkout/.venv"
"$checkout/.venv/bin/python" -m pip install --quiet -r "$root/platforms/ps5/native_app/requirements-mkpfs.txt"
"$checkout/.venv/bin/python" -m pip install --quiet --no-deps "$checkout"
printf '\nDependencies ready. In this shell run:\nexport PS5_OPENGL_PREFIX=%q\nexport MKPFS=%q\n' "$prefix" "$checkout/.venv/bin/mkpfs"
