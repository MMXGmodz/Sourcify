#pragma once
#include "json.hpp"
#include <string>
#include <vector>
#include <map>
#include <random>

namespace sourcify {
using Json=nlohmann::json;
bool valid_id(const std::string& id);
std::string file_key(const std::string& id);
Json parse_json(const std::string& text,size_t limit=4*1024*1024);
struct Track {
    std::string id,title,artist,album,thumbnail,kind;
    double duration=0;
    Json json() const;
    static Track parse(const Json& j);
};
struct Settings {
    float volume=.75f;
    int repeat=0,buffer_ms=2000,notification_seconds=3,cache_mb=512;
    bool shuffle=false,resume=true,notifications=false,logging=true,debug_overlay=false,api_debug=false,ipc_debug=false;
    std::string start_page="Home",language="de",source="native",bridge,token,ca_file,download_dir;
    Json json(bool secrets=false) const;
    void apply(const Json& j);
};
struct Library {
    std::map<std::string,Track> tracks;
    std::vector<std::string> queue,favorites,recent,results;
    std::map<std::string,std::vector<std::string>> playlists;
    int index=-1;
    double position=0;
    std::string active_playlist;
    Settings settings;
    void add(const Track& track);
    void play(const std::string& id);
    bool next(int direction,bool ended=false);
    void remove(size_t at);
    void move(size_t from,size_t to);
    void favorite(const std::string& id);
    void playlist(const std::string& name,const std::string& id,bool remove=false);
    Json json(bool secrets=false) const;
    void restore(const Json& j);
    std::string current() const;
private:
    std::mt19937 random{std::random_device{}()};
};
}
