#include "model.hpp"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace sourcify {
bool valid_id(const std::string& id) {
    if(id.size()==11)return std::all_of(id.begin(),id.end(),[](unsigned char c){return std::isalnum(c)||c=='_'||c=='-';});
    if(id.size()!=42||id.substr(0,6)!="local:")return false;
    for(size_t i=6;i<42;i++)if(i==14||i==19||i==24||i==29){if(id[i]!='-')return false;}else if(!std::isxdigit(static_cast<unsigned char>(id[i])))return false;
    return true;
}
std::string file_key(const std::string& id){if(!valid_id(id))throw std::runtime_error("Invalid track ID");auto key=id;std::replace(key.begin(),key.end(),':','_');return key;}
Json parse_json(const std::string& text,size_t limit) {
    if(text.size()>limit)throw std::runtime_error("Response too large");
    return Json::parse(text,[](int depth,Json::parse_event_t,Json&){if(depth>32)throw std::runtime_error("JSON nesting limit");return true;});
}
static std::string str(const Json& j,const char* key,size_t max=300) {
    if(!j.contains(key))return "";
    if(!j[key].is_string()||j[key].get_ref<const std::string&>().size()>max)throw std::runtime_error("Invalid text field");
    const auto s=j[key].get<std::string>();if(s.find('\0')!=std::string::npos)throw std::runtime_error("Invalid text");return s;
}
static double number(const Json& j,const char* key,double fallback,double low,double high) {
    if(!j.contains(key))return fallback;if(!j[key].is_number())throw std::runtime_error("Invalid number");auto n=j[key].get<double>();if(!std::isfinite(n)||n<low||n>high)throw std::runtime_error("Number out of range");return n;
}
Track Track::parse(const Json& j) {
    if(!j.is_object())throw std::runtime_error("Invalid metadata");Track t;t.id=str(j,"id",42);if(!valid_id(t.id))throw std::runtime_error("Invalid track ID");
    t.title=str(j,"title");t.artist=str(j,"artist",200);t.album=str(j,"album",200);t.thumbnail=str(j,"thumbnail",2048);t.kind=str(j,"kind",20);t.duration=number(j,"duration",0,0,86400);return t;
}
Json Track::json() const{return {{"id",id},{"title",title},{"artist",artist},{"album",album},{"thumbnail",thumbnail},{"kind",kind},{"duration",duration}};}
Json Settings::json(bool secrets) const {
    Json j={{"volume",volume},{"repeat",repeat},{"shuffle",shuffle},{"buffer_ms",buffer_ms},{"resume",resume},{"notifications",notifications},{"notification_seconds",notification_seconds},{"logging",logging},{"cache_mb",cache_mb},{"start_page",start_page},{"language",language},{"bridge",bridge},{"download_dir",download_dir}};
    j["source"]=source;j["debug_overlay"]=debug_overlay;j["api_debug"]=api_debug;j["ipc_debug"]=ipc_debug;
    if(secrets){j["token"]=token;j["ca_file"]=ca_file;}return j;
}
void Settings::apply(const Json& j) {
    if(!j.is_object())throw std::runtime_error("Invalid settings");
    Settings s=*this;
    s.volume=static_cast<float>(number(j,"volume",volume,0,1));s.repeat=static_cast<int>(number(j,"repeat",repeat,0,2));s.buffer_ms=static_cast<int>(number(j,"buffer_ms",buffer_ms,250,10000));
    s.notification_seconds=static_cast<int>(number(j,"notification_seconds",notification_seconds,1,5));s.cache_mb=static_cast<int>(number(j,"cache_mb",cache_mb,16,8192));
    for(auto key:{"repeat","buffer_ms","notification_seconds","cache_mb"})if(j.contains(key)&&!j[key].is_number_integer())throw std::runtime_error("Integer setting required");
    for(auto key:{"shuffle","resume","notifications","logging","debug_overlay","api_debug","ipc_debug"})if(j.contains(key)&&!j[key].is_boolean())throw std::runtime_error("Invalid setting");
    s.shuffle=j.value("shuffle",shuffle);s.resume=j.value("resume",resume);s.notifications=j.value("notifications",notifications);s.logging=j.value("logging",logging);
    s.debug_overlay=j.value("debug_overlay",debug_overlay);s.api_debug=j.value("api_debug",api_debug);s.ipc_debug=j.value("ipc_debug",ipc_debug);
    if(j.contains("source")){s.source=str(j,"source",20);if(s.source!="native"&&s.source!="companion")throw std::runtime_error("Invalid music source");}
    if(j.contains("language")){s.language=str(j,"language",2);if(s.language!="de"&&s.language!="en")throw std::runtime_error("Invalid language");}
    if(j.contains("start_page")){s.start_page=str(j,"start_page",20);if(s.start_page!="Home"&&s.start_page!="Library"&&s.start_page!="Now Playing"&&s.start_page!="Settings")throw std::runtime_error("Invalid start page");}
    for(auto key:{"bridge","token","ca_file","download_dir"})if(j.contains(key)){auto v=str(j,key,2048);if(key==std::string("bridge"))s.bridge=v;else if(key==std::string("token")){if(!v.empty()&&(v.size()!=64||!std::all_of(v.begin(),v.end(),[](char c){return std::isxdigit(static_cast<unsigned char>(c));})))throw std::runtime_error("Invalid token");s.token=v;}else if(key==std::string("ca_file"))s.ca_file=v;else s.download_dir=v;}
    *this=s;
}
void Library::add(const Track& t){if(!valid_id(t.id))throw std::runtime_error("Invalid ID");if(tracks.size()>=5000&&!tracks.count(t.id))throw std::runtime_error("Library full");tracks[t.id]=t;}
std::string Library::current() const{return index>=0&&index<static_cast<int>(queue.size())?queue[index]:"";}
void Library::play(const std::string& id){if(!tracks.count(id))throw std::runtime_error("Track not found");auto it=std::find(queue.begin(),queue.end(),id);if(it==queue.end()){if(queue.size()>=500)throw std::runtime_error("Queue full");queue.push_back(id);index=static_cast<int>(queue.size()-1);}else index=static_cast<int>(it-queue.begin());position=0;recent.erase(std::remove(recent.begin(),recent.end(),id),recent.end());recent.insert(recent.begin(),id);if(recent.size()>50)recent.resize(50);}
bool Library::next(int direction,bool ended){
    if(queue.empty())return false;if(ended&&settings.repeat==1){position=0;return true;}
    int next=index+direction;
    if(settings.shuffle&&direction>0&&queue.size()>1){std::uniform_int_distribution<int> d(0,static_cast<int>(queue.size()-2));next=d(random);if(next>=index)next++;}
    if(next>=static_cast<int>(queue.size())){if(settings.repeat!=2)return false;next=0;}
    if(next<0)next=settings.repeat==2?static_cast<int>(queue.size()-1):0;
    index=next;position=0;const auto id=current();recent.erase(std::remove(recent.begin(),recent.end(),id),recent.end());recent.insert(recent.begin(),id);if(recent.size()>50)recent.resize(50);return true;
}
void Library::remove(size_t at){if(at>=queue.size())throw std::runtime_error("Invalid queue index");queue.erase(queue.begin()+at);if(static_cast<int>(at)<index)index--;if(index>=static_cast<int>(queue.size()))index=static_cast<int>(queue.size()-1);}
void Library::move(size_t from,size_t to){if(from>=queue.size()||to>=queue.size())throw std::runtime_error("Invalid queue index");auto id=queue[from];queue.erase(queue.begin()+from);queue.insert(queue.begin()+to,id);if(index==static_cast<int>(from))index=static_cast<int>(to);else if(static_cast<int>(from)<index&&static_cast<int>(to)>=index)index--;else if(static_cast<int>(from)>index&&static_cast<int>(to)<=index)index++;}
void Library::favorite(const std::string& id){if(!tracks.count(id))throw std::runtime_error("Track not found");auto it=std::find(favorites.begin(),favorites.end(),id);if(it==favorites.end())favorites.insert(favorites.begin(),id);else favorites.erase(it);}
void Library::playlist(const std::string& name,const std::string& id,bool remove){if(name.empty()||name.size()>80||name.find('\0')!=std::string::npos)throw std::runtime_error("Invalid playlist name");if(!tracks.count(id))throw std::runtime_error("Track not found");if(playlists.size()>=100&&!playlists.count(name))throw std::runtime_error("Playlist limit");auto& ids=playlists[name];auto it=std::find(ids.begin(),ids.end(),id);if(remove){if(it!=ids.end())ids.erase(it);}else if(it==ids.end()){if(ids.size()>=500)throw std::runtime_error("Playlist full");ids.push_back(id);}}
Json Library::json(bool secrets) const{Json t=Json::object();for(const auto& [id,track]:tracks)t[id]=track.json();return {{"schema",1},{"tracks",t},{"queue",queue},{"index",index},{"position",position},{"favorites",favorites},{"recent",recent},{"results",results},{"playlists",playlists},{"active_playlist",active_playlist},{"settings",settings.json(secrets)}};}
void Library::restore(const Json& j){
    if(!j.is_object()||j.value("schema",0)!=1)throw std::runtime_error("Unsupported state schema");Library l;
    auto saved=j.value("settings",Json::object());if(saved.is_object()&&!saved.contains("source")&&saved.contains("bridge")&&saved["bridge"].is_string()&&!saved["bridge"].get<std::string>().empty())saved["source"]="companion";l.settings.apply(saved);const auto& t=j.at("tracks");if(!t.is_object()||t.size()>5000)throw std::runtime_error("Invalid library");for(const auto& item:t.items()){auto track=Track::parse(item.value());if(track.id!=item.key())throw std::runtime_error("Metadata ID mismatch");l.add(track);}
    auto ids=[&](const Json& list,size_t limit){if(!list.is_array()||list.size()>limit)throw std::runtime_error("Invalid ID list");std::vector<std::string> out;for(const auto& x:list){if(!x.is_string())throw std::runtime_error("Invalid ID");auto id=x.get<std::string>();if(l.tracks.count(id))out.push_back(id);}return out;};
    l.queue=ids(j.value("queue",Json::array()),500);l.favorites=ids(j.value("favorites",Json::array()),5000);l.recent=ids(j.value("recent",Json::array()),50);
    l.index=j.value("index",-1);if(l.index<0||l.index>=static_cast<int>(l.queue.size()))l.index=l.queue.empty()?-1:0;l.position=number(j,"position",0,0,86400);
    const auto p=j.value("playlists",Json::object());if(!p.is_object()||p.size()>100)throw std::runtime_error("Invalid playlists");for(const auto& item:p.items()){if(item.key().empty()||item.key().size()>80)throw std::runtime_error("Invalid playlist");l.playlists[item.key()]=ids(item.value(),500);}l.active_playlist=str(j,"active_playlist",80);
    *this=std::move(l);
}
}
