# Sourcify Player für PS5 – Entwicklungsbuild 0.01

**Aktuelle Oberfläche: native ShadowMount-App `PPSA99051` mit `eboot.bin`.**
Installation, App-Build, Sandbox-Pfade und aktueller Teststatus stehen in
[PS5-ShadowMount.md](PS5-ShadowMount.md). Ein grün markiertes Payload ist kein
App-Start. Die älteren ELF-/Plugin-Builds in den folgenden Kapiteln sind
Service-/Entwicklungsreferenzen; für den aktuellen Vordergrund-App-Test bitte
das neue ShadowMount-Paket verwenden.

Suche, Stream-Auflösung einschließlich `s`-/`n`-Signaturen, Cover und Downloads
laufen jetzt standardmäßig vollständig auf der PS5. **Kein PC-Begleitserver,
Node.js, Python oder externes Sourcify-Backend ist für den Betrieb nötig.**
Internet zu YouTube ist zum Suchen/Streamen erforderlich; Downloads laufen offline.

Die zusätzliche Plattform ist unter `platforms/ps5` implementiert. Die App,
der separate Playback-Service und das dünne Control-Plugin wurden mit der
öffentlichen PS5-Toolchain kompiliert. **Dieser Build wurde nicht auf einer PS5
getestet und hat die Hardware-Abnahme noch nicht bestanden.** Keine Firmware
oder etaHEN-Version wird derzeit als hardwaregestützt unterstützt bezeichnet.

## Analyse des bestehenden Projekts

Sourcify hat drei getrennte Projekte und bisher keinen gemeinsamen C++-Core:

| Bereich | Android (`sourcify-player`) | Desktop (`sourcify-windows`) |
|---|---|---|
| Sprache / UI | Kotlin, Compose, Material 3 | JavaScript, Electron, HTML/CSS |
| Build | Gradle, AGP, JDK 21 | npm, electron-builder, NSIS |
| Audio | Media3/ExoPlayer, Android AudioTrack | HTMLAudio, Electron-Medienprotokoll |
| Suche / Streams | InnerTube/InnerTubeX, Ktor/OkHttp | yt-dlp über `runEngine`, geprüfte HTTPS-Googlevideo-URLs |
| Account | YouTube-Cookies/SAPISID in Android-Einstellungen | kein eigener OAuth-/Account-Login |
| Bibliothek / Favoriten | Room | atomare JSON-Datei über `src/core.cjs: Store` |
| Playlists | lokale und YouTube-Playlists | Queue; bisher keine eigene Playlist-Datenbank |
| Queue / Verlauf | Media3, persistierte Queue | Store-IDs/Index, Shuffle/Repeat, 50 Verlaufseinträge |
| Downloads / Cache | Media3 DownloadManager und Cache | yt-dlp-Dateien, ablaufende Stream-URLs |
| Metadaten / Cover | InnerTube-Modelle, Coil | `cleanTrack`, HTTPS-Thumbnails |
| Gemeinsam hören | lokaler HTTP-Server, Online-Protobuf/WebSocket | lokaler HTTP-Server |

Der Go-Server `sourcify-online-server` ist ein Jam-Relay, kein Musik-Backend.
Die Dateistruktur steht in `PS5-source-inventory.txt`. Direkt wiederverwendet:
Desktop-Engine, Track-Normalisierung, Store, Range-Parser, URL-Prüfung, eigene
Sourcify-Grafiken und Lizenzen. `src/music-api.cjs` enthält die zuvor in
`main.cjs` liegenden Musik-Requests und wird jetzt von Desktop und PS5-
Begleitserver gemeinsam verwendet. `cleanTrack` erhält Album/Artist-Metadaten.
Android wurde für diesen Port nicht geändert. Windows-Version und Einstieg
bleiben unverändert; die realen Electron-Regressionstests bestanden.

Compose/Room/ExoPlayer und Electron/HTMLAudio sind keine PS5-Bibliotheken.
Deshalb gibt es einen kleinen nativen C++-Core für Queue, Bibliothek,
Playlists, Metadaten und Settings, mit austauschbaren Plattformkomponenten.

## Belegte Schnittstellen und Architektur

Verwendete öffentliche Quellen:

- [ps5-payload-sdk v0.43](https://github.com/ps5-payload-dev/sdk/releases/tag/v0.43),
  Release-Commit `d9c9519116944a7f1c22d262012c53b80b3520b7`: ELF-Payloads,
  FreeBSD/POSIX, dynamische PS5-Systembibliotheken, C++-Runtime.
- [pacbrew-repo v0.40.2](https://github.com/ps5-payload-dev/pacbrew-repo/releases/tag/v0.40.2),
  `1687e827675c66e1b040751c7f0811222bd3aea0`: PS5-Bibliotheken/Build-Rezepte.
- [PS5-SDL 2.30.12](https://github.com/ps5-payload-dev/SDL/tree/a47182a20e741e4735d1fcd41e8656bf338b0c72):
  Video-/Pad-/Audio-Backend; Pad verwendet echte `scePadReadState`-Aufrufe,
  Audio `sceAudioOutOpen` am MAIN-Port mit 48 kHz, Stereo S16.
- [etaHEN 2.5B](https://github.com/etaHEN/etaHEN/tree/dafa13b562ddb137a4b4a97b9aaa287c0c57cc9c)
  und [etaHEN-Plugins](https://github.com/etaHEN/etaHEN-Plugins/tree/6339554e4e3c92c0a655a37194c1152d6b82ad88):
  Daemon-Plugins, echter `etaHEN_PLUGIN`-Header und öffentliches
  `sceNotificationSend`-Beispiel. Der ältere LightningMods/etaHEN-SDK-Link
  war nicht verfügbar. Es werden keine erfundenen Plugin-Callbacks verwendet.

`app` → versioniertes lokales IPC → `Service` → FFmpeg/PCM-Ringpuffer/SDL-Audio.
Ohne externen Service bettet die App denselben Service als Fallback ein.
`etahen_plugin/control.cpp` enthält ausschließlich State-/Control-IPC und
optionale System-Benachrichtigungen, keinen Decoder und keine große UI.
Die Service-/Control-Plugins verwenden wie das öffentliche Beispiel
`kernel_sys`; die Frontend-ELF verwendet den normalen SDK-Payload-Link.

Die native Quelle adaptiert die tatsächlich im Android-Projekt verwendeten
InnerTubeX-Requests und Renderer-Modelle. `network/youtube.cpp` spricht
YouTube Music direkt per HTTPS an (WEB_REMIX-Suche, VISIONOS-/ANDROID_VR-
Playerprofile aus der vorhandenen Abhängigkeit). Metadaten und Googlevideo-
Audio werden direkt geladen. Künstler/Alben gruppieren lokale Suchmetadaten.

`network/cipher.cpp` bettet die echte QuickJS-C-Engine und denselben EJS-Solver
wie InnerTubeX ein. Signaturen (`s`) und Throttling-Parameter (`n`) werden lokal
berechnet. Der tatsächliche Player-Script-Pfad wird aus der YouTube-Watch-Seite
ermittelt; keine erfundenen PS5-/etaHEN-APIs, kein Remote-Resolver. Die Umgebung
enthält die aus InnerTubeX übernommenen minimalen DOM-/Intl-Adapter. Sie ersetzt
keinen Browser und stellt keine Datei-/Netzwerk-/OS-JavaScript-Bindings bereit.
192 MiB JS-Speicherbudget, 512 KiB Stack, 15 Sekunden Interrupt-Limit und
Abbruch bei Trackwechsel/Shutdown. Playercode und signierte URLs bleiben im
Speicher; Medien werden nicht über JavaScript decodiert.

Die vorhandene Desktop-Engine bleibt als ausdrücklich wählbare **optionale**
Quelle (`source: "companion"`) kompatibel. Alte Konfigurationen mit gesetzter
PC-Adresse behalten dieses Verhalten. Nach Update in Einstellungen → Musikquelle
„YouTube direkt“ auswählen; neue Installationen nutzen es automatisch.
Das native Downloadpaket enthält keinen PC-Server und keine yt-dlp-Binaries.
Die optionalen Brückensourcen bleiben im Source-ZIP, getrennt vom PS5-Laufzeitpfad.

**Live-YouTube und PS5-Hardware sind hier nicht erfolgreich geprüft worden.**
Der Live-Versuch scheiterte bereits am Netzwerkproxy dieser Build-Umgebung
mit HTTP 403 beim HTTPS-Tunnel. Die Tests verwenden eindeutig bezeichnete
HTTPS-Upstream-Fixtures und echte native Requests/Decoder/QuickJS-Codepfade.
Öffentliche anonyme Tracks sind implementiert; YouTube kann Clientprofile,
Playercode, PO-Token-Anforderungen oder regionale Regeln ändern. Verlangte
Anmeldung/Verifizierung, private/bezahlte/gesperrte Titel, SABR und Live-HLS
werden nicht umgangen. Kein nativer YouTube-Account-Login oder PO-Token-Generator.

## Voraussetzungen und reproduzierbarer Build der früheren ELF-/Service-Version

Linux x86_64 oder WSL2; Bash, GNU Make, pkg-config, Python **3.12+**, LLVM/Clang
18 oder 19 einschließlich LLD und llvm-config. Diese Werkzeuge werden nur
zum Kompilieren benötigt. Die PS5 braucht sie nicht. Kein proprietäres Sony-SDK
erforderlich. QuickJS/EJS werden aus dem beigelegten Quellcode/Assets gebaut.

Beispiel unter Debian/Ubuntu mit den entsprechenden Paketen:

```sh
sudo apt install make pkg-config python3 clang-19 lld-19 llvm-19-dev
python3 platforms/ps5/setup_sdk.py --destination "$HOME/sourcify-ps5-sdk"
export PS5_PAYLOAD_SDK="$HOME/sourcify-ps5-sdk"
export LLVM_CONFIG=llvm-config-19
./build_ps5.sh release
./build_ps5.sh debug
```

Python muss `tarfile`-Extraktion mit `filter='data'` unterstützen. Der Installer
lädt feste SDK-/Bibliotheksversionen, prüft SHA-256 und überschreibt keinen
bereits gefüllten Zielordner. Für Installation/Cache/temporäre Extraktion etwa
3 GB freien Platz einplanen. Offline sind dieselben geprüften Archive mit
`--cache VERZEICHNIS` verwendbar. Die beiden gepinnten Hashes stehen im Script.
SDK-Wrapper nutzen `LLVM_CONFIG`; bei fehlendem Compiler, C++-Runtime oder
Bibliotheken bricht das Build-Script mit Fehler ab.

Outputs:

```text
build/ps5/release/Sourcify-PS5-release.zip
build/ps5/debug/Sourcify-PS5-debug.zip
build/ps5/{release,debug}/sourcify.elf
build/ps5/{release,debug}/sourcify-service.plugin
build/ps5/{release,debug}/sourcify-control.plugin
build/ps5/{release,debug}/sourcify-ctl.elf
```

DEBUG: `-O0 -g`, zusätzliche Input-Diagnose. RELEASE: `-O2 -DNDEBUG`, Debug-
Informationen entfernt; optionale Kategorien bleiben gezielt einschaltbar.
`build_ps5.bat release` startet den Build in WSL mit bereits gesetztem SDK
und LLVM_CONFIG. Der Batch-/WSL-Einstieg wurde hier nicht auf Windows getestet.

Das frühere Payload-Paket ist **ein ELF-/Homebrew-Bundle, keine Retail-PKG und kein eboot.bin**.
Das öffentliche SDK verlangt dafür kein erfundenes `param.json` oder Sony-
Packaging. Ein eigener ELF-Loader muss auf deiner Konsole bereits funktionieren.
`homebrew.js` nutzt das öffentliche Launcher-Schema von ps5-payload-websrv.

## Früherer ELF-Startweg (durch die native App ersetzt)

Dieser Payload-Startweg wird für die Oberfläche nicht mehr empfohlen: Ein
geladener ELF besitzt nicht automatisch den nötigen Grafik-/App-Kontext.
Die folgenden alten Pfade erklären die separaten Service-Builds.

1. Release-ZIP entpacken. `app/` einschließlich `assets/` nach
   `/data/sourcify/app` kopieren. Unter diesem Standardpfad kann auch ein
   Loader ohne Argument-Unterstützung Assets finden.
2. `app/sourcify.elf` mit deinem vorhandenen ELF-Loader starten. Alternativ
   den ganzen App-Ordner in ps5-payload-websrv aufnehmen und `homebrew.js`
   verwenden. Loader und Assets nicht nur als einzelne ELF übertragen.
3. Mit Internet verbundene PS5 verwenden: LAN, WLAN oder ein Smartphone-
   Hotspot mit mobilen Daten funktionieren gleichermaßen auf Netzwerkebene.
   Die App verlangt kein gemeinsames WLAN mit einem anderen Gerät.
4. Suche öffnen, mit X Titel/Künstler eingeben, Suchergebnis mit X abspielen.
   Quadrat favorisiert, Dreieck fügt zur Queue hinzu. Options → Download
   speichert den gewählten Song auf der Konsole. Kein PC-Kopplungscode nötig.
5. Bei früherer Installation Einstellungen → Musikquelle → „YouTube direkt“.
   Favoriten/Playlists bleiben in der vorhandenen lokalen Datenbank erhalten.
6. Eigene Musik optional nach `imports/` kopieren und unter Einstellungen
   „Importierte Audiodateien einlesen“ wählen. Geprüfte Downloads und Importe
   lassen sich ohne Internet abspielen.

### HTTPS und optionale alte PC-Quelle

Native API/Player/Script/Cover/Media-Endpunkte sind per HTTPS und Rollen-
Allowlist eingeschränkt. Zertifikatskette **und** Hostname werden geprüft,
Mozilla-CA-Bundle ist beigelegt; keine TLS-Abschaltung oder HTTPS-Downgrades.
Keine Redirects zu beliebigen Hosts. API-Antwortgrößen, IDs und Verschachtelung
werden begrenzt. Verbindungs-/Operationstimeouts und höchstens drei Versuche.

Nur falls ausdrücklich gewünscht: aus dem Source-Paket
`platforms/ps5/bridge/start_companion.bat` bzw. `.sh` mit Node.js 24 LTS starten,
Musikquelle „Optionaler Begleitserver“ wählen, private PC-Adresse eintragen,
einmaligen achtstelligen Code aus der Serverkonsole eingeben. Private IPv4-
HTTP ist für das vertrauenswürdige LAN zugelassen; andere Netze verlangen
korrekt konfiguriertes HTTPS. `--tls-key`/`--tls-cert` und optional `--cookies`
bleiben kompatibel. Native YouTube-Quelle verwendet weder Server noch Cookies.
Keine automatische Übernahme von YouTube-Account-Playlists oder Accounts.

## etaHEN-Service und Control-Plugin

Optional und auf Hardware ungetestet:

1. Die App mit Einstellungen → Beenden schließen, sodass ihr eingebetteter
   Service und Audio-Port beendet werden.
2. `plugins/sourcify-service.plugin` und `sourcify-control.plugin` nach
   `/data/etaHEN/plugins` kopieren; SDK dokumentiert außerdem
   `/mnt/usbN/etaHEN/plugins` als Plugin-Suchpfad.
3. In etaHEN Toolbox erst Service (`SOUR00001`, 0.01), dann Control
   (`SOUR00002`, 0.01) starten. **Für den ersten Test kein Autostart** konfigurieren.
4. Sourcify-App erneut öffnen. Sie verbindet sich über `playback.sock` zum
   bereits laufenden Service und öffnet keinen zweiten Audio-Port.
5. Nach dem Test Plugins über die Toolbox stoppen. Service und App müssen
   denselben Datenpfad nutzen; Assets liegen unter `DATENPFAD/app/assets`.

Plugin-Paketheader entspricht exakt dem öffentlichen SDK-Schema:
`etaHEN_PLUGIN\0` + Title-ID + `\0` + Version + `\0` + ELF.
Feature Detection fragt das echte `control.sock`/`PLUGIN_STATUS` ab.
`etaHEN_files` bedeutet nur vorhandene etaHEN-Konfigurationsdatei, keine
Firmware-/Runtime-Kompatibilitätsbestätigung.

**Background-Audio ist experimentell.** Ein Daemon kann von der UI unabhängig
laufen; ob der MAIN-Audio-Port beim Spielstart erhalten bleibt oder korrekt
mit Spielton mischt, ist nicht durch öffentliche SDK-Quellen garantiert.
Deshalb meldet `background_playback` stets `false`, bis Hardwaretests und
gegebenenfalls ein verifizierter Audio-Adapter vorliegen.

Für das originale Control Center gibt es in den untersuchten Quellen keine
stabile öffentliche Musik-Erweiterung. etaHEN-interne Overlay-Hooks sind kein
allgemeiner Plugin-Overlay-Vertrag. **In-Game-Overlay und globaler Shortcut
sind nicht implementiert/verfügbar.** Keine Offsets, Spiel-Injection oder
scheinbar funktionierenden Aktivierungsschalter. Ein eigenes Quick Menu
funktioniert innerhalb der App über Options. Zukünftige verifizierte Adapter
gehören nach `overlay/`, `input/` und `compat/`; diese Capability-Grenze bleibt
isoliert. Ein Overlay-/IPC-Verbindungsverlust verhindert nicht die normale App.

## Controller, TV-UI und Funktionsstatus

Die UI arbeitet mit logischer 1920×1080-Fläche und skaliert zur verfügbaren
Ausgabe. Native 4K-Ausgabe hängt vom SDL/VideoOut-Backend und Hardware ab.
Große Schrift/Zeilen, sichtbarer Fokus, eigene navy/cyan Sourcify-Grafiken,
Deutsch/Englisch und Controller-Tastatur; keine Maus-/Touch-Pflicht.

| Eingabe | Aktion |
|---|---|
| D-Pad / linker Stick | Fokus und Listen/Tastatur navigieren |
| Cross / X | bestätigen, ausgewählten Song starten |
| Circle | zurück / Menü oder Tastatur schließen |
| Square | Favorit umschalten |
| Triangle | Warteschlange öffnen |
| L1 / R1 | Seiten wechseln |
| L2 / R2 | zehn Sekunden zurück / vor |
| Options | eigenes Quick Menu öffnen/schließen |

Quick Menu: Play/Pause, Previous/Next, Lautstärke, Shuffle/Repeat,
Queue-Aktionen, Download/Löschen und Playlist-Aktionen, passend zur Auswahl.
Queue-Einträge werden über ihren Index verschoben/entfernt, damit doppelte
Songs korrekt behandelt werden. Suchtext, URL, Code und Playlistname können
mit der eigenen Controller-Tastatur eingegeben werden. Host-Tastatur ist
zusätzlicher Test-/Entwicklereingang, keine Voraussetzung auf PS5.

| Funktion | Implementierung / Nachweis |
|---|---|
| Start/Home/TV-UI | native SDL-App, Host-Renderer getestet, PS5-Start offen |
| Controller | alle geforderten Buttons/Achsen gemappt und synthetisch getestet; DualSense-Hardware offen |
| Suche / Songlisten | direktes InnerTube-HTTPS, Parser aus bestehendem Android-Code adaptiert, native HTTPS-Fixtures geprüft; Live/Hardware offen |
| Künstler / Alben | Gruppierung der Bibliotheks-/Tag-Metadaten, kein kompletter YouTube-Music-Katalogbrowser |
| Bibliothek / Favoriten / Verlauf | persistierter nativer Core, Tests bestanden |
| Playlists | lokale PS5-Playlists erstellen, hinzufügen/entfernen/löschen/abspielen; keine Account-Synchronisation |
| Queue / Shuffle / Repeat | implementiert und getestet; 500 Queue-Einträge, auch Duplikate |
| Cover / Now Playing | asynchrone echte Downloads, begrenzter Bilddecoder/Cache, Host-Screenshots |
| Audio / Pause / Seek / Volume | FFmpeg + realer SDL-Callback; Host mit Dummy-Ausgabe geprüft, hörbarer PS5-Ton offen |
| Offline / Downloads | Range-Fortsetzung, Formatprüfung, SHA-256, Metadaten, Größe/Löschen; Host geprüft |
| Settings / Neustart | atomar gespeichert, automatisches Resume mit Position/Queue/Playlist geprüft |
| Playback-Service / IPC | unabhängige Prozesse auf Host getestet, PS5-Daemon-Start offen |
| Thin Control-Plugin | echte State-/Play/Pause/Next/Previous-Weiterleitung auf Host; etaHEN-Hardware offen |
| Song Notifications | eigener In-App-Toast 1–5 s; optional echte PS5-System-API, deren Dauer bestimmt das OS; Hardware offen |
| In-App Quick Menu | implementiert; Controller-Abnahme offen |
| In-Game-Overlay / globaler Shortcut | nicht verfügbar mangels verifiziertem Adapter |
| Musik während Spielen | unbestätigt, Capability deaktiviert; erst nach Hardware-Test fertig |
| Gapless / Canvas / PS5-Jam / Sleep-Wake | nicht implementiert bzw. nicht hardwaregeprüft; keine Attrappen |

## Audio, Netzwerk und Fehlerbehandlung

FFmpeg 7 decodiert MP3, AAC/M4A, FLAC, WAV, Ogg/Opus und WebM entsprechend den
vorhandenen Demuxern. Stream-Transport nutzt libcurl über eigenes AVIO:
FFmpeg 7s OpenSSL-`tls_verify` allein prüft nicht zuverlässig den Servernamen.
Der native Transport prüft deshalb beides außerhalb FFmpeg. Endliche Medien
mit Content-Length und HTTP-Range werden unterstützt, maximal 512 MiB pro
Datei. Keine HLS-/Live-/unendlichen Streams in diesem Transport.

Stereo 48 kHz/S16, bounded PCM-Ringpuffer, Callback ohne Heap-Allocations,
separater Decoderthread, API-/Cover-/Download-Worker mit begrenzten Queues.
Audio-Puffer einstellbar 250–10000 ms (maximal etwa 1,92 MB PCM).
Timeouts, höchstens drei Transportversuche, Seek-Cancellation und saubere
Worker-Beendigung. Der Download erfolgt einzeln, mit Abbrechen/Fortsetzen.
Fehlende Cover haben ein eigenes Markenbild. Netzwerk-/Decode-Fehler werden
als wiederherstellbare Meldung angezeigt, Decoder kann einen anderen Song
starten. Trackwechsel bricht eine laufende native Stream-Auflösung ab; Pause
während der Auflösung bleibt beim Start erhalten.

Teil-Downloads bleiben erhalten. Range-Start und Dateigröße werden geprüft;
volle Dateien bekommen SHA-256 und Metadaten. Wenn sich der entfernte Track
ändert oder eine bereits vollständige `.part` einen 416-Response erhält,
Teil-Datei löschen und neu laden. Bei nativen Downloads wird die Identität
(id/itag/Länge/lastModified) separat geprüft; passt sie nicht, startet der
Download neu statt inkompatible Audioblöcke anzuhängen. Importdateien werden nicht nach Downloads
kopiert und können auf dem Dateisystem verwaltet werden. Cover-Cache-Limit
begrenzt Cover; es ist keine automatische Quote für bewusst gespeicherte
Offline-Musik. UI zeigt den Download-Speicherverbrauch.

## Datenpfade, Settings, Resume und Logging

Beim Start wird Schreibbarkeit geprüft: explizit `--data PFAD` oder
`SOURCIFY_DATA`; sonst auf PS5 `/data/sourcify`, dann `/mnt/usb0/sourcify`,
`/mnt/usb1/sourcify`. Wenn kein Pfad schreibbar ist, eindeutiger Startfehler.
Keine pauschale Annahme, dass `/data` in jeder Umgebung verfügbar ist.
Assets mit `--assets PFAD` angeben, sonst `DATENPFAD/app/assets` auf PS5.
Bei USB-/anderen Roots für beide Plugins identisches `SOURCIFY_DATA` über
Loader/Launcher-Umgebung setzen. Kann dein Plugin-Loader keine Umgebung
setzen, zunächst den Standardpfad verwenden oder einen getrennt getesteten
Launcher ergänzen.

```text
DATENPFAD/
  app/assets/               Font, Markenbild, CA-Bundle
  cache/covers/             Cover und Teil-Dateien
  cache/audio/              für austauschbaren Cache-Adapter reserviert
  cache/metadata/           Download-/Track-Metadaten
  config/state.json         Queue, Index, Position, Playlists, Settings/Token
  config/client.json        optionale Erstkonfiguration
  downloads/                verifizierte Audio- und Teil-Dateien
  imports/                  eigene MP3/M4A/AAC/FLAC/WAV/OGG/OPUS/WebM
  logs/sourcify.log          kategorisierte Logs
  playback.sock             lokales Service-IPC
  control.sock              dünnes Plugin-IPC
```

`client.json` ist **Erstkonfiguration**; nach erfolgreichem Restore gewinnt
`state.json`, damit UI-Änderungen nicht beim Neustart überschrieben werden.
Vor dem allerersten Start kann z. B. gesetzt werden:

```json
{
  "source": "native",
  "language": "de",
  "resume": true,
  "ca_file": "/data/sourcify/config/my-ca.pem",
  "download_dir": "/mnt/usb0/sourcify-downloads"
}
```

Eigene CA und Download-Verzeichnis sind Dateikonfigurationen. Für eine
nachträgliche Änderung Service/App stoppen und entsprechende Settings in
`state.json` bearbeiten; nicht gleichzeitig laufende JSON-Dateien verändern.
Ein geändertes Download-Verzeichnis verschiebt vorhandene Dateien nicht.
UI-Settings: Musikquelle, Startseite, Resume, Sprache, Volume,
Verbindung/Kopplung nur in optionalem Companion-Modus,
Shuffle/Repeat, Buffer, Notifications/Dauer, Cover-Limit/Cache leeren,
Import, Logging, Debug Overlay, API-/IPC-Debug und Beenden. Account-Auto-Login,
Gapless oder globale Shortcuts werden nicht als funktionierende Schalter
angeboten. Gespeicherte Kopplung wird wiederverwendet. Resume startet optional
letzten Song und Position mit gespeicherter Queue/Playlist/Volume/Repeat/Shuffle.

Verzeichnisse 0700, atomare Config/Metadaten 0600, lokale IPC-Sockets 0600;
Symlink-/Traversal-Prüfung, validierte IDs, JSON-Limits. Token fehlt in
GET_STATE-/UI-Antworten und Logs. Es gibt keinen öffentlich verifizierten
PS5-Homebrew-Keystore; andere privilegierte Payloads können Dateirechte
umgehen. Der Build behauptet keine Hardware-Verschlüsselung für Tokens.

Logs: APP, AUDIO, NETWORK, API, UI, INPUT, OVERLAY, ETAHEN, IPC, STORAGE.
Maximal 2 MiB plus rotierte `.log.1`. Keine Passwörter, Cookies, Bearer-Tokens,
Media-URLs oder frei eingegebenen Payloadwerte loggen. API-/IPC-Debug zeigt
Operationen/Kommandonamen. Debug Overlay zeigt IPC-/Audio-/Underrun-Status.
Beschädigter State wird als `state.corrupt.json` gesichert und durch Defaults
ersetzt. Beschädigte Offline-Dateien werden nicht abgespielt; löschen/neu laden.
Ohne Control-Plugin funktioniert die App weiter, solange Audio/Assets bereit sind.

## IPC und austauschbare Komponenten

Unix-Domain-Sockets, newline-JSON, Protokollversion 1, validierte Kommandos,
maximal 16 KiB Requests und 4 MiB Replies, 2 s Socket-Timeout, Zeitstempel
höchstens fünf Minuten abweichend. Beispiel:

```json
{"protocol_version":1,"command":"SET_VOLUME","payload":{"volume":0.5},"timestamp":1791122400000}
```

Zeitstempel für reale Requests immer frisch erzeugen. Replies enthalten
`protocol_version`, `payload` oder generischen `error` ohne Geheimnisse.
Control: PLAY, PAUSE, RESUME, TOGGLE_PLAYBACK, NEXT, PREVIOUS, SEEK,
SET_VOLUME, SET_REPEAT, SET_SHUFFLE, GET_STATE, GET_QUEUE; zusätzlich
PLUGIN_STATUS. Service außerdem STOP, SETTINGS, SEARCH, SYNC_LIBRARY, PAIR,
ENQUEUE, SELECT, MOVE, REMOVE, CLEAR_QUEUE, FAVORITE, PLAYLIST_ADD/REMOVE/
DELETE/PLAY, DOWNLOAD, CANCEL_DOWNLOAD, DELETE_DOWNLOAD, CLEAR_CACHE,
SCAN_IMPORTS. `sourcify-ctl SOCKET COMMAND '{...}'` ist das Host-Diagnosetool;
PS5-ELF-Variante benötigt Loader-Unterstützung für Argumente.

## Tests und offene Hardware-Abnahme

In dieser Entwicklungsumgebung bestanden:

- 29 Node-Tests: bestehender Desktop, gemeinsame Musik-API und Companion.
- 10 zusätzliche Native-YouTube-/QuickJS-Prüfgruppen: Renderer, Metadaten-ID,
  sichere URLs, Parameter-Encoding, Source-Settings, echte EJS-Signaturen/
  n-Challenges, Cancellation und Decoder-Script-Fehler.
- 15 native HTTPS-Prozessprüfungen ohne Companion: Suche/Cover, Playerlookup,
  QuickJS sig/n, echtes AAC/M4A-Streaming, VR-Fallback/Query-Range, Pause/Seek/Volume/Queue,
  Download-Fortsetzung/Hash, Bibliothek-Neustart, DE/EN-Settings, Offline, Fehler,
  TLS-CA/Hostname, Pause während Auflösung und STOP-Cancellation.
- 21 native Check-Gruppen: Queue/Playlists/Settings/Parser/Restore/Metadaten,
  Cache/Hash/Symlinks, echte Sockets, SDL-Controller-Mapping und FFmpeg-Audio.
- 21 Prozess-Integrationstests: echter Companion-HTTP, Decoder/SDL,
  Such-/Cover-Requests, Pause/Seek/Volume, Downloads, Control-IPC, Neustart-
  Resume, Offline-Wiedergabe, Netzverlust, D/EN-Renderer, beschädigter State.
- 8 Audioformate (WAV, MP3, AAC/M4A, FLAC, Ogg, Opus, WebM): echte
  HTTP-Streams, Pause/Seek/Resume, Download-Hash und Wiedergabe ohne Companion;
  separat auf Host geprüft, ohne YouTube-Upstream-Fixtures.
- 6 TLS-Checks: API und Audio akzeptieren vertrauenswürdige Zertifikate,
  lehnen unbekannte CAs und falsche Servernamen ab.
- Reale Electron-App mit Sandbox/IPC/Audio/Video/Seek/Favoriten/Credits sowie
  Jam-Host mit zwei unabhängigen Browser-Gästen.
- Reproduzierbare SDK-Neuinstallation mit SHA-256-Prüfung, DEBUG-/RELEASE-
  PS5-Cross-Build und echte Plugin-Paketheader.

Host-Reproduktion mit passenden Entwicklungsbibliotheken:

```sh
npm ci
node --test test/*.test.cjs platforms/ps5/tests/*.test.cjs
# SDL2, SDL2_image/ttf, FFmpeg 7, libcurl/OpenSSL und pkg-config installieren:
make -C platforms/ps5 TARGET=host CONFIG=debug all test transport-tests youtube-tests
# native.py/formats.py benötigen auch ffmpeg CLI, TLS-Tests openssl CLI:
python3 platforms/ps5/tests/native.py
python3 platforms/ps5/tests/integration.py
python3 platforms/ps5/tests/tls.py
# zusätzlich ffmpeg CLI mit MP3/AAC/FLAC/Vorbis/Opus-Encodern:
python3 platforms/ps5/tests/formats.py
```

Die Host-Tests nutzen echte native Codepfade, jedoch Dummy-Audio/Video und
explizite YouTube-Upstream-Fixtures. `SOURCIFY_NATIVE_TEST_PORT` ist eine
ausschließlich im Host-Target vorhandene Testumleitung; Zertifikatsprüfung
bleibt aktiv. Diese Umleitung fehlt im PS5-Binary vollständig. Kein physischer Controller und kein
hörbarer PS5-Audio-Test. Die Linux-Electron-Prüfung benötigt X11 und
Playwright; `test/launch-electron.cjs`, `test/electron.py`, `test/jam-electron.py`
stehen im Source-Paket. Tests sind keine Behauptung unterstützter Firmware.

Hardware-Testreihenfolge:

1. Firmware, etaHEN-Version, verwendeten Loader und Ausgabemodus notieren.
2. App ohne Plugins starten; Datenpfad, Font, Fokus, D/EN und Beenden prüfen.
3. Alle Controller-Eingaben inkl. Stick/Trigger/Options prüfen; 1080p,
   gegebenenfalls 4K und UI-Lesbarkeit am TV testen.
4. Companion koppeln, Live-Suche und echte Titel/Cover laden; hörbaren Song,
   Pause, Resume, Seek, Next/Previous, Volume, Queue-Duplikate prüfen.
5. Favoriten/Playlist/Settings speichern, sauber beenden, neu starten,
   automatisches Resume und Offline-Datei prüfen.
6. Netzwerk trennen, Decoderfehler, fehlendes Cover und beschädigten Cache
   prüfen; anderen Titel starten, ohne die ganze App neu zu starten.
7. Vordergrund-App beenden; Service-/Control-Plugins manuell laden,
   Handshake/Play/Pause/Next/Previous und optionale System-Toast prüfen.
8. Erst danach während laufender Musik ein Spiel starten: Prozessbestand,
   hörbarer Ton, Mischung/Volume, Systemmenu, längere Laufzeit, Spielwechsel
   und Ressourcenverbrauch messen. Audioverluste/Underruns protokollieren.
9. Sleep/Wake und Konsole-Neustart separat prüfen; keine Autostart-Freigabe
   ohne stabile Ergebnisse. Background-Audio erst nach diesem Nachweis aktiv
   markieren. In-Game-Overlay erfordert zusätzlich einen belegten Adapter.

Nächster Entwicklungsschritt sind diese Hardware-Tests und daraus abgeleitete
SDL-/Audio-/Lifecycle-Anpassungen in den Plattformadaptern. Ohne Ergebnisse
werden keine Firmware-Offsets ergänzt und keine Background-Fähigkeit behauptet.
Für Fehleranalyse `logs/sourcify.log`, Startverhalten und Versionsangaben senden;
keine `state.json` oder Cookie-Dateien veröffentlichen, sie enthalten Geheimnisse.

## Dateien, Lizenzen und Verteilung

Prüfbericht mit Build-Hashes und offenen Punkten: `PS5-validation.json`.
Vollständige Liste neuer/geänderter Dateien: `PS5-changed-files.txt`.
Source-Paket enthält bestehende Desktop-App, nativen Core, alle PS5-Adapter,
Build-/Installationsscripts, Tests und die relevanten Third-Party-Quellen.
`PS5-THIRD-PARTY.txt`, `platforms/ps5/third_party/sources.json` und LICENSE
beschreiben Lizenzen und gepinnte Quellen. Der Buildbundle enthält
`SHA256.json` für seine Dateien. SDK-Binärpakete sind nicht im Source-ZIP;
der prüfende Installer lädt die festen öffentlichen Releases separat.

Android-/Windows-Releases werden nicht ersetzt. Die PS5-Auslieferung ist ein
zusätzlicher Entwicklungsbuild, bis die oben genannten Abnahmekriterien auf
echter Hardware nachgewiesen sind.
