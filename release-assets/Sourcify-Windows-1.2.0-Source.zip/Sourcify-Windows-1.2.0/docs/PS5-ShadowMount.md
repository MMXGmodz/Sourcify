# Sourcify: native PS5-App für ShadowMount

Entwicklungsbuild 0.01, Title-ID **PPSA99051**, Stand 5. Oktober 2026.
Diese Version ersetzt den bisherigen ELF-Start der Oberfläche durch einen
nativen App-Titel. Suche, Stream-Auflösung, QuickJS-Signaturen, FFmpeg-Audio,
Cover, Bibliothek und Downloads laufen innerhalb der PS5-App. Im Betrieb ist
kein PC, Browser, Node.js oder Begleitserver erforderlich.

**Der Build wurde auf dem Host geprüft, noch nicht auf einer PS5.** Es gibt
deshalb aktuell keine als unterstützt bestätigte Firmware-/etaHEN-Version.
Die nachfolgenden Installationswege stammen aus den verlinkten Referenzprojekten;
deren Hardware-Ergebnisse werden nicht als Sourcify-Test ausgegeben.

## Installation am Smartphone oder PC

Voraussetzung: eine bereits eingerichtete PS5-Homebrew-Umgebung mit etaHEN,
FTP-Zugriff und einem aktiven **ShadowMountPlus**, das native Homebrew-Titel
bzw. `.ffpfsc` unterstützt. Der Payload Manager allein installiert keinen
App-Titel. Sein grüner Haken bestätigt den Payload-Start, nicht die Oberfläche.

1. `Sourcify-PS5-ShadowMount.zip` entpacken.
2. **Einen** der beiden Wege wählen:
   - Abbild: `PPSA99051.ffpfsc` nach **`/data/homebrew/PPSA99051.ffpfsc`** kopieren.
   - Ordner: den kompletten Ordner `PPSA99051` nach
     **`/data/homebrew/PPSA99051/`** kopieren. Darin liegen direkt `eboot.bin`,
     `sce_sys/`, `sce_module/` und `assets/`.
3. Die Übertragung vollständig abschließen. Ordner und Abbild derselben
   Title-ID nicht gleichzeitig im Scan-Pfad halten. Eine laufende App vor
   einem Update über das PS5-Menü schließen.
4. ShadowMountPlus den Titel erkennen und registrieren lassen. Anschließend
   **Sourcify Player im Spielebereich** starten. Automatischer Start ist je nach
   Loader-Version unterschiedlich und wird nicht vorausgesetzt.
5. `Suche` öffnen, mit dem Controller einen Suchbegriff eingeben und einen Song
   auswählen. Die PS5 benötigt Internet; LAN, WLAN und ein Smartphone-Hotspot
   mit mobilen Daten sind möglich.

`eboot.bin` ist hier ein App-SELF, **kein Payload für den Payload Manager**.
`sourcify.elf` und die alten Sourcify-Service-Plugins werden für diesen
Vordergrund-App-Test nicht benötigt. Vorhandene Dateien in `/data/sourcify`
werden von der neuen App nicht gelöscht; sie nutzt zunächst ihre eigene Sandbox.

Falls kein Titel erscheint: ShadowMountPlus-Verfügbarkeit, vollständigen
Transfer und den Scan-Pfad prüfen. Die App kann eine fehlende App-Registrierung
nicht aus dem Payload Manager heraus ersetzen. Loader-Dokumentation beachten.

## Bedienung

| Taste | Aktion |
|---|---|
| D-Pad / linker Stick | Fokus und Listen bewegen |
| X / Cross | Auswählen, Song starten, Tastatur bestätigen |
| Circle | Zurück, Tastatur/Menü schließen |
| Square | Favorit umschalten |
| Triangle | Zur Warteschlange hinzufügen |
| L1 / R1 | Seite wechseln |
| L2 / R2 | Zurück-/vorspulen |
| Options | Sourcify-Musikmenü mit Play/Pause, Next/Previous, Lautstärke, Queue und Beenden |

Deutsch/Englisch werden in den Einstellungen umgeschaltet. Der SDF-Schriftatlas
enthält deutsche Umlaute, weitere europäische Zeichen und die verwendeten
Bedienzeichen. Die TV-Oberfläche verwendet virtuelle 1920×1080 Koordinaten mit
96/54 Pixeln Sicherheitsabstand. Der verwendete OpenGL-SDK-Build präsentiert
1080p; natives 4K ist mit diesem Paket nicht zugesichert.

## Architektur und tatsächliche Änderungen

- `core/native` und die vorhandenen Audio-/Netzwerk-/Service-/UI-Komponenten
  bleiben die Grundlage. Windows- und Android-Einstiege werden nicht ersetzt.
- `graphics/canvas_gl.cpp` adaptiert Sourcifys bestehende Zeichen-Schnittstelle
  an den echten DrawList/GlBatch-/SDF-Font-Code von `ps5-homebrew-ui`.
  SDL2 bleibt für DualSense-Ereignisse, Bilder und Audio zuständig. Die native
  App initialisiert keinen SDL-Video-Backend.
- Ein eigener CRT erzeugt einen nativen Prozess-ELF (`e_type=0xFE10`);
  der Referenz-Konverter erstellt daraus ein entwicklungs-signiertes
  `eboot.bin`. `param.json` stammt strukturell aus dem Homebrew-UI-Projekt und
  erhält eigene Sourcify-Identität, Titel, Version und Grafik.
- `sce_module/libc.prx` wird aus den öffentlichen Clean-Room-Manifesten
  deterministisch generiert, nicht aus einem Sony-Spiel kopiert. Es erfüllt
  den Loader-Vertrag und ist keine vollständige C-Library. Sourcifys aktive
  Funktionen werden über echte SDK-/Systemimplementierungen gebunden.
- Die Sandbox-Daten liegen in `/download0/sourcify`; Assets werden aus
  `/app0/assets` gelesen. Verzeichnislisten verwenden `open`/`getdents` und
  geprüfte FreeBSD-Records statt des nativen `opendir`-Problems.
  Eine verweigerte etaHEN-Dateiprüfung bricht den Start nicht ab. Ein fehlender
  Unix-Socket lässt die echten Service-Commands innerhalb des App-Prozesses
  weiter funktionieren; externe IPC wird nur bei erfolgreichem Listener als
  verfügbar gemeldet. Native Shell-Argumente werden nicht als Payload-CLI
  interpretiert.
- Native Worker ohne explizite Attribute erhalten 2 MiB Stack; explizite
  SDL-/System-Attribute bleiben erhalten. Der OpenGL-/C++-Heap ist ein
  prozesslebenslanger 256-MiB-Mspace. Tatsächlicher Spitzenbedarf und
  Verhalten bei Speichermangel bleiben Teil des Hardware-Tests.
- Native DNS nutzt die Konsolen-Resolver-Schnittstellen aus EVO (IPv4;
  IPv6-only-Netze sind mit diesem Resolver nicht zugesichert). TLS prüft
  Zertifikate weiter mit dem mitgelieferten CA-Bundle. Zufall für die Library-
  Schnittstellen stammt aus `sceRandomGetRandomNumber` (öffentliche SDK-
  Beispielsignatur), niemals aus Zeitstempeln als Sicherheitsersatz.
  Der finale App-ELF benötigt `libScePosixForWebKit` nicht.
- Optionale, nicht installierte ZSTD-Tracing-Hooks werden beim Link auf Null
  gesetzt, entsprechend ihrer ursprünglichen undefinierten Weak-Symbol-Semantik.
  Es werden keine Musik-/Systemfunktionen durch Erfolgs-Stubs ersetzt.
- Der erste präsentierte Frame löst den Splash-Screen ab. Beenden nutzt
  `sceSystemServiceLoadExec("exit", nullptr)`; ein abgelehnter Exit oder
  Startfehler wird protokolliert und wartet mit Sleep auf das Schließen
  durch die Shell. Keine aggressiven Kill- oder Neustartversuche.

## Daten, Logs und bestehende Plugins

```text
/app0/assets/                       gebündelte Ressourcen, schreibgeschützt
/download0/sourcify/config/          Settings und Bibliothek
/download0/sourcify/cache/covers/    Cover-Cache
/download0/sourcify/cache/audio/     Audio-Cache
/download0/sourcify/cache/metadata/  Download-/Track-Metadaten
/download0/sourcify/downloads/       Offline-Dateien und fortsetzbare .part-Dateien
/download0/sourcify/imports/         lokale Audio-Dateien, falls übertragbar
/download0/sourcify/logs/app.log     frühe Boot-/OpenGL-/Resolver-Diagnose
/download0/sourcify/logs/app.prev.log vorheriger Start
/download0/sourcify/logs/sourcify.log bestehende kategorisierte Service-Logs
```

Bei laufendem Titel ist der Host-/FTP-Pfad in der Referenzumgebung gewöhnlich
`/mnt/sandbox/PPSA99051_000/download0/sourcify/`; die Slot-Nummer kann abweichen.
Dieser Pfad ist kein fest vorausgesetzter Schreibpfad für den App-Code. Manche
FTP-Dienste erlauben dort nur Lesen. Offline-Dateien werden im App-UI geladen.
Quota, Persistenz nach Neuinstallation und USB-Zugriff müssen auf Hardware
geprüft werden; Downloads verlassen sich im nativen Titel nicht auf einen
  möglicherweise verweigerten `statvfs`-Vorabcheck. Größe und Schreibfehler
  werden beim tatsächlichen, begrenzten Transfer geprüft. `/download0` wird nicht als universeller SaveData-Ersatz behauptet.
Die App fordert keine Root-/Jailbreak-Aufhebung an, um alte `/data`-Dateien zu lesen.

Ein außerhalb der Sandbox laufender alter Service/Control-Plugin erhält damit
nicht automatisch Zugriff auf die App-Queue. Feature Detection meldet nur
eine erfolgreich verbundene Instanz als verfügbar. Es werden keine zusätzlichen
Plugins als angeblich funktionierende In-Game-Integration mit diesem Paket gestartet.

## Funktionsstatus

| Funktion | Implementierung / Host-Prüfung | PS5-Hardware |
|---|---|---|
| Native App, eboot/param/runtime/PFS | Debug/Release kompiliert, SELF-Integrität und PFS-Roundtrip geprüft | offen |
| TV-UI / DE/EN / Cover / Fokus | echte OpenGL-Host-Vorschau, Bilder visuell geprüft | offen |
| DualSense-Belegung | SDK-SDL-Backend und synthetische Input-Tests | offen |
| Suche / Metadaten / Player-Auflösung / s+n | native HTTPS- und QuickJS-Prozessprüfungen | offen, Live-YouTube offen |
| Audio / Pause / Seek / Next / Previous / Volume | tatsächliches FFmpeg-Audio in Host-Tests | Ausgabe/Hören offen |
| Queue / Favoriten / Verlauf / lokale Playlists | Core-/Prozessprüfungen | offen |
| Downloads / Resume / SHA256 / Offline | echte HTTPS-AAC-Datei, Fortsetzung und Offline-Decoder geprüft | Speicher/Quota offen |
| Settings / Neustart / Netzwerkfehler | Core-/Prozessprüfungen | offen |
| Accounts / YouTube-Login | nicht implementiert | nicht verfügbar |
| Hintergrundton im Spiel | nicht als funktionsfähig markiert | nicht geprüft |
| In-Game-Overlay / Control Center / globale Shortcuts | nicht verfügbar; vorhandenes Quick Menu ist innerhalb der App | nicht verfügbar |
| Externe etaHEN-Service-/Control-Verbindung | Sandbox-Grenze dokumentiert, nur nach erfolgreicher Verbindung aktiv | offen |

Die bestehende native Musikquelle unterstützt keine YouTube-PO-Tokens, SABR-
only-Streams oder garantierten Zugriff auf beliebige/altersbeschränkte Videos.
YouTube kann Clientprofile und Playercode ändern. Fehler werden angezeigt;
keine Zertifikatsprüfung oder Zugriffskontrolle wird abgeschaltet.

## Reproduzierbarer Build (Linux/WSL)

Build-Voraussetzungen: Python 3.12, venv/pip, Git, curl, tar, make, pkg-config,
G++ mit C++20, zlib-Entwicklungspaket, LLVM/Clang 19 inklusive compiler-rt-Builtins,
öffentliches PS5-Payload-SDK v0.43 und die bereits verwendeten Pacbrew-v0.40.2-
Bibliotheken (SDL2/image, FFmpeg 7, curl/OpenSSL und C++-Runtime).
Der bestehende SDK-Setup-Weg steht in [PS5.md](PS5.md).

```bash
# Einmalig: gepinnte Grafik- und PFS-Werkzeuge herunterladen und überprüfen
bash setup_ps5_app.sh
# Die vom Setup ausgegebenen PS5_OPENGL_PREFIX-/MKPFS-Exports übernehmen.
export PS5_PAYLOAD_SDK=/pfad/zum/sourcify-ps5-sdk
export LLVM_CONFIG=/pfad/zu/llvm-config

bash build_ps5_app.sh --config release
bash build_ps5_app.sh --config debug
```

Unter Windows führt `build_ps5_app.bat --config release` denselben Build in
WSL aus. SDK-/LLVM-/OpenGL-/MkPFS-Variablen müssen in dessen Login-Umgebung
gesetzt sein. Der Batch-Einstieg ist vorhanden, auf Windows nicht getestet.
`--folder-only` erstellt nur den nativen Titelordner, ohne MkPFS zu benötigen.

Ergebnisse: `build/ps5-app/{release,debug}/PPSA99051/`,
`PPSA99051.ffpfsc` und `validation.json`. Die alten ELF-Service-Builds bleiben
unter `build/ps5/` separat. Es wird keine Retail-PKG oder Firmware-Umgehung gebaut.
Alle Referenzrevisionen und Release-Hashes stehen in
`platforms/ps5/native_app/provenance.json`. Enthaltene Font-Baker-Quellen
reproduzieren den Atlas mit:

```bash
g++ -std=c++20 -O2 -w platforms/ps5/vendor/homebrew_ui/tools/font-baker/bake_font.cpp -o /tmp/sourcify-font-baker
/tmp/sourcify-font-baker platforms/ps5/assets/font.ttf platforms/ps5/assets/fonts/sourcify-regular.huifont 56 8 2048 european
```

Die SDK-Manifestprüfung, Runtime-Digestprüfung, Konvertierung, SELF-Integrität
und MkPFS-Verifikation gehören zum Build. Fehlende Abhängigkeiten führen zu
einer Fehlermeldung und werden nicht durch Dummy-Funktionen ersetzt.

## Prüfungen und nächste Hardware-Schritte

Ausgeführt: 29 JavaScript-Tests, 23 native Core-Prüfgruppen einschließlich
bösartiger/trunkierter Directory-Records, 10 YouTube-/QuickJS-Prüfgruppen,
16 native HTTPS-/AAC-/Service-Prozessprüfungen, OpenGL-Vorschauen DE/EN,
Start/Audio-Import und OpenGL-Rendern mit belegtem Socket-Pfad ohne externen
Service, Debug/Release-Builds, SELF-Integrität und vollständiger PFS→exFAT→Datei-Roundtrip.
Fixture-Audio und Fixture-YouTube-Antworten sind ausdrücklich keine Live-
YouTube- oder PS5-Tests. Die Umgebung blockiert Live-YouTube-Zugriff über
den Netzwerkproxy; die PS5-Netzwerkverbindung wurde hier nicht benutzt.

Auf Hardware noch prüfen, in dieser Reihenfolge:

1. Registrierung, Icon, App-Start und erster sichtbarer Frame; Boot-Log sichern.
2. Alle Controller-Tasten, Fokus und Tastatur einschließlich Umlaute.
3. Echte YouTube-Suche und Cover, Stream-Auflösung, hörbare Ausgabe.
4. Pause/Resume/Seek, Queue, Previous/Next, Volume, Favoriten und Playlists.
5. Download/Fortsetzung/Offline, Settings-Speicherung und sauberer Neustart.
6. Netzwerkverlust, Speichermangel, beschädigte Dateien und Quota behandeln.
7. Erst danach getrennte etaHEN-Service-Anbindung und Spielwechsel/Mischung
   untersuchen. Background Playback bleibt bis zu einem erfolgreichen
   Konsolentest ausdrücklich unfertig.

Wenn der Start scheitert: Title-ID, PS5-Firmware, etaHEN-/ShadowMountPlus-
Version sowie `app.log` und `sourcify.log` helfen bei der nächsten Korrektur.
`PS5-ShadowMount-changed-files.txt` listet alle Dateien dieses App-Updates;
`PS5-ShadowMount-validation.json` enthält die tatsächlichen Build-/Testdaten.

## Referenzen und Lizenzen

- [ps5-homebrew-ui](https://github.com/blackbearreloaded/ps5-homebrew-ui),
  Commit `4bd942579dd981b3df9c740438489ca6a614ddc0`: DrawList, GL-Batch,
  Fonts, EGL-Start, CRT-/Container-Tools und Runtime-Shims, GPL-3.0-or-later.
- [EVO-PLAYER-PS5](https://github.com/sainsaji/EVO-PLAYER-PS5),
  Commit `21524a4a6effa65312be2026042e44a96efca4c6`: native libc-/DNS-Kompatibilität,
  Sandbox-/ShadowMount-Erfahrungen, GPL-3.0-or-later.
- [ps5-opengl 1.0.0](https://github.com/blackbearreloaded/ps5-opengl/releases/tag/v1.0.0):
  gepinnter öffentlicher Grafik-SDK-Build samt korrespondierenden Quellen.
- [MkPFS](https://github.com/PSBrew/MkPFS), Commit
  `6cb8313dfe0c988ac52617794553f343243d3a56`: PS5-Abbildbau und Prüfung.

Original-Copyrights bleiben in den Quellen und Lizenzdateien erhalten.
UI-Credits **MMXG · Vibecoded** ersetzen keine nötigen Third-Party-Lizenzen.
Zusätzliche Quellen des Grafik-SDK werden als eigener Source-Download
bereitgestellt; alle enthaltenen Hashes und Quellen lassen sich prüfen.

Zusätzlicher Grafik-Quellcode: [Sourcify-PS5-OpenGL-Source.zip](https://drive.google.com/file/d/1RI1hOKoo2HidtV1NSVD2rnzhg3LjJR8p/view?usp=drivesdk).
