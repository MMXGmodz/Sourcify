@echo off
setlocal
set "BUILD_CONFIG=%~1"
if "%BUILD_CONFIG%"=="" set "BUILD_CONFIG=release"
if /I not "%BUILD_CONFIG%"=="release" if /I not "%BUILD_CONFIG%"=="debug" (
  echo Usage: build_ps5.bat [debug^|release]
  exit /b 2
)
where wsl.exe >nul 2>nul
if errorlevel 1 (
  echo WSL2 with Debian/Ubuntu is required. See docs/PS5.md.
  exit /b 1
)
pushd "%~dp0"
wsl.exe bash -lc "./build_ps5.sh %BUILD_CONFIG%"
set "BUILD_RESULT=%ERRORLEVEL%"
popd
exit /b %BUILD_RESULT%
