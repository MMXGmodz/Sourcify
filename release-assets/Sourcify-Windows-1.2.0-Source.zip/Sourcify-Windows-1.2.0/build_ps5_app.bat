@echo off
rem Native title build through the same Linux toolchain in WSL.
where wsl >nul 2>nul || (echo WSL is required. See docs/PS5.md. & exit /b 1)
wsl --cd "%~dp0." bash -lc "exec bash build_ps5_app.sh %*"
exit /b %errorlevel%
