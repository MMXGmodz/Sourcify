#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
build_config="${1:-release}"
case "$build_config" in debug|DEBUG) build_config=debug;; release|RELEASE) build_config=release;; *) echo "Usage: build_ps5.sh [debug|release]" >&2; exit 2;; esac
printf '[1/6] Checking public PS5 SDK\n'
: "${PS5_PAYLOAD_SDK:?Set PS5_PAYLOAD_SDK to your ps5-payload-sdk installation}"
test -x "$PS5_PAYLOAD_SDK/bin/prospero-clang++" || { echo 'PS5 compiler wrapper missing or not executable' >&2; exit 1; }
command -v make >/dev/null
command -v python3 >/dev/null
"$PS5_PAYLOAD_SDK/bin/prospero-clang++" --version >/dev/null
printf '[2/6] Checking PS5 SDL2, FFmpeg, curl and C++ runtime\n'
"$PS5_PAYLOAD_SDK/bin/prospero-pkg-config" --exists sdl2 SDL2_ttf SDL2_image libavformat libavcodec libswresample libavutil libcurl || { echo 'Install pacbrew PS5 libraries into the SDK target directory' >&2; exit 1; }
test -f "$PS5_PAYLOAD_SDK/target/lib/libc++.a" || { echo 'PS5 libc++ missing' >&2; exit 1; }
printf '[3/6] Building native core, frontend and playback service\n'
make -C platforms/ps5 TARGET=ps5 CONFIG="$build_config" -j"${SOURCIFY_BUILD_JOBS:-2}"
if [ "$build_config" = release ]; then
  "$PS5_PAYLOAD_SDK/bin/prospero-strip" --strip-debug "build/ps5/$build_config/"*.elf
fi
printf '[4/6] Packaging real etaHEN plugin headers\n'
python3 platforms/ps5/etahen_plugin/make_plugin.py "build/ps5/$build_config/sourcify-service.elf" SOUR00001 0.01
python3 platforms/ps5/etahen_plugin/make_plugin.py "build/ps5/$build_config/sourcify-control.elf" SOUR00002 0.01
printf '[5/6] Creating ELF/homebrew installation bundle\n'
python3 platforms/ps5/package.py "$build_config"
printf '[6/6] BUILD SUCCESSFUL — PS5 hardware acceptance still required\n'
