'use strict';
const http=require('node:http'),https=require('node:https'),fs=require('node:fs'),path=require('node:path');
const {Readable}=require('node:stream'),{pipeline}=require('node:stream/promises');
const {randomBytes,randomUUID,timingSafeEqual}=require('node:crypto');
const {isIP}=require('node:net'),os=require('node:os');
const {Store,runEngine,validId,parseRange,safeMediaUrl}=require('../../../src/core.cjs');
const {musicApi}=require('../../../src/music-api.cjs');
function privateIP(ip) {
  ip=ip?.replace(/^::ffff:/,'');if(isIP(ip)!==4)return ip==='::1';
  const a=ip.split('.').map(Number);return a[0]===127||a[0]===10||(a[0]===172&&a[1]>=16&&a[1]<=31)||(a[0]===192&&a[1]===168);
}
function same(a,b){const x=Buffer.from(a||''),y=Buffer.from(b||'');return x.length===y.length&&timingSafeEqual(x,y);}
function safeCover(u){try{const x=new URL(u);return x.protocol==='https:'&&!x.username&&!x.password&&/(^|\.)ytimg\.com$/i.test(x.hostname);}catch{return false;}}
async function body(req){let n=0,s='';for await(const b of req){n+=b.length;if(n>4096)throw Error('Request too large');s+=b;}return JSON.parse(s||'{}');}
function visible(t){return {id:t.id,kind:t.kind,title:String(t.title||'').slice(0,300),artist:String(t.artist||'').slice(0,200),album:String(t.album||'').slice(0,200),duration:Math.max(0,Number(t.duration)||0),thumbnail:safeCover(t.thumbnail)?t.thumbnail:''};}
function createBridge({store,engine,token,fetchFn=fetch,pairCode=null,now=Date.now,tls=null}) {
  if(!/^[a-f0-9]{64}$/.test(token))throw Error('Invalid bridge token');
  const api=musicApi(engine),rate=new Map();let active=0,paired=false;const pairUntil=now()+180000;
  const handler=async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Cache-Control','no-store');
    const reply=(status,obj)=>{if(!res.headersSent){res.writeHead(status,{'Content-Type':'application/json'});res.end(JSON.stringify(obj));}};
    const controller=new AbortController();res.on('close',()=>controller.abort());
    let counted=false;
    try {
      if(!tls&&!privateIP(req.socket.remoteAddress))return reply(403,{error:'Private network required'});
      const host=req.headers.host||'';const u=new URL(req.url,'http://localhost');
      if(host.length>255||req.url.length>2048||req.headers.origin)return reply(403,{error:'Native clients only'});
      if(u.pathname==='/v1/pair'&&req.method==='POST'){
        const key=req.socket.remoteAddress,r=rate.get(key)||{at:now(),n:0};
        if(now()-r.at>180000){r.at=now();r.n=0;}r.n++;rate.set(key,r);
        if(rate.size>200)rate.delete(rate.keys().next().value);
        if(r.n>5)return reply(429,{error:'Pairing attempts exceeded'});
        const p=await body(req);
        if(!pairCode||paired||now()>pairUntil||!same(String(p.code||''),pairCode))return reply(403,{error:'Pairing closed or code invalid'});
        paired=true;return reply(200,{protocol_version:1,token});
      }
      if(!same(req.headers.authorization,'Bearer '+token))return reply(401,{error:'Pair this console first'});
      if(req.method!=='GET'&&req.method!=='HEAD')return reply(405,{error:'Method not allowed'});
      if(active>=8)return reply(503,{error:'Companion busy'});active++;counted=true;
      if(u.pathname==='/v1/status')return reply(200,{protocol_version:1,name:'Sourcify Companion',account:'extractor',features:{search:true,media:true,covers:true,library:true}});
      if(u.pathname==='/v1/library')return reply(200,{protocol_version:1,tracks:Object.values(store.state.tracks).slice(0,5000).map(visible),favorites:store.state.favorites,recent:store.state.recent});
      if(u.pathname==='/v1/search'){
        const q=u.searchParams.get('q'),tracks=await api.search(q,20);store.add(tracks);return reply(200,{protocol_version:1,tracks:tracks.map(visible)});
      }
      const m=/^\/v1\/(media|cover|track)\/([^/]+)$/.exec(u.pathname);
      if(!m)return reply(404,{error:'Unknown endpoint'});
      const id=decodeURIComponent(m[2]);if(!validId(id))return reply(400,{error:'Invalid track ID'});
      const t=store.state.tracks[id];if(!t)return reply(404,{error:'Unknown track'});
      if(m[1]==='track'){
        if(t.kind==='youtube'){const item=await api.remote(id);if(item.metadata?.title&&item.metadata.title!=='Unbekannter Titel')store.add([{...t,...item.metadata}]);}
        return reply(200,{protocol_version:1,track:visible(store.state.tracks[id])});
      }
      if(m[1]==='media'){
        const local=store.state.downloads[id]?.path||(t.kind==='local'?t.path:null);
        if(local){
          const size=fs.statSync(local).size,r=parseRange(req.headers.range,size);if(!r){res.writeHead(416,{'Content-Range':`bytes */${size}`});return res.end();}
          const h={'Content-Type':'application/octet-stream','Content-Length':r.end-r.start+1,'Accept-Ranges':'bytes'};if(r.partial)h['Content-Range']=`bytes ${r.start}-${r.end}/${size}`;
          res.writeHead(r.partial?206:200,h);if(req.method==='HEAD'||size===0)return res.end();
          return await pipeline(fs.createReadStream(local,{start:r.start,end:r.end}),res,{signal:controller.signal});
        }
        const item=await api.remote(id);await forward(item.url,{...item.headers,...(req.headers.range?{Range:req.headers.range}:{})},safeMediaUrl,req,res,controller.signal,fetchFn);return;
      }
      if(!safeCover(t.thumbnail))return reply(404,{error:'No cover'});
      await forward(t.thumbnail,{},safeCover,req,res,controller.signal,fetchFn,true);
    } catch(e){
      if(!controller.signal.aborted){if(res.headersSent)res.destroy();else reply(502,{error:'Source unavailable. Check companion connectivity or import local music.'});}
    } finally {if(counted)active--;}
  };
  const server=tls?https.createServer(tls,handler):http.createServer(handler);server.requestTimeout=10000;server.headersTimeout=10000;server.keepAliveTimeout=3000;
  return server;
}
async function forward(url,headers,allowed,req,res,signal,fetchFn,cover=false){
  let response;
  for(let i=0;i<4;i++){
    if(!allowed(url))throw Error('Unsafe redirect');
    response=await fetchFn(url,{headers,method:req.method,redirect:'manual',signal:AbortSignal.any([signal,AbortSignal.timeout(20000)])});
    if(response.status>=300&&response.status<400){const location=response.headers.get('location');await response.body?.cancel();if(!location)throw Error('No redirect');url=new URL(location,url).href;response=null;continue;}break;
  }
  if(!response||![200,206,416].includes(response.status))throw Error('Source failed');
  if(cover){const n=Number(response.headers.get('content-length'));if(n>4*1024*1024)throw Error('Cover too large');}
  const h={};for(const key of ['content-type','content-length','content-range','accept-ranges']){const v=response.headers.get(key);if(v)h[key]=v;}
  res.writeHead(response.status,h);if(req.method==='HEAD'||!response.body){await response.body?.cancel();res.end();return;}
  await pipeline(Readable.fromWeb(response.body),res,{signal});
}
async function importFiles(store,files){
  for(const file of files){const absolute=path.resolve(file);if(!fs.statSync(absolute).isFile())throw Error('Not a file');const name=path.parse(file).name,i=name.indexOf(' - ');
    const old=Object.values(store.state.tracks).find(t=>t.path===absolute);if(old)continue;
    store.add([{id:'local:'+randomUUID(),kind:'local',title:i>0?name.slice(i+3):name,artist:i>0?name.slice(0,i):'Local music',album:'',duration:0,path:absolute,thumbnail:''}]);
  }
}
async function main(){
  const argv=process.argv.slice(2),value=(key,fallback)=>{const i=argv.indexOf(key);return i<0?fallback:argv[i+1];};
  const root=path.resolve(value('--data',path.join(os.homedir(),'.sourcify-ps5-companion')));fs.mkdirSync(root,{recursive:true,mode:0o700});
  const file=path.join(root,'token');let token;try{token=fs.readFileSync(file,'utf8').trim();}catch{token=randomBytes(32).toString('hex');fs.writeFileSync(file,token,{mode:0o600});}
  const library=value('--library',path.join(root,'library.json'));const store=new Store(library);
  const imports=argv.flatMap((a,i)=>a==='--import'?[argv[i+1]]:[]);await importFiles(store,imports);
  const exe=value('--engine',path.resolve(__dirname,'../../../vendor',process.platform==='win32'?'yt-dlp.exe':'yt-dlp'));
  const cookie=value('--cookies',null);
  if(cookie&&!fs.statSync(cookie).isFile())throw Error('Cookie file missing');
  const shutdown=new AbortController();
  const engine=args=>runEngine(exe,[...(cookie?['--cookies',path.resolve(cookie)]:[]),...args],{signal:shutdown.signal});
  const pairCode=argv.includes('--pair')?String(require('node:crypto').randomInt(10000000,100000000)):null;
  const key=value('--tls-key',null),cert=value('--tls-cert',null);if(!!key!==!!cert)throw Error('Both TLS key and certificate required');
  const tls=key?{key:fs.readFileSync(key),cert:fs.readFileSync(cert)}:null;
  const host=value('--bind','127.0.0.1'),port=Number(value('--port','17840'));if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Invalid port');
  const server=createBridge({store,engine,token,pairCode,tls});server.listen(port,host,()=>{
    console.log(`Sourcify companion listening on ${host}:${port}. Library: ${library}`);
    if(pairCode)console.log(`One-time pairing code (3 minutes): ${pairCode}`);
    if(!tls&&host!=='127.0.0.1')console.log('HTTP pairing/media is unencrypted; use a trusted private LAN or configure TLS.');
  });
  const stop=()=>{shutdown.abort();server.close();server.closeAllConnections();};process.on('SIGINT',stop);process.on('SIGTERM',stop);
}
if(require.main===module)main().catch(()=>{console.error('Companion failed. Check command arguments, engine and file permissions.');process.exitCode=1;});
module.exports={createBridge,privateIP,safeCover,visible,importFiles};
