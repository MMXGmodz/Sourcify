@echo off
setlocal
cd /d "%~dp0"
where node.exe >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 24 LTS first: https://nodejs.org/
  pause
  exit /b 1
)
node --use-env-proxy server.cjs --bind 0.0.0.0 --pair %*
pause
