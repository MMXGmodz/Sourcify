#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
node --use-env-proxy server.cjs --bind 0.0.0.0 --pair "$@"
