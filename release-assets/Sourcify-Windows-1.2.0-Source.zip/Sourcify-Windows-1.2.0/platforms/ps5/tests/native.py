#!/usr/bin/env python3
"""Direct InnerTube integration fixture. No companion/backend is used.
TLS verifies original YouTube hosts; host-only routing is absent from PS5 builds.
"""
import pathlib,json,os,socket,subprocess,tempfile,time,ssl,http.server,threading,urllib.parse,hashlib,base64
root=pathlib.Path(__file__).resolve().parents[3];exe=pathlib.Path(os.environ.get('SOURCIFY_NATIVE_EXE',root/'build/host/debug/sourcify'));assets=root/'platforms/ps5/assets'
player='''(function(){function PlayerUrl(url,key,signature){this.values={s:signature||null,n:null};}PlayerUrl.prototype.set=function(key,value){this.values[key]=value;};PlayerUrl.prototype.get=function(key){return this.values[key];};PlayerUrl.prototype.clone=function(){return this;};PlayerUrl.prototype.apply=function(){if(this.values.s)this.values.s=this.values.s.split("").reverse().join("");if(this.values.n)this.values.n+="_done";};function transform(url,key,signature){var value=new PlayerUrl(url,key,signature);value.set("alr","yes");return value;}}).call(this);'''
checks=[];requests=[];audio=b''
# Generate real AAC/M4A audio so format, length and decoder all match the native player response.
def rpc(data,command,payload=None):
 with socket.socket(socket.AF_UNIX) as s:
  s.settimeout(5);s.connect(str(data/'playback.sock'));s.sendall((json.dumps({'protocol_version':1,'command':command,'payload':payload or {},'timestamp':int(time.time()*1000)})+'\n').encode());out=b''
  while not out.endswith(b'\n'):out+=s.recv(65536)
  j=json.loads(out)
  if 'error' in j:raise RuntimeError(j['error'])
  return j['payload']
def wait(fn):
 until=time.monotonic()+20
 while time.monotonic()<until:
  try:
   x=fn()
   if x:return x
  except (OSError,RuntimeError,KeyError):pass
  time.sleep(.05)
 raise AssertionError('Timed out')
def stop(p):
 if p and p.poll() is None:p.terminate();p.wait(timeout=15)
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def handle(self):
  try:super().handle()
  except (BrokenPipeError,ConnectionResetError,ssl.SSLError):pass
 def reply(self,body,status=200,extra=None):
  if not isinstance(body,bytes):body=body.encode()
  self.send_response(status);self.send_header('Content-Length',str(len(body)))
  for k,v in (extra or {}).items():self.send_header(k,v)
  self.end_headers();self.wfile.write(body)
 def do_POST(self):
  j=json.loads(self.rfile.read(int(self.headers['Content-Length'])));client=j['context']['client']['clientName'];requests.append((self.path,client,j))
  if self.path.startswith('/youtubei/v1/search'):
   assert client=='WEB_REMIX' and 'Authorization' not in self.headers and j['query']=='fixture'
   def row(id):return {'musicResponsiveListItemRenderer':{'playlistItemData':{'videoId':id},'flexColumns':[{'musicResponsiveListItemFlexColumnRenderer':{'text':{'runs':[{'text':'Native '+id}]}}},{'musicResponsiveListItemFlexColumnRenderer':{'text':{'runs':[{'text':'Artist','navigationEndpoint':{'browseEndpoint':{'browseId':'UCfixture'}}},{'text':'Album','navigationEndpoint':{'browseEndpoint':{'browseId':'MPREfixture'}}},{'text':'0:12'}]}}}],'thumbnail':{'musicThumbnailRenderer':{'thumbnail':{'thumbnails':[{'url':'https://i.ytimg.com/vi/'+id+'/hqdefault.jpg','width':480}]}}}}}
   self.reply(json.dumps({'contents':[row('abcdefghi01'),row('abcdefghi02')],'responseContext':{'visitorData':'fixture_visitor'}}));return
  id=j['videoId'];time.sleep(.15)
  if id=='abcdefghi02' and client=='VISIONOS':self.reply(json.dumps({'playabilityStatus':{'status':'ERROR'}}));return
  uri='https://r1--fixture.googlevideo.com/videoplayback?id='+id+'&n=value'
  fmt={'itag':140,'mimeType':'audio/mp4; codecs="mp4a.40.2"','bitrate':128000,'contentLength':str(len(audio)),'lastModified':'123456','signatureCipher':urllib.parse.urlencode({'url':uri,'s':'abc','sp':'sig'})}
  self.reply(json.dumps({'playabilityStatus':{'status':'OK'},'videoDetails':{'videoId':id,'title':'Native '+id,'author':'Artist','lengthSeconds':'12'},'streamingData':{'expiresInSeconds':'3600','adaptiveFormats':[fmt]}}))
 def do_GET(self):
  parsed=urllib.parse.urlparse(self.path);q=urllib.parse.parse_qs(parsed.query)
  if parsed.path=='/youtubei/v1/search':self.reply('{}');return
  if parsed.path=='/watch':self.reply('<script src="/s/player/fixture/player_ias.vflset/en_US/base.js"></script>');return
  if parsed.path.startswith('/s/player/'):self.reply(player);return
  if parsed.path.startswith('/vi/'):
   self.reply(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII='));return
  if parsed.path=='/videoplayback':
   if q.get('sig')!=['cba'] or q.get('n')!=['value_done']:self.reply('bad cipher',403);return
   value=q.get('range',[self.headers.get('Range','bytes=0-'+str(len(audio)-1)).removeprefix('bytes=')])[0];start,end=map(int,value.split('-'));end=min(end,len(audio)-1);requests.append(('media',q.get('id',[None])[0],start,end,'range' in q));status=200 if 'range' in q else 206;self.reply(audio[start:end+1],status,{} if status==200 else {'Content-Range':f'bytes {start}-{end}/{len(audio)}'});return
  self.reply('missing',404)
with tempfile.TemporaryDirectory(prefix='sourcify-native-') as tmp:
 p=pathlib.Path(tmp);encoded=p/'tone.m4a';subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(root/'test/fixtures/tone.wav'),'-c:a','aac','-b:a','128k','-movflags','+faststart',str(encoded)],check=True);audio=encoded.read_bytes();data=p/'data';(data/'config').mkdir(parents=True);key=p/'key.pem';cert=p/'ca.pem'
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(key),'-out',str(cert),'-days','1','-subj','/CN=Sourcify direct fixture','-addext','subjectAltName=DNS:music.youtube.com,DNS:www.youtube.com,DNS:i.ytimg.com,DNS:r1--fixture.googlevideo.com'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(cert,key);server.socket=context.wrap_socket(server.socket,server_side=True);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 env={**os.environ,'SDL_AUDIODRIVER':'dummy','SDL_VIDEODRIVER':'dummy','SOURCIFY_NATIVE_TEST_PORT':str(server.server_port)}
 (data/'config/client.json').write_text(json.dumps({'source':'native','ca_file':str(cert),'resume':False}))
 def start():return subprocess.Popen([str(exe),'--daemon','--data',str(data),'--assets',str(assets)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 process=None
 try:
  transport=root/'build/host/debug/transport-tests';uri='https://music.youtube.com/youtubei/v1/search';wrong=p/'wrong.pem';wrongkey=p/'wrong-key.pem'
  subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(wrongkey),'-out',str(wrong),'-days','1','-subj','/CN=Wrong host','-addext','subjectAltName=DNS:wrong.invalid'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
  for ca,expected in [(cert,0),(assets/'ca-bundle.crt',1)]:assert subprocess.run([str(transport),uri,str(ca),'native'],env=env,capture_output=True).returncode==expected
  wrongserver=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);wrongctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);wrongctx.load_cert_chain(wrong,wrongkey);wrongserver.socket=wrongctx.wrap_socket(wrongserver.socket,server_side=True);threading.Thread(target=wrongserver.serve_forever,daemon=True).start()
  try:assert subprocess.run([str(transport),uri,str(wrong),'native'],env={**env,'SOURCIFY_NATIVE_TEST_PORT':str(wrongserver.server_port)},capture_output=True).returncode==1
  finally:wrongserver.shutdown();wrongserver.server_close()
  checks.append('direct native TLS accepts trusted CA and rejects unknown CA and hostname mismatch')
  process=start();wait(lambda:rpc(data,'GET_STATE'));s=rpc(data,'GET_STATE');assert s['settings']['source']=='native' and not s['capabilities']['companion_required'];checks.append('native default and no companion credentials')
  rpc(data,'SEARCH',{'query':'fixture'});wait(lambda:len(rpc(data,'GET_STATE')['results'])==2);checks.append('direct HTTPS InnerTube search with existing WEB_REMIX profile')
  wait(lambda:len(list((data/'cache/covers').glob('*.img')))==2);checks.append('direct HTTPS cover loading')
  a,b='abcdefghi01','abcdefghi02';rpc(data,'PLAY',{'id':a});rpc(data,'PAUSE');wait(lambda:rpc(data,'GET_STATE')['playback']['duration']>0);assert rpc(data,'GET_STATE')['playback']['paused'];rpc(data,'RESUME');wait(lambda:rpc(data,'GET_STATE')['playback']['position']>.1);checks.append('pause during asynchronous stream resolution is retained');assert not rpc(data,'GET_STATE')['playback']['error'];checks.append('native player lookup, actual QuickJS sig/n solving and FFmpeg streaming')
  rpc(data,'PAUSE');pos=rpc(data,'GET_STATE')['playback']['position'];time.sleep(.2);assert rpc(data,'GET_STATE')['playback']['position']==pos;rpc(data,'SEEK',{'position':4});wait(lambda:rpc(data,'GET_STATE')['playback']['position']>=4);rpc(data,'RESUME');wait(lambda:rpc(data,'GET_STATE')['playback']['position']>4.1);checks.append('direct playback pause, seek and resume')
  rpc(data,'PLAY',{'id':b});rpc(data,'STOP');time.sleep(.3);assert not rpc(data,'GET_STATE')['playback']['loading'] and rpc(data,'GET_STATE')['playback']['paused'];rpc(data,'PLAY',{'id':a});wait(lambda:rpc(data,'GET_STATE')['playback']['position']>.1);checks.append('stop cancels pending native stream resolution')
  rpc(data,'SET_VOLUME',{'volume':.35});assert abs(rpc(data,'GET_STATE')['playback']['volume']-.35)<.001;rpc(data,'ENQUEUE',{'id':b});rpc(data,'NEXT');wait(lambda:any(r[0]=='media' and r[1]==b and r[-1] is True for r in requests));wait(lambda:rpc(data,'GET_STATE')['playback']['position']>.1 and not rpc(data,'GET_STATE')['playback']['loading'] and rpc(data,'GET_STATE')['index']==1);checks.append('queue fallback to actual ANDROID_VR profile and bounded query ranges')
  rpc(data,'PREVIOUS');wait(lambda:rpc(data,'GET_STATE')['index']==0);rpc(data,'FAVORITE',{'id':a});rpc(data,'PLAYLIST_ADD',{'name':'Native mix','id':a});checks.append('previous, favorites and local playlists')
  (data/'downloads'/f'{a}.part').write_bytes(audio[:4096]);(data/'downloads'/f'{a}.part.json').write_text(json.dumps({'id':a,'itag':'140','bytes':len(audio),'last_modified':'123456'}));rpc(data,'DOWNLOAD',{'id':a});wait(lambda:(data/'downloads'/f'{a}.audio').exists());assert (data/'downloads'/f'{a}.audio').read_bytes()==audio;assert any(r[0]=='media' and r[1]==a and r[2]==4096 for r in requests);meta=json.loads((data/'cache/metadata'/f'{a}.json').read_text());assert meta['sha256']==hashlib.sha256(audio).hexdigest();checks.append('direct resumable download, audio verification and SHA256 metadata')
  rpc(data,'SETTINGS',{'language':'en'});rpc(data,'STOP');stop(process);process=start();wait(lambda:rpc(data,'GET_STATE')['favorites']==[a]);assert rpc(data,'GET_STATE')['playlists']['Native mix']==[a];assert rpc(data,'GET_STATE')['settings']['language']=='en';checks.append('native source and library restored across restart')
  rpc(data,'SETTINGS',{'start_page':'Settings'});dest=pathlib.Path(os.environ.get('SOURCIFY_TEST_ARTIFACTS',str(p)));dest.mkdir(exist_ok=True,parents=True)
  rpc(data,'SETTINGS',{'start_page':'Now Playing'});rpc(data,'PLAY',{'id':a});wait(lambda:rpc(data,'GET_STATE')['playback']['position']>.1);rpc(data,'PAUSE')
  for language in ['de','en']:
   rpc(data,'SETTINGS',{'language':language});shot=dest/f'Sourcify-PS5-Nativ-NowPlaying-{language}.png';subprocess.run([str(exe),'--windowed','--data',str(data),'--assets',str(assets),'--frames','15','--screenshot',str(shot)],env=env,check=True,timeout=15,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);assert shot.stat().st_size>10000
  checks.append('native Now Playing and covers render in German and English with paused AAC playback');rpc(data,'SETTINGS',{'start_page':'Settings'})
  for language in ['de','en']:
   rpc(data,'SETTINGS',{'language':language});shot=dest/f'Sourcify-PS5-Nativ-Settings-{language}.png';subprocess.run([str(exe),'--windowed','--data',str(data),'--assets',str(assets),'--frames','15','--screenshot',str(shot)],env=env,check=True,timeout=15,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);assert shot.stat().st_size>10000
  checks.append('native UI settings render with source selection in German and English')
  server.shutdown();server.server_close();rpc(data,'PLAY',{'id':a});wait(lambda:rpc(data,'GET_STATE')['playback']['position']>.1);checks.append('download plays offline without YouTube or companion')
  rpc(data,'SEARCH',{'query':'fixture'});wait(lambda:rpc(data,'GET_STATE')['message']);assert process.poll() is None;checks.append('native network failure is recoverable')
  print(json.dumps({'passed':len(checks),'checks':checks,'upstream':'HTTPS fixtures, not live YouTube','hardware_tested':False},indent=2))
 finally:stop(process);server.shutdown();server.server_close()
