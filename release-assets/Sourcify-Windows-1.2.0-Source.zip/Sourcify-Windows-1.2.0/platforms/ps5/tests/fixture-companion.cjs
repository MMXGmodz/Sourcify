// Deterministic upstream fixtures; production HTTP/auth/range server is unchanged.
'use strict';
const fs=require('node:fs'),path=require('node:path');
const {Store,parseRange}=require('../../../src/core.cjs');
const {createBridge,importFiles}=require('../bridge/server.cjs');
async function main(){
 const dir=process.argv[2],root=path.resolve(__dirname,'../../..');const store=new Store(path.join(dir,'library.json'));
 const wave=fs.readFileSync(path.join(root,'test/fixtures/tone.wav')),cover=fs.readFileSync(path.join(root,'assets/icon.png'));
 store.add(['abcdefghi01','abcdefghi02'].map((id,i)=>({id,title:i?'Second fixture':'First fixture',artist:'Fixture artist',album:'Fixture album',duration:12,thumbnail:'https://i.ytimg.com/fixture.png',kind:'youtube'})));
 await importFiles(store,[path.join(root,'test/fixtures/tone.wav')]);
 const engine=async args=>{if(args.includes('--flat-playlist'))return JSON.stringify({entries:Object.values(store.state.tracks).filter(t=>t.kind==='youtube').map(t=>({...t,channel:t.artist}))});const id=new URL(args.at(-1)).searchParams.get('v');return JSON.stringify({...store.state.tracks[id],url:'https://fixture.googlevideo.com/tone.wav',duration:12});};
 const fetchFn=async(url,opts)=>{
  if(url.includes('ytimg.com'))return new Response(cover,{headers:{'Content-Type':'image/png','Content-Length':String(cover.length)}});
  const r=parseRange(opts.headers.Range,wave.length);if(!r)return new Response(null,{status:416});
  const h={'Content-Type':'audio/wav','Content-Length':String(r.end-r.start+1),'Accept-Ranges':'bytes'};if(r.partial)h['Content-Range']=`bytes ${r.start}-${r.end}/${wave.length}`;
  return new Response(opts.method==='HEAD'?null:wave.subarray(r.start,r.end+1),{status:r.partial?206:200,headers:h});
 };
 const tls=process.argv[3]?{key:fs.readFileSync(process.argv[3]),cert:fs.readFileSync(process.argv[4])}:null;
 const server=createBridge({store,engine,token:'a'.repeat(64),fetchFn,tls});server.listen(0,'127.0.0.1',()=>console.log(JSON.stringify({port:server.address().port})));
 const stop=()=>{server.closeAllConnections();server.close();};process.on('SIGTERM',stop);process.on('SIGINT',stop);
}
main().catch(e=>{console.error(e);process.exitCode=1;});
