#!/usr/bin/env python3
"""Exercise the actual embedded player/UI when the Unix socket cannot be opened."""
import json,os,pathlib,shutil,subprocess,tempfile
root=pathlib.Path(__file__).resolve().parents[3]
exe=pathlib.Path(os.environ.get('SOURCIFY_NATIVE_EXE',root/'build/host-gl/debug/sourcify'))
with tempfile.TemporaryDirectory(prefix='sourcify-local-app-') as folder:
    data=pathlib.Path(folder)/'data';(data/'config').mkdir(parents=True);(data/'imports').mkdir()
    (data/'config/client.json').write_text(json.dumps({'source':'native','resume':False,'start_page':'Library'}))
    (data/'playback.sock').write_text('must remain unchanged')
    shutil.copy(root/'test/fixtures/tone.wav',data/'imports/tone.wav')
    destination=pathlib.Path(os.environ.get('SOURCIFY_TEST_ARTIFACTS',folder));destination.mkdir(exist_ok=True,parents=True)
    screenshot=destination/'Sourcify-PS5-ShadowMount-Local-Fallback.png'
    process=subprocess.run([str(exe),'--data',str(data),'--assets',str(root/'platforms/ps5/assets'),'--frames','35','--screenshot',str(screenshot)],env={**os.environ,'SDL_AUDIODRIVER':'dummy','SDL_VIDEODRIVER':'dummy','LIBGL_ALWAYS_SOFTWARE':'1'},capture_output=True,timeout=30)
    assert process.returncode==0,process.stderr.decode()
    assert (data/'playback.sock').read_text()=='must remain unchanged'
    state=json.loads((data/'config/state.json').read_text())
    assert any(track['title']=='tone' and track['duration']>0 for track in state['tracks'].values())
    assert 'embedded service uses local dispatch' in (data/'logs/sourcify.log').read_text()
    assert screenshot.stat().st_size>10000
    print(json.dumps({'embedded_service_without_socket':True,'occupied_socket_preserved':True,'real_audio_imported':True,'gl_render_and_normal_shutdown':True,'hardware_tested':False}))
