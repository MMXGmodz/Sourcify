#!/usr/bin/env python3
"""Real audio format regression through companion HTTP, FFmpeg/SDL and offline files.
Requires host binaries and an ffmpeg CLI with the listed encoders; no YouTube mocks.
"""
import hashlib,json,os,pathlib,socket,subprocess,tempfile,time,shutil
root=pathlib.Path(__file__).resolve().parents[3]
exe=root/'build/host/debug/sourcify'
assets=root/'platforms/ps5/assets'
formats={'wav':['-c:a','pcm_s16le'],'mp3':['-c:a','libmp3lame','-q:a','5'],'m4a':['-c:a','aac'],'aac':['-c:a','aac','-f','adts'],'flac':['-c:a','flac'],'ogg':['-c:a','libvorbis'],'opus':['-c:a','libopus'],'webm':['-c:a','libopus']}
def rpc(data,command,payload=None):
 with socket.socket(socket.AF_UNIX) as sock:
  sock.settimeout(5);sock.connect(str(data/'playback.sock'))
  sock.sendall((json.dumps({'protocol_version':1,'command':command,'payload':payload or {},'timestamp':int(time.time()*1000)})+'\n').encode())
  reply=b''
  while not reply.endswith(b'\n'):
   chunk=sock.recv(65536)
   if not chunk:raise RuntimeError('Service disconnected')
   reply+=chunk
  message=json.loads(reply)
  if 'error' in message:raise RuntimeError(message['error'])
  return message['payload']
def wait(fn,timeout=15):
 deadline=time.monotonic()+timeout
 while time.monotonic()<deadline:
  try:
   result=fn()
   if result:return result
  except (OSError,KeyError):pass
  time.sleep(.03)
 raise AssertionError('Operation timed out')
def stop(process):
 if process is not None and process.poll() is None:
  process.terminate()
  try:process.wait(timeout=12)
  except subprocess.TimeoutExpired:process.kill();process.wait();raise AssertionError('Process shutdown timed out')
def main():
 if not shutil.which('ffmpeg'):raise SystemExit('Install ffmpeg with MP3/AAC/FLAC/Vorbis/Opus encoders first')
 if not exe.is_file():raise SystemExit('Build TARGET=host CONFIG=debug first')
 env={**os.environ,'SDL_AUDIODRIVER':'dummy','SDL_VIDEODRIVER':'dummy'}
 results=[];service=companion=None
 with tempfile.TemporaryDirectory(prefix='sourcify-formats-') as tmp:
  temp=pathlib.Path(tmp);data=temp/'native';(data/'config').mkdir(parents=True)
  files={}
  for extension,options in formats.items():
   file=temp/('Format - '+extension+'.'+extension)
   subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','6','-ac','2',*options,str(file)],check=True,timeout=20)
   files[extension]=file
  with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  args=['node',str(root/'platforms/ps5/bridge/server.cjs'),'--data',str(temp/'companion'),'--port',str(port)]
  for file in files.values():args+=['--import',str(file)]
  try:
   companion=subprocess.Popen(args,stdout=subprocess.PIPE,text=True)
   assert 'listening' in companion.stdout.readline()
   token=(temp/'companion/token').read_text().strip()
   (data/'config/client.json').write_text(json.dumps({'bridge':f'http://127.0.0.1:{port}','token':token,'resume':False}))
   service=subprocess.Popen([str(exe),'--daemon','--data',str(data),'--assets',str(assets)],env=env)
   wait(lambda:rpc(data,'GET_STATE'));rpc(data,'SYNC_LIBRARY');wait(lambda:rpc(data,'GET_STATE')['online'])
   state=rpc(data,'GET_STATE');tracks={track['title']:id for id,track in state['tracks'].items()}
   assert len(tracks)==len(formats)
   def playback():return rpc(data,'GET_STATE')['playback']
   for extension,file in files.items():
    id=tracks[extension];print('Checking '+extension,flush=True);rpc(data,'PLAY',{'id':id})
    wait(lambda:not playback()['loading'] and playback()['position']>.15)
    assert playback()['error']=='',extension
    rpc(data,'PAUSE');position=playback()['position'];time.sleep(.08);assert playback()['position']==position
    rpc(data,'SEEK',{'position':2});wait(lambda:playback()['duration']>0 and playback()['position']>=2);assert playback()['paused']
    rpc(data,'RESUME');wait(lambda:not playback()['loading'] and playback()['position']>2.1);rpc(data,'STOP')
    rpc(data,'DOWNLOAD',{'id':id});key=id.replace(':','_');download=data/'downloads'/(key+'.audio');metadata=data/'cache/metadata'/(key+'.json')
    wait(lambda:metadata.is_file())
    assert download.read_bytes()==file.read_bytes(),extension
    assert json.loads(metadata.read_text())['sha256']==hashlib.sha256(file.read_bytes()).hexdigest()
    results.append({'format':extension,'http_stream':'passed','pause_seek_resume':'passed','download_hash':'passed'})
   stop(companion);companion=None
   for result in results:
    rpc(data,'PLAY',{'id':tracks[result['format']]});wait(lambda:not playback()['loading'] and playback()['position']>.15)
    assert playback()['error']=='',result['format'];rpc(data,'STOP');result['offline']='passed'
   print(json.dumps({'formats':results,'passed_formats':len(results),'hardware_tested':False},indent=2))
  finally:stop(service);stop(companion)
if __name__=='__main__':main()
