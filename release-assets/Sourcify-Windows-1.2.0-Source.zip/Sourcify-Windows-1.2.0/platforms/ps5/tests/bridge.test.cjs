'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createBridge,privateIP,safeCover,importFiles}=require('../bridge/server.cjs');const {Store}=require('../../../src/core.cjs');
test('companion trust boundaries reject public HTTP peers and unsafe cover hosts',()=>{for(const ip of ['127.0.0.1','10.1.1.1','192.168.2.1','::ffff:172.16.2.1'])assert(privateIP(ip));for(const ip of ['8.8.8.8','172.32.0.1','example.com'])assert(!privateIP(ip));assert(safeCover('https://i.ytimg.com/vi/x.jpg'));assert(!safeCover('https://localhost/secret'));assert(!safeCover('https://ytimg.com.evil.test/x'));});
test('real HTTP server: pairing, search, metadata, local streams and byte ranges',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'sourcify-bridge-'));const store=new Store(path.join(dir,'library.json'));const file=path.join(dir,'Artist - Song.wav');fs.writeFileSync(file,'0123456789');await importFiles(store,[file]);const token='a'.repeat(64);
 const server=createBridge({store,token,pairCode:'12345678',engine:async()=>JSON.stringify({entries:[{id:'abcdefghi01',title:'Song',channel:'Artist',thumbnail:'https://i.ytimg.com/x.jpg'}]})});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+server.address().port;const headers={Authorization:'Bearer '+token};
 try{
  assert.equal((await fetch(base+'/v1/library')).status,401);
  let r=await fetch(base+'/v1/pair',{method:'POST',body:JSON.stringify({code:'wrong'})});assert.equal(r.status,403);
  r=await fetch(base+'/v1/pair',{method:'POST',body:JSON.stringify({code:'12345678'})});assert.equal((await r.json()).token,token);
  assert.equal((await fetch(base+'/v1/pair',{method:'POST',body:JSON.stringify({code:'12345678'})})).status,403);
  r=await fetch(base+'/v1/library',{headers});const library=await r.json();assert.equal(library.tracks.length,1);assert(!JSON.stringify(library).includes(file));const id=library.tracks[0].id;
  r=await fetch(base+'/v1/media/'+encodeURIComponent(id),{headers:{...headers,Range:'bytes=3-5'}});assert.equal(r.status,206);assert.equal(r.headers.get('content-range'),'bytes 3-5/10');assert.equal(await r.text(),'345');
  assert.equal((await fetch(base+'/v1/media/'+encodeURIComponent(id),{headers:{...headers,Range:'bytes=99-'}})).status,416);
  r=await fetch(base+'/v1/media/'+encodeURIComponent(id),{method:'HEAD',headers});assert.equal(r.headers.get('content-length'),'10');assert.equal(await r.text(),'');
  r=await fetch(base+'/v1/search?q=Artist',{headers});assert.equal((await r.json()).tracks[0].id,'abcdefghi01');
  assert.equal((await fetch(base+'/v1/status',{headers:{...headers,Origin:'https://evil.test'}})).status,403);
  assert.equal((await fetch(base+'/v1/media/..%2Fsecret',{headers})).status,400);
 }finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));fs.rmSync(dir,{recursive:true,force:true});}
});
test('pairing expires and too many attempts are rejected',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'sourcify-pair-'));let time=0;const server=createBridge({store:new Store(path.join(dir,'lib.json')),token:'a'.repeat(64),pairCode:'12345678',now:()=>time,engine:async()=>''});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+server.address().port;
 try{time=180001;assert.equal((await fetch(base+'/v1/pair',{method:'POST',body:'{"code":"12345678"}'})).status,403);for(let i=0;i<5;i++)await fetch(base+'/v1/pair',{method:'POST',body:'{}'});assert.equal((await fetch(base+'/v1/pair',{method:'POST',body:'{}'})).status,429);}finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));fs.rmSync(dir,{recursive:true,force:true});}
});
