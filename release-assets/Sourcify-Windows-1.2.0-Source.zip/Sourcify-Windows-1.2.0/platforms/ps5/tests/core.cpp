#include "model.hpp"
#include "storage.hpp"
#include "http.hpp"
#include "protocol.hpp"
#include "player.hpp"
#include "controller.hpp"
#include "dirents.hpp"
#include <cassert>
#include <iostream>
#include <fstream>
#include <unistd.h>
#include <sys/stat.h>
using namespace sourcify;
static int checks=0;
template<class F>void check(F fn){fn();checks++;}
template<class F>void rejects(F fn){bool threw=false;try{fn();}catch(...){threw=true;}assert(threw);}
int main(){
    const std::string a="abcdefghi01",b="abcdefghi02",c="abcdefghi03";
    check([&]{assert(valid_id(a));assert(valid_id("local:12345678-1234-1234-1234-123456789abc"));for(auto id:{"../../test","https://example.com","--exec","local:../x"})assert(!valid_id(id));rejects([]{file_key("../../x");});});
    check([]{rejects([]{parse_json("{broken");});rejects([]{parse_json(std::string(40,'[')+std::string(40,']'));});rejects([]{parse_json("{}",1);});});
    Library l;for(auto id:{a,b,c})l.add(Track::parse(Json{{"id",id},{"title",id},{"duration",120}}));
    check([&]{l.play(a);l.queue={a,b,a,c};l.index=2;l.move(2,0);assert(l.index==0);l.remove(3);assert(l.index==0);l.remove(0);assert(l.index==0);assert(l.current()==a);});
    check([&]{l.queue={a,b,c};l.index=2;l.settings.repeat=0;assert(!l.next(1,true));l.settings.repeat=2;assert(l.next(1,true));assert(l.index==0);l.settings.repeat=1;assert(l.next(1,true));assert(l.index==0);});
    check([&]{l.settings.repeat=0;l.settings.shuffle=true;for(int i=0;i<50;i++){auto previous=l.index;assert(l.next(1));assert(previous!=l.index);}l.settings.shuffle=false;});
    check([&]{l.favorite(a);assert(l.favorites==std::vector<std::string>{a});l.favorite(a);assert(l.favorites.empty());rejects([&]{l.favorite("missing");});});
    check([&]{l.playlist("Mix",a);l.playlist("Mix",a);assert(l.playlists["Mix"].size()==1);l.playlist("Mix",a,true);assert(l.playlists["Mix"].empty());rejects([&]{l.playlist("",a);});});
    check([&]{l.position=31;l.settings.volume=.35f;l.settings.language="en";l.favorite(b);Library restored;restored.restore(l.json(true));assert(restored.current()==l.current());assert(restored.favorites==l.favorites);assert(restored.position==31);assert(restored.settings.volume==.35f);assert(restored.settings.language=="en");});
    check([&]{auto state=l.json();state["queue"].push_back("missing");Library restored;restored.restore(state);assert(restored.queue.size()==l.queue.size());state["schema"]=2;rejects([&]{restored.restore(state);});});
    check([]{Settings s;rejects([&]{s.apply(Json{{"volume",2}});});assert(s.volume==.75f);rejects([&]{s.apply(Json{{"volume","0.5"}});});rejects([&]{s.apply(Json{{"repeat",6}});});rejects([&]{s.apply(Json{{"shuffle","yes"}});});rejects([&]{s.apply(Json{{"language","xx"}});});rejects([&]{s.apply(Json{{"token","password"}});});});
    check([&]{rejects([&]{Track::parse(Json{{"id",a},{"duration",-1}});});rejects([&]{Track::parse(Json{{"id",a},{"title",42}});});rejects([&]{Track::parse(Json{{"id",a},{"title",std::string(301,'a')}});});});
    check([]{assert(safe_bridge("http://127.0.0.1:17840"));assert(safe_bridge("http://192.168.1.2:17840"));assert(safe_bridge("http://172.31.1.2:17840"));assert(safe_bridge("https://music.example.com"));for(auto u:{"http://172.32.1.2:17840","http://example.com","file:///etc/passwd","http://user@192.168.1.2","https://x.example/path","https://x.example?token=x","http://192.168.1.2#x"})assert(!safe_bridge(u));});
    check([]{auto r=envelope("GET_STATE");validate_request(r);r["protocol_version"]=2;rejects([&]{validate_request(r);});r=envelope("GET_STATE");r["timestamp"]=0;rejects([&]{validate_request(r);});r=envelope("GET_STATE");r["payload"]=Json::array();rejects([&]{validate_request(r);});});
    char temp[]="/tmp/sourcify-native-XXXXXX";auto dir=mkdtemp(temp);assert(dir);Paths paths(dir);
    check([&]{atomic_file(paths.config/"test.json","{}");assert(read_file(paths.config/"test.json")=="{}");struct stat st{};stat((paths.config/"test.json").c_str(),&st);assert((st.st_mode&0777)==0600);assert(!fs::exists(paths.config/"test.json.tmp"));rejects([&]{read_file(paths.config/"test.json",1);});});
    check([&]{auto source=paths.root/"source";atomic_file(source,"ok");auto link=paths.root/"link";fs::create_symlink(source,link);rejects([&]{read_file(link);});rejects([&]{atomic_file(source.string()+".tmp","ignored");fs::remove(source.string()+".tmp");fs::create_symlink(link,source.string()+".tmp");atomic_file(source,"blocked");});});
    check([&]{const auto file=paths.downloads/(file_key(a)+".audio");atomic_file(file,"audio");auto meta=Json{{"bytes",5},{"sha256",sha256(file)}};atomic_file(paths.metadata/(file_key(a)+".json"),meta.dump());assert(verified_audio(paths,a));atomic_file(file,"corrupt");assert(!verified_audio(paths,a));});
    check([&]{IpcServer server(paths.socket(),[](const Json& r){return Json{{"command",r["command"]}};});assert(rpc(paths.socket(),"GET_STATE")["command"]=="GET_STATE");rejects([&]{IpcServer duplicate(paths.socket(),[](const Json&){return Json();});});assert(fs::exists(paths.socket()));});assert(!fs::exists(paths.socket()));
    check([&]{register_local_rpc(paths.socket(),[](const Json& r){return Json{{"command",r["command"]}};});struct Guard{fs::path path;~Guard(){unregister_local_rpc(path);}} guard{paths.socket()};assert(!fs::exists(paths.socket()));assert(rpc(paths.socket(),"PAUSE")["command"]=="PAUSE");rejects([&]{rpc(paths.socket(),"invalid");});rejects([&]{rpc(paths.socket(),"PLAY",{{"large",std::string(20000,'x')}});});rejects([&]{register_local_rpc(paths.socket(),[](const Json&){return Json();});});});rejects([&]{rpc(paths.socket(),"GET_STATE");});
    check([&]{atomic_file(paths.covers/"cover.img","img");assert(directory_bytes(paths.covers)==3);clear_covers(paths);assert(directory_bytes(paths.covers)==0);});
    check([]{auto record=[](std::string name){size_t size=(9+name.size()+3)&~size_t(3);std::string value(size,'\0');value[0]=1;value[4]=static_cast<char>(size&255);value[5]=static_cast<char>(size>>8);value[6]=8;value[7]=static_cast<char>(name.size());value.replace(8,name.size(),name);return value;};
        assert(parse_directory_names(record(".")+record("..")+record("cover.img"))==std::vector<std::string>{"cover.img"});
        for(auto bad:{record("../escape"),record(std::string("a\0b",3)),std::string(7,'\0')})rejects([&]{parse_directory_names(bad);});
        auto valid=record("song.audio");for(size_t i=1;i<valid.size();i++)rejects([&]{parse_directory_names(std::string_view(valid).substr(0,i));});
        auto bad=valid;bad[4]=0;rejects([&]{parse_directory_names(bad);});bad=valid;bad[7]=127;rejects([&]{parse_directory_names(bad);});bad=valid;bad[8+10]='x';rejects([&]{parse_directory_names(bad);});
    });
    // A real decoder + SDL audio device, using generated PCM rather than a mock player.
    SDL_setenv("SDL_AUDIODRIVER","dummy",1);assert(SDL_Init(SDL_INIT_AUDIO|SDL_INIT_TIMER|SDL_INIT_GAMECONTROLLER)==0);
    check([]{Input input;const std::map<int,Action> buttons={{SDL_CONTROLLER_BUTTON_A,Action::Accept},{SDL_CONTROLLER_BUTTON_B,Action::Back},{SDL_CONTROLLER_BUTTON_X,Action::Favorite},{SDL_CONTROLLER_BUTTON_Y,Action::Enqueue},{SDL_CONTROLLER_BUTTON_DPAD_UP,Action::Up},{SDL_CONTROLLER_BUTTON_DPAD_DOWN,Action::Down},{SDL_CONTROLLER_BUTTON_DPAD_LEFT,Action::Left},{SDL_CONTROLLER_BUTTON_DPAD_RIGHT,Action::Right},{SDL_CONTROLLER_BUTTON_LEFTSHOULDER,Action::PageLeft},{SDL_CONTROLLER_BUTTON_RIGHTSHOULDER,Action::PageRight},{SDL_CONTROLLER_BUTTON_START,Action::Menu}};for(auto [button,action]:buttons){SDL_Event e{};e.type=SDL_CONTROLLERBUTTONDOWN;e.cbutton.button=static_cast<Uint8>(button);assert(input.event(e)==action);}SDL_Event e{};e.type=SDL_CONTROLLERAXISMOTION;e.caxis.axis=SDL_CONTROLLER_AXIS_LEFTX;e.caxis.value=-24000;assert(input.event(e)==Action::Left);e.caxis.axis=SDL_CONTROLLER_AXIS_LEFTY;e.caxis.value=0;assert(input.event(e)==Action::None);e.caxis.axis=SDL_CONTROLLER_AXIS_TRIGGERLEFT;e.caxis.value=25000;assert(input.event(e)==Action::SeekBack);e.caxis.value=0;input.event(e);e.caxis.axis=SDL_CONTROLLER_AXIS_TRIGGERRIGHT;e.caxis.value=25000;assert(input.event(e)==Action::SeekForward);});
    const auto wave=paths.imports/"tone.wav";{std::ofstream f(wave,std::ios::binary);auto u16=[&](uint16_t n){f.put(static_cast<char>(n&255));f.put(static_cast<char>(n>>8));};auto u32=[&](uint32_t n){u16(static_cast<uint16_t>(n));u16(static_cast<uint16_t>(n>>16));};f.write("RIFF",4);u32(36+48000*4*2);f.write("WAVEfmt ",8);u32(16);u16(1);u16(2);u32(48000);u32(48000*4);u16(4);u16(16);f.write("data",4);u32(48000*4*2);for(int i=0;i<48000*2;i++){int16_t sample=static_cast<int16_t>(std::sin(i*.0576)*12000);u16(static_cast<uint16_t>(sample));u16(static_cast<uint16_t>(sample));}}
    check([&]{Player player;player.play(wave.string(),"","",0);auto until=SDL_GetTicks()+2000;while(player.position()<.15&&SDL_GetTicks()<until)SDL_Delay(10);assert(player.position()>=.15);assert(player.state()["error"]=="");player.pause(true);auto position=player.position();SDL_Delay(100);assert(player.position()==position);player.volume(.2f);assert(player.state()["volume"].get<float>()==.2f);player.seek(1);SDL_Delay(100);assert(player.position()>=1);assert(player.state()["paused"]==true);player.pause(false);until=SDL_GetTicks()+2000;bool ended=false;while(SDL_GetTicks()<until){if(player.take_finished()){ended=true;break;}SDL_Delay(10);}assert(ended);});
    check([&]{Player player;player.play((paths.root/"missing.mp3").string(),"","",0);auto until=SDL_GetTicks()+1000;while(player.state()["error"]==""&&SDL_GetTicks()<until)SDL_Delay(10);assert(player.state()["error"]!="");player.play(wave.string(),"","",0);SDL_Delay(150);assert(player.state()["error"]=="");player.stop();});
    fs::remove_all(paths.root/"cache");fs::create_directory_symlink(paths.root/"imports",paths.root/"cache");rejects([&]{Paths unsafe(dir);});
    SDL_Quit();fs::remove_all(paths.root);std::cout<<checks<<" native checks passed\n";
}
