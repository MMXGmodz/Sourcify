#!/usr/bin/env python3
"""Real host service, FFmpeg, SDL, IPC, companion HTTP and process restart.
Only the external YouTube responses are deterministic test fixtures.
"""
import json,os,pathlib,socket,subprocess,tempfile,time,shutil
root=pathlib.Path(__file__).resolve().parents[3]
exe=root/'build/host/debug/sourcify'
control=root/'build/host/debug/sourcify-control'
assets=root/'platforms/ps5/assets'
checks=[]
def rpc(data,command,payload=None,name='playback.sock'):
 with socket.socket(socket.AF_UNIX) as s:
  s.settimeout(5);s.connect(str(data/name));s.sendall((json.dumps({'protocol_version':1,'command':command,'payload':payload or {},'timestamp':int(time.time()*1000)})+'\n').encode())
  out=b''
  while not out.endswith(b'\n'):
   b=s.recv(65536)
   if not b:raise RuntimeError('IPC disconnected')
   out+=b
  r=json.loads(out)
  if 'error' in r:raise RuntimeError(r['error'])
  return r['payload']
def wait(fn,timeout=12):
 until=time.monotonic()+timeout
 while time.monotonic()<until:
  try:
   value=fn()
   if value:return value
  except (OSError,RuntimeError,KeyError):pass
  time.sleep(.05)
 raise AssertionError('Timed out')
def stop(p):
 if p and p.poll() is None:
  p.terminate()
  try:p.wait(timeout=12)
  except subprocess.TimeoutExpired:p.kill();p.wait();raise AssertionError('Shutdown did not complete')
env={**os.environ,'SDL_AUDIODRIVER':'dummy','SDL_VIDEODRIVER':'dummy'}
with tempfile.TemporaryDirectory(prefix='sourcify-integration-') as tmp:
 temp=pathlib.Path(tmp);data=temp/'data';data.mkdir();(data/'config').mkdir();service=plugin=companion=None
 try:
  companion=subprocess.Popen(['node',str(root/'platforms/ps5/tests/fixture-companion.cjs'),str(temp)],stdout=subprocess.PIPE,text=True)
  port=json.loads(companion.stdout.readline())['port']
  (data/'config/client.json').write_text(json.dumps({'bridge':f'http://127.0.0.1:{port}','token':'a'*64,'resume':False}))
  def start():return subprocess.Popen([str(exe),'--daemon','--data',str(data),'--assets',str(assets)],env=env)
  service=start();wait(lambda:rpc(data,'GET_STATE'));checks.append('service starts with actual audio device')
  rpc(data,'SYNC_LIBRARY');wait(lambda:rpc(data,'GET_STATE')['online']);state=rpc(data,'GET_STATE');assert len(state['tracks'])==3;checks.append('companion library through HTTP')
  rpc(data,'SEARCH',{'query':'fixture'});wait(lambda:len(rpc(data,'GET_STATE')['results'])==2);checks.append('shared search parser + async native API')
  wait(lambda:len(list((data/'cache/covers').glob('*.img')))==2);checks.append('authenticated async cover downloads')
  a,b='abcdefghi01','abcdefghi02'
  rpc(data,'PLAY',{'id':a});wait(lambda:rpc(data,'GET_STATE')['playback']['position']>.15);assert rpc(data,'GET_STATE')['playback']['error']=='';checks.append('HTTP streaming and actual FFmpeg decoding')
  rpc(data,'PAUSE');position=rpc(data,'GET_STATE')['playback']['position'];time.sleep(.15);assert rpc(data,'GET_STATE')['playback']['position']==position;checks.append('pause freezes audio position')
  rpc(data,'SEEK',{'position':4});wait(lambda:rpc(data,'GET_STATE')['playback']['position']>=4);assert rpc(data,'GET_STATE')['playback']['paused'];rpc(data,'RESUME');wait(lambda:rpc(data,'GET_STATE')['playback']['position']>4.1);checks.append('seek while paused then resume')
  rpc(data,'SET_VOLUME',{'volume':.3});assert abs(rpc(data,'GET_STATE')['playback']['volume']-.3)<.001;checks.append('volume is applied to actual output callback')
  rpc(data,'ENQUEUE',{'id':b});rpc(data,'NEXT');wait(lambda:rpc(data,'GET_STATE')['index']==1);rpc(data,'PREVIOUS');wait(lambda:rpc(data,'GET_STATE')['index']==0);checks.append('queue next/previous')
  rpc(data,'FAVORITE',{'id':a});rpc(data,'PLAYLIST_ADD',{'name':'Test Mix','id':a});rpc(data,'SET_REPEAT',{'repeat':2});rpc(data,'SET_SHUFFLE',{'shuffle':True});rpc(data,'SETTINGS',{'language':'en'});checks.append('library, playlist and persisted preferences')
  # Resume a real partial download using the companion Range handler.
  original=(root/'test/fixtures/tone.wav').read_bytes();(data/'downloads'/f'{a}.part').write_bytes(original[:4096])
  rpc(data,'DOWNLOAD',{'id':a});wait(lambda:(data/'downloads'/f'{a}.audio').exists());assert (data/'downloads'/f'{a}.audio').read_bytes()==original;assert (data/'cache/metadata'/f'{a}.json').exists();checks.append('resumable download, audio probe and SHA256 metadata')
  rpc(data,'STOP');plugin=subprocess.Popen([str(control)],env={**env,'SOURCIFY_DATA':str(data)})
  wait(lambda:rpc(data,'PLUGIN_STATUS',name='control.sock'));assert rpc(data,'GET_STATE',name='control.sock')['favorites']==[a];rpc(data,'PLAY',{'id':a},name='control.sock');wait(lambda:rpc(data,'GET_STATE')['playback']['position']>.1);rpc(data,'PAUSE',name='control.sock');assert rpc(data,'GET_STATE')['playback']['paused'];checks.append('separate control plugin forwards real playback IPC')
  rpc(data,'NEXT',name='control.sock');wait(lambda:rpc(data,'GET_STATE')['index']==1);rpc(data,'PREVIOUS',name='control.sock');wait(lambda:rpc(data,'GET_STATE')['index']==0);checks.append('plugin next/previous controls')
  wait(lambda:rpc(data,'GET_STATE')['capabilities']['control_plugin']);assert rpc(data,'GET_STATE')['capabilities']['background_playback'] is False;assert rpc(data,'GET_STATE')['capabilities']['ingame_overlay'] is False;checks.append('handshake feature detection reports hardware limitations')
  rpc(data,'PAUSE');stop(service);service=None;assert not (data/'playback.sock').exists();service=start();wait(lambda:rpc(data,'GET_STATE')['favorites']==[a]);restored=rpc(data,'GET_STATE');assert restored['playlists']['Test Mix']==[a];assert restored['settings']['language']=='en';assert restored['settings']['repeat']==2;assert restored['settings']['shuffle'];checks.append('clean shutdown, socket removal and state restore')
  rpc(data,'SETTINGS',{'resume':True});rpc(data,'PLAY',{'id':a});wait(lambda:rpc(data,'GET_STATE')['playback']['position']>.1);rpc(data,'SEEK',{'position':4});wait(lambda:rpc(data,'GET_STATE')['playback']['position']>4.1);rpc(data,'PAUSE');stop(service);service=None;service=start();wait(lambda:rpc(data,'GET_STATE')['playback']['position']>4.1);checks.append('automatic restart resumes saved song and position')
  stop(companion);companion=None;rpc(data,'PLAY',{'id':a});wait(lambda:rpc(data,'GET_STATE')['playback']['position']>.1);checks.append('verified download plays with companion offline')
  rpc(data,'PLAY',{'id':b});wait(lambda:rpc(data,'GET_STATE')['playback']['error']);assert service.poll() is None;checks.append('network loss surfaces recoverable decoder error')
  # Renderer is the actual native UI, captured with the SDL software backend.
  rpc(data,'SETTINGS',{'start_page':'Now Playing'});rpc(data,'PLAY',{'id':a});wait(lambda:rpc(data,'GET_STATE')['playback']['position']>.1)
  dest=pathlib.Path(os.environ.get('SOURCIFY_TEST_ARTIFACTS',str(temp)))
  dest.mkdir(exist_ok=True,parents=True)
  for language in ['en','de']:
   rpc(data,'SETTINGS',{'language':language})
   shot=dest/f'Sourcify-PS5-Native-{language}.png';subprocess.run([str(exe),'--windowed','--data',str(data),'--assets',str(assets),'--frames','25','--screenshot',str(shot)],env=env,check=True,timeout=15);assert shot.stat().st_size>10000
  checks.append('real native renderer screenshots in English and German')
  rpc(data,'DELETE_DOWNLOAD',{'id':a});assert not (data/'downloads'/f'{a}.audio').exists();checks.append('offline deletion removes audio and metadata')
  stop(service);service=None;state_file=data/'config/state.json';state_file.write_text('{broken');service=start();wait(lambda:rpc(data,'GET_STATE'));assert (data/'config/state.corrupt.json').exists();checks.append('corrupt state recovery without process crash')
  print(json.dumps({'checks':checks,'passed':len(checks),'hardware_tested':False},indent=2))
 finally:
  for p in [plugin,service,companion]:stop(p)
