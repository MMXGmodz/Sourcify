#include "youtube.hpp"
#include <iostream>
#include <cassert>
using namespace sourcify;
int main(int argc,char** argv){assert(argc==2);int checks=0;
const std::string media="https://r1--fixture.googlevideo.com/videoplayback?id=abc&n=value";
assert(approved_youtube_url(media,UrlRole::Media));assert(!approved_youtube_url("http://r1.googlevideo.com/videoplayback",UrlRole::Media));assert(!approved_youtube_url("https://googlevideo.com.evil.test/videoplayback",UrlRole::Media));assert(!approved_youtube_url("https://u:p@googlevideo.com/videoplayback",UrlRole::Media));assert(!approved_youtube_url("https://googlevideo.com:8443/videoplayback",UrlRole::Media));checks++;
assert(url_parameter(set_url_parameter(media,"n","a&ä"),"n")=="a&ä");assert(url_parameter(set_url_parameter(media,"n","done"),"id")=="abc");checks++;
assert(youtube_player_script_url("<script src='/s/player/fixture/player_ias.vflset/en_US/base.js'></script>")=="https://www.youtube.com/s/player/fixture/player_ias.vflset/en_US/base.js");checks++;
Json r={{"playlistItemData",{{"videoId","abcdefghi01"}}},{"flexColumns",Json::array({{{"musicResponsiveListItemFlexColumnRenderer",{{"text",{{"runs",Json::array({{{"text","Title"}}})}}}}}},{{"musicResponsiveListItemFlexColumnRenderer",{{"text",{{"runs",Json::array({{{"text","Artist"},{"navigationEndpoint",{{"browseEndpoint",{{"browseId","UCfixture"}}}}}},{{"text","3:45"}}})}}}}}}})}};
auto tracks=parse_youtube_search({{"contents",Json::array({{{"musicResponsiveListItemRenderer",r}},{{"musicResponsiveListItemRenderer",r}}})}});assert(tracks.size()==1&&tracks[0].title=="Title"&&tracks[0].artist=="Artist"&&tracks[0].duration==225);checks++;
r["playlistItemData"]["videoId"]="../outside";assert(parse_youtube_search({{"musicResponsiveListItemRenderer",r}}).empty());checks++;
bool rejected=false;try{parse_youtube_metadata({{"videoDetails",{{"videoId","abcdefghi02"},{"title","No"}}}},"abcdefghi01");}catch(...){rejected=true;}assert(rejected);checks++;
Settings settings;assert(settings.source=="native");settings.apply({{"source","companion"}});assert(settings.source=="companion");rejected=false;try{settings.apply({{"source","invalid"}});}catch(...){rejected=true;}assert(rejected);checks++;
CipherSolver cipher(argv[1]);const std::string player=R"JS((function(){function PlayerUrl(url,key,signature){this.values={s:signature||null,n:null};}PlayerUrl.prototype.set=function(key,value){this.values[key]=value;};PlayerUrl.prototype.get=function(key){return this.values[key];};PlayerUrl.prototype.clone=function(){return this;};PlayerUrl.prototype.apply=function(){if(this.values.s)this.values.s=this.values.s.split("").reverse().join("");if(this.values.n)this.values.n+="_done";};function transform(url,key,signature){var value=new PlayerUrl(url,key,signature);value.set("alr","yes");return value;}}).call(this);)JS";
auto out=cipher.solve(player,"abc","value",[]{return false;});assert(out.at("sig")=="cba"&&out.at("n")=="value_done");checks++;
rejected=false;try{cipher.solve(player,"abc","value",[]{return true;});}catch(...){rejected=true;}assert(rejected);checks++;
rejected=false;try{cipher.solve("invalid javascript","abc","",[]{return false;});}catch(...){rejected=true;}assert(rejected);checks++;
std::cout<<checks<<" native YouTube and QuickJS checks passed\n";
}
