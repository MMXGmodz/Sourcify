#!/usr/bin/env python3
import json,pathlib,subprocess,tempfile,os
root=pathlib.Path(__file__).resolve().parents[3]
exe=root/'build/host/debug/transport-tests'
with tempfile.TemporaryDirectory(prefix='sourcify-tls-') as d:
 p=pathlib.Path(d);key=p/'key.pem';cert=p/'cert.pem'
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(key),'-out',str(cert),'-days','1','-subj','/CN=Sourcify fixture','-addext','subjectAltName=IP:127.0.0.1'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
 server=subprocess.Popen(['node',str(root/'platforms/ps5/tests/fixture-companion.cjs'),str(p),str(key),str(cert)],stdout=subprocess.PIPE,text=True)
 try:
  port=json.loads(server.stdout.readline())['port']
  for mode in ['api','audio']:
   assert subprocess.run([str(exe),f'https://127.0.0.1:{port}',str(cert),mode],capture_output=True).returncode==0
   assert subprocess.run([str(exe),f'https://127.0.0.1:{port}',str(root/'platforms/ps5/assets/ca-bundle.crt'),mode],capture_output=True).returncode==1
   assert subprocess.run([str(exe),f'https://localhost:{port}',str(cert),mode],capture_output=True).returncode==1
  print('6 TLS checks passed: API and audio accept trusted certificates; reject unknown CA and hostname mismatch')
 finally:server.terminate();server.wait(timeout=5)
