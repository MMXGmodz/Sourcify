#include "http.hpp"
#include "media.hpp"
#include "direct.hpp"
#include <iostream>
int main(int argc,char** argv){using namespace sourcify;if(argc!=4)return 2;curl_global_init(CURL_GLOBAL_DEFAULT);try{if(std::string(argv[3])=="native"){DirectHttps h(argv[2],[]{return false;});h.request(argv[1],UrlRole::Api);return 0;}Settings s;s.bridge=argv[1];s.token=std::string(64,'a');Http h(s,argv[2]);if(std::string(argv[3])=="api"){auto j=h.get("/v1/status");if(j["name"]!="Sourcify Companion")return 3;}else {MediaReader reader(h.base+"/v1/media/abcdefghi01","Authorization: Bearer "+h.token,h.ca,[]{return false;});uint8_t buf[4];if(reader.read(buf,4)!=4||std::string(reinterpret_cast<char*>(buf),4)!="RIFF")return 4;}std::cout<<"Verified TLS transport succeeded\n";return 0;}catch(...){std::cerr<<"Verified TLS transport rejected source\n";return 1;}}
