"""Validate the actual native app and round-trip the generated PS5 image."""
import hashlib,json,pathlib,re,struct,subprocess,tempfile

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def programs(data):
    if data[:6]!=b'\x7fELF\x02\x01':raise RuntimeError('Expected little-endian ELF64')
    offset=struct.unpack_from('<Q',data,32)[0];size,count=struct.unpack_from('<HH',data,54)
    if size!=56:raise RuntimeError('Unexpected ELF program header size')
    return [struct.unpack_from('<IIQQQQQQ',data,offset+i*size) for i in range(count)]
def needed_modules(data):
    headers=programs(data);dynamic=next(h for h in headers if h[0]==2)
    entries=[struct.unpack_from('<qQ',data,dynamic[2]+i) for i in range(0,dynamic[5],16)]
    table=next(value for tag,value in entries if tag==5)
    segment=next(h for h in headers if h[0]==1 and h[3]<=table<h[3]+h[5])
    base=segment[2]+table-segment[3]
    return [data[base+value:data.index(b'\0',base+value)].decode('ascii') for tag,value in entries if tag==1]
def validate_artifacts(out,mkpfs=None):
    out=pathlib.Path(out);app=out/'PPSA99051';param=json.loads((app/'sce_sys/param.json').read_text())
    if param['titleId']!='PPSA99051' or not re.fullmatch(r'UP9000-PPSA99051_00-[A-Z0-9]{16}',param['contentId']):raise RuntimeError('Invalid title identity')
    raw=(out/'eboot.elf').read_bytes()
    if struct.unpack_from('<H',raw,16)[0]!=0xfe10 or not any(h[0]==0x61000001 for h in programs(raw)):raise RuntimeError('Expected native process ELF with SCE process parameters')
    modules=needed_modules((out/'llvm-pie.elf').read_bytes())
    if any('PosixForWebKit' in s for s in modules):raise RuntimeError('Native-inaccessible WebKit imports present')
    if 'libSceRandom.sprx' not in modules:raise RuntimeError('System entropy provider missing')
    if b'SOURCIFY_NATIVE_TEST_PORT' in raw:raise RuntimeError('Host-only TLS routing leaked into PS5 app')
    font=(app/'assets/fonts/sourcify-regular.huifont').read_bytes();count=struct.unpack_from('<I',font,32)[0]
    glyphs={struct.unpack_from('<I',font,40+i*24)[0] for i in range(count)}
    if not all(ord(c) in glyphs for c in 'äöüÄÖÜß♪♥□△'):raise RuntimeError('Required DE/UI glyph missing')
    files={str(p.relative_to(app)):digest(p) for p in app.rglob('*') if p.is_file()}
    if mkpfs:
        with tempfile.TemporaryDirectory(prefix='sourcify-pfs-') as work:
            dest=pathlib.Path(work)/'unpacked'
            subprocess.run([str(mkpfs),'unpack','--deep','--no-progress',str(out/'PPSA99051.ffpfsc'),str(dest)],check=True,stdout=subprocess.DEVNULL)
            extracted={str(p.relative_to(dest)):digest(p) for p in dest.rglob('*') if p.is_file()}
            if files!=extracted:raise RuntimeError('PFS/exFAT round-trip file or SHA256 mismatch')
    return {'native_elf_type':'0xFE10','native_process_parameters':True,'modules':modules,'host_tls_route_absent':True,'locale_glyphs_present':True,'app_files':files,'pfs_roundtrip_files':len(files) if mkpfs else None,'hardware_tested':False}
