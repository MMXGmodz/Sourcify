// Sourcify - sufficient native worker stacks, including SDL and decoder threads.
// SPDX-License-Identifier: GPL-3.0-or-later
#include <pthread.h>
#include <errno.h>
int __real_pthread_create(pthread_t*,const pthread_attr_t*,void*(*)(void*),void*);
int __wrap_pthread_create(pthread_t* thread,const pthread_attr_t* requested,void*(*start)(void*),void* argument){
    if(requested)return __real_pthread_create(thread,requested,start,argument);
    pthread_attr_t attr;int rc=pthread_attr_init(&attr);if(rc)return rc;rc=pthread_attr_setstacksize(&attr,2*1024*1024);
    if(!rc)rc=__real_pthread_create(thread,&attr,start,argument);pthread_attr_destroy(&attr);return rc;
}
