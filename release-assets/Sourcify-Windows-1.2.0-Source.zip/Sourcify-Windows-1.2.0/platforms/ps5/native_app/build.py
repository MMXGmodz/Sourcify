#!/usr/bin/env python3
"""Build Sourcify as a native title, independently of the payload build."""
import argparse, concurrent.futures, hashlib, json, os, pathlib, shlex, shutil, subprocess, sys
from validate import validate_artifacts

HERE=pathlib.Path(__file__).resolve().parent
PS5=HERE.parent
ROOT=PS5.parent.parent
def run(args, **kwargs):
    subprocess.run([str(a) for a in args],check=True,**kwargs)
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',choices=['debug','release'],default='release');parser.add_argument('--folder-only',action='store_true');opts=parser.parse_args()
    sdk=pathlib.Path(os.environ.get('PS5_PAYLOAD_SDK','')).resolve()
    gl=pathlib.Path(os.environ.get('PS5_OPENGL_PREFIX','')).resolve()
    for file in [sdk/'bin/prospero-clang++',sdk/'bin/prospero-lld',sdk/'target/lib/libc++.a',gl/'manifest.sha256',gl/'lib/libPS5OpenGL.a']:
        if not file.is_file():raise RuntimeError(f'Missing {file}. Set PS5_PAYLOAD_SDK and PS5_OPENGL_PREFIX; see docs/PS5.md.')
    if digest(gl/'manifest.sha256')!='f4b91f672be037fbac3f82494f1225deaf4c227a03f37ac3ffa56abb213b943f':raise RuntimeError('Expected verified ps5-opengl SDK 1.0.0 manifest')
    run(['sha256sum','--check','--strict','--quiet','manifest.sha256'],cwd=gl)
    out=ROOT/'build/ps5-app'/opts.config;obj=out/'obj';host=out/'host'
    obj.mkdir(parents=True,exist_ok=True);host.mkdir(exist_ok=True)
    native=HERE/'tooling';tool=host/'ps5-native-tool';builder=host/'libc-builder'
    print('[1/6] Building native container tools',flush=True)
    cxx=os.environ.get('HOST_CXX','g++')
    tool_sources=[native/(s+'.cpp') for s in ['native_app_builder','self_container','elf_object','sce_module_writer']]
    if not tool.exists() or tool.stat().st_mtime<max(p.stat().st_mtime for p in tool_sources):run([cxx,'-std=c++20','-O2',*tool_sources,'-lz','-o',tool])
    if not builder.exists():run([cxx,'-std=c++20','-O2',native/'libc_builder.cpp','-o',builder])
    raw=out/'libc.raw.elf';libc=out/'libc.prx'
    run([builder,native/'runtime/api-surface.txt',native/'runtime/imports.txt',raw])
    run([tool,'self','--sign','--in',raw,'--out',libc])
    if digest(libc)!='e6ff45d16adf687855cc3b33b0c8a4132b6504360b221e0a34c7e99fb3ba0036':raise RuntimeError('Clean-room libc container digest mismatch')
    pkg=sdk/'bin/prospero-pkg-config';packages=['sdl2','SDL2_image','libavformat','libavcodec','libswresample','libavutil','libcurl','openssl']
    cflags=shlex.split(subprocess.check_output([str(pkg),'--cflags',*packages],text=True))
    libs=shlex.split(subprocess.check_output([str(pkg),'--static','--libs',*packages],text=True))
    libs=[flag for flag in libs if flag not in ['-pthread','-lpthread'] and not flag.startswith(('-D','-lSce'))]
    includes=[ROOT/'core/native',PS5/'vendor',PS5/'vendor/homebrew_ui',gl/'include']+[PS5/s for s in ['app','audio','network','storage','ipc','input','graphics','notifications']]
    common=['-O0','-g','-DSOURCIFY_DEBUG'] if opts.config=='debug' else ['-O2','-DNDEBUG']
    common+=['-fPIC','-ffunction-sections','-fdata-sections','-DSOURCIFY_PS5','-DSOURCIFY_PS5_APP','-DSOURCIFY_OPENGL','-DGL_GLEXT_PROTOTYPES','-pthread','-Wall','-Wextra','-Wno-misleading-indentation',*cflags]
    common += ['-I'+str(p) for p in includes]+['-isystem',str(PS5/'vendor/quickjs')]
    sources=[ROOT/'core/native/model.cpp']+[PS5/s for s in ['storage/storage.cpp','network/http.cpp','network/direct.cpp','network/cipher.cpp','network/youtube.cpp','network/media.cpp','audio/player.cpp','ipc/protocol.cpp','app/service.cpp','input/controller.cpp','graphics/canvas_gl.cpp','app/ui.cpp','app/main.cpp']]
    sources += [PS5/'vendor/homebrew_ui/gfx'/s for s in ['draw_list.cpp','font.cpp','gl_batch.cpp','gl_program.cpp','triangulate.cpp']]
    sources += [PS5/'vendor/homebrew_ui/platform/ps5'/s for s in ['system.cpp','display_egl.cpp']]
    sources += [HERE/s for s in ['runtime_shims.c','app_heap.c','libc_ext.c','dns.c','threads.c','random.c','fnmatch.c','strcasestr.c']]+[native/'app_crt.cpp']
    sources += [PS5/'vendor/quickjs'/s for s in ['quickjs.c','libregexp.c','libunicode.c','cutils.c','dtoa.c']]
    print('[2/6] Compiling Sourcify, native OpenGL frontend and runtime',flush=True)
    def compile_one(source):
        target=obj/(str(source.relative_to(ROOT)).replace('/','_')+'.o')
        dependencies=list(PS5.rglob('*.hpp'))+list((ROOT/'core/native').glob('*.hpp'))+[pathlib.Path(__file__)]
        if target.exists() and target.stat().st_mtime>max(source.stat().st_mtime,*(p.stat().st_mtime for p in dependencies)):return target
        cc=sdk/'bin'/('prospero-clang' if source.suffix=='.c' else 'prospero-clang++')
        flags=['-std=gnu11','-D_GNU_SOURCE','-DCONFIG_VERSION="2026-06-04"'] if source.suffix=='.c' else ['-std=c++20']
        run([cc,*flags,*common,*(['-w'] if 'vendor/quickjs' in str(source) else []),'-c',source,'-o',target])
        return target
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(4,os.cpu_count() or 2)) as pool:objects=list(pool.map(compile_one,sources))
    print('[3/6] Linking native process ELF',flush=True)
    # Link the actual SDK libc implementations after the C++/media/GL archives.
    # Threads resolve through system import libraries, never a pretend pthread implementation.
    llvm=os.environ.get('LLVM_CONFIG','llvm-config');resource=subprocess.check_output([str(sdk/'bin/prospero-clang'),'--print-resource-dir'],text=True).strip()
    builtins=pathlib.Path(resource)/'lib/linux/libclang_rt.builtins-x86_64.a'
    stubs=[gl/'lib/libSceAgc.so',gl/'lib/libSceAgcDriver.so']
    runtime=[sdk/'target/lib'/s for s in ['libc++.a','libc++abi.a','libunwind.a']]
    wraps=['malloc','calloc','realloc','free','posix_memalign','malloc_usable_size','sceSystemServiceHideSplashScreen','pthread_create']
    intermediate=out/'llvm-pie.elf'
    run([sdk/'bin/prospero-lld','-T',native/'ps5-pie.ld','--eh-frame-hdr','--gc-sections','--exclude-libs=ALL','--defsym=ZSTD_trace_decompress_begin=0','--defsym=ZSTD_trace_decompress_end=0','--version-script',native/'app-symbols.map','-e','_start','-o',intermediate,*['--wrap='+s for s in wraps],*objects,'-L'+str(sdk/'target/lib'),'--start-group',gl/'lib/libPS5OpenGL.a',*libs,*runtime,builtins,'--end-group','--undefined=ps5_agc_gate2_run','--as-needed',*stubs,*sorted((sdk/'target/lib').glob('*.so')),'--start-group',sdk/'target/lib/libc.a','--end-group'])
    print('[4/6] Converting and signing eboot.bin',flush=True)
    eboot=out/'eboot.elf';param=json.loads((HERE/'sce_sys/param.json').read_text());title=param['titleId'];app=out/title
    run([tool,'link','--in',intermediate,'--out',eboot,'--stub',stubs[0],'--stub',stubs[1],'--stub-dir',sdk/'target/lib','--module-sdk','0x02000009','--companion-sdk','0x08050001','--file-name','eboot.elf'])
    app.mkdir(exist_ok=True);(app/'sce_module').mkdir(exist_ok=True)
    run([tool,'self','--sign','--magic','0x1D3D154F','--in',eboot,'--out',app/'eboot.bin'])
    shutil.copytree(HERE/'sce_sys',app/'sce_sys',dirs_exist_ok=True);shutil.copytree(PS5/'assets',app/'assets',dirs_exist_ok=True);shutil.copy2(libc,app/'sce_module/libc.prx')
    print('[5/6] Verifying native SELF containers and runtime',flush=True)
    run([tool,'self','--inspect','--file',app/'eboot.bin']);run([tool,'self','--inspect','--file',app/'sce_module/libc.prx'])
    manifest={'title_id':title,'configuration':opts.config,'hardware_tested':False,'opengl_manifest_sha256':digest(gl/'manifest.sha256'),'eboot_sha256':digest(app/'eboot.bin'),'runtime_sha256':digest(libc)}
    if not opts.folder_only:
        mkpfs=os.environ.get('MKPFS','mkpfs')
        if not shutil.which(mkpfs):raise RuntimeError('MkPFS missing. Install pinned revision 6cb8313dfe0c988ac52617794553f343243d3a56; see docs/PS5.md. Native app folder was built successfully.')
        print('[6/6] Creating verified ShadowMount PFS',flush=True)
        image=out/(title+'.ffpfsc');image.unlink(missing_ok=True)
        run([mkpfs,'pack','folder','--no-adjust-output-file-extension','--version','PS5','--verify',app,image]);manifest['ffpfsc_sha256']=digest(image)
    manifest['artifact_checks']=validate_artifacts(out,None if opts.folder_only else mkpfs)
    (out/'validation.json').write_text(json.dumps(manifest,indent=2)+'\n');print('BUILD SUCCESSFUL: '+str(out),flush=True)
if __name__=='__main__':
    try:main()
    except (RuntimeError,subprocess.CalledProcessError,OSError) as error:print('BUILD FAILED: '+str(error),file=sys.stderr);sys.exit(1)
