// Sourcify - real console entropy instead of native-inaccessible WebKit imports.
// SPDX-License-Identifier: GPL-3.0-or-later
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
// Signature from the public PS5 SDK samples/hello_so/libB.c.
int sceRandomGetRandomNumber(uint8_t* buffer,size_t size);
void arc4random_buf(void* buffer,size_t size){
    uint8_t* out=buffer;
    while(size){size_t chunk=size<16?size:16;
        if(sceRandomGetRandomNumber(out,chunk)!=0){fputs("[APP] Secure system entropy unavailable\n",stderr);abort();}
        out+=chunk;size-=chunk;
    }
}
uint32_t arc4random(void){uint32_t value;arc4random_buf(&value,sizeof(value));return value;}
uint32_t arc4random_uniform(uint32_t bound){
    if(bound<2)return 0;uint32_t value,threshold=(uint32_t)(-bound)%bound;
    do {value=arc4random();}while(value<threshold);return value%bound;
}
