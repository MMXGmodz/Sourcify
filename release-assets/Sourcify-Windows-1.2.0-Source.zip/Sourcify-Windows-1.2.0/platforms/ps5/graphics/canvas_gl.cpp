// Sourcify - native PS5 drawing through ps5-homebrew-ui's OpenGL kit.
// SPDX-License-Identifier: GPL-3.0-or-later
#include "canvas.hpp"
#include "gfx/gl_batch.hpp"
#include "gfx/gl_program.hpp"
#include "platform/ps5/system.hpp"
#ifdef SOURCIFY_PS5_APP
#include "platform/ps5/display_egl.hpp"
#else
#include <EGL/egl.h>
#include <EGL/eglext.h>
#endif
#include <algorithm>
#include <stdexcept>

namespace sourcify {
namespace gfx=hui::gfx;
static gfx::Color color(SDL_Color c){return {c.r/255.f,c.g/255.f,c.b/255.f,c.a/255.f};}
struct Canvas::Impl {
#ifdef SOURCIFY_PS5_APP
    hui::ps5::Display display;
#else
    EGLDisplay display=EGL_NO_DISPLAY;EGLSurface surface=EGL_NO_SURFACE;EGLContext context=EGL_NO_CONTEXT;
#endif
    gfx::GlBatch batch;gfx::Font font;gfx::DrawList list;uint32_t face=0;
    int width=1920,height=1080;bool first=true;
    struct Image{GLuint texture;int w,h;Uint32 used;};
    std::map<std::string,Image> images;
    explicit Impl(const std::string& assets){
#ifdef SOURCIFY_PS5_APP
        if(!display.open())throw std::runtime_error("PS5 EGL display unavailable; check app.log");width=display.width();height=display.height();
#else
        display=eglGetPlatformDisplay(EGL_PLATFORM_SURFACELESS_MESA,EGL_DEFAULT_DISPLAY,nullptr);
        if(display==EGL_NO_DISPLAY||!eglInitialize(display,nullptr,nullptr)||!eglBindAPI(EGL_OPENGL_API))throw std::runtime_error("Host EGL unavailable");
        EGLConfig config{};EGLint count=0;const EGLint attrs[]={EGL_SURFACE_TYPE,EGL_PBUFFER_BIT,EGL_RENDERABLE_TYPE,EGL_OPENGL_BIT,EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_NONE};
        if(!eglChooseConfig(display,attrs,&config,1,&count)||!count)throw std::runtime_error("Host EGL config unavailable");
        const EGLint ctx[]={EGL_CONTEXT_MAJOR_VERSION,4,EGL_CONTEXT_MINOR_VERSION,5,EGL_CONTEXT_OPENGL_PROFILE_MASK,EGL_CONTEXT_OPENGL_CORE_PROFILE_BIT,EGL_NONE};
        const EGLint size[]={EGL_WIDTH,width,EGL_HEIGHT,height,EGL_NONE};
        surface=eglCreatePbufferSurface(display,config,size);context=eglCreateContext(display,config,EGL_NO_CONTEXT,ctx);
        if(surface==EGL_NO_SURFACE||context==EGL_NO_CONTEXT||!eglMakeCurrent(display,surface,surface,context))throw std::runtime_error("Host EGL context unavailable");
        gfx::set_glsl_prefix("#version 450 core\n");
#endif
        if(!batch.init())throw std::runtime_error("OpenGL shaders unavailable; check app.log");
        if(!font.load(read_file(fs::path(assets)/"fonts/sourcify-regular.huifont",16*1024*1024)))throw std::runtime_error("SDF font unavailable");
        face=batch.create_font_texture(font);if(!face)throw std::runtime_error("Font texture unavailable");IMG_Init(IMG_INIT_PNG|IMG_INIT_JPG);
    }
    ~Impl(){for(auto& [key,image]:images)glDeleteTextures(1,&image.texture);batch.release();IMG_Quit();
#ifndef SOURCIFY_PS5_APP
        eglMakeCurrent(display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);eglDestroyContext(display,context);eglDestroySurface(display,surface);eglTerminate(display);
#endif
    }
    void draw(){glBindFramebuffer(GL_FRAMEBUFFER,0);batch.draw(list,gfx::fit_viewport(width,height),width,height);}
};
Canvas::Canvas(std::string assets,bool):impl(std::make_unique<Impl>(assets)){}
Canvas::~Canvas()=default;
void Canvas::clear(){impl->list.clear();impl->list.push_transform(.9f,0,0,96,54);while(impl->images.size()>32){auto old=std::min_element(impl->images.begin(),impl->images.end(),[](const auto& a,const auto& b){return a.second.used<b.second.used;});glDeleteTextures(1,&old->second.texture);impl->images.erase(old);}glDisable(GL_SCISSOR_TEST);glClearColor(9/255.f,14/255.f,25/255.f,1);glClear(GL_COLOR_BUFFER_BIT);}
void Canvas::present(){impl->draw();if(glGetError()!=GL_NO_ERROR)throw std::runtime_error("OpenGL rendering failed; check app.log");
#ifdef SOURCIFY_PS5_APP
    if(!impl->display.swap())throw std::runtime_error("PS5 display swap failed");if(impl->first){hui::sys::hide_splash_screen();impl->first=false;}
#else
    glFinish();
#endif
}
void Canvas::rect(int x,int y,int w,int h,SDL_Color c,bool border){gfx::Rect r{float(x),float(y),float(w),float(h)};if(border)impl->list.bordered_rect(r,6,{0,0,0,0},2,color(c));else impl->list.rounded_rect(r,w>15&&h>15?8:0,color(c));}
void Canvas::text(std::string value,int x,int y,int size,SDL_Color c,int max_width){if(value.empty()||max_width<=0)return;auto fit=impl->font.fit(value,float(size),float(max_width));impl->list.text(impl->font,impl->face,fit,float(x),float(y)+impl->font.ascent(float(size)),float(size),color(c));}
void Canvas::cover(const std::string& file,int x,int y,int size){
    try {
        if(!impl->images.count(file)){
            auto data=read_file(file,4*1024*1024);
            // Decode only a small, bounded cover; SDL_image validates the container.
            uint32_t w=0,h=0;const auto* b=reinterpret_cast<const unsigned char*>(data.data());
            if(data.size()>=24&&std::memcmp(b,"\x89PNG\r\n\x1a\n",8)==0){for(int i=0;i<4;i++){w=(w<<8)|b[16+i];h=(h<<8)|b[20+i];}}
            else if(data.size()>4&&b[0]==255&&b[1]==216){size_t p=2;while(p+4<data.size()){if(b[p++]!=255)break;while(p<data.size()&&b[p]==255)p++;if(p+3>=data.size())break;int marker=b[p++];if(marker==217||marker==218)break;size_t n=(size_t(b[p])<<8)|b[p+1];if(n<2||n>data.size()-p)break;if(((marker>=192&&marker<=195)||(marker>=197&&marker<=199)||(marker>=201&&marker<=203)||(marker>=205&&marker<=207))&&n>=7){h=(uint32_t(b[p+3])<<8)|b[p+4];w=(uint32_t(b[p+5])<<8)|b[p+6];break;}p+=n;}}
            if(!w||!h||w>4096||h>4096||uint64_t(w)*h>4*1024*1024)throw std::runtime_error("Invalid cover size");
            SDL_Surface* source=IMG_Load_RW(SDL_RWFromConstMem(data.data(),int(data.size())),1);if(!source)throw std::runtime_error("Invalid cover");
            SDL_Surface* rgba=SDL_CreateRGBSurfaceWithFormat(0,512,512,32,SDL_PIXELFORMAT_RGBA32);if(!rgba){SDL_FreeSurface(source);throw std::runtime_error("Cover memory unavailable");}
            int side=std::min(source->w,source->h);SDL_Rect crop{(source->w-side)/2,(source->h-side)/2,side,side};SDL_SetSurfaceBlendMode(source,SDL_BLENDMODE_NONE);SDL_BlitScaled(source,&crop,rgba,nullptr);SDL_FreeSurface(source);
            GLuint texture=impl->batch.create_texture(rgba->w,rgba->h,static_cast<const uint8_t*>(rgba->pixels));SDL_FreeSurface(rgba);if(!texture)throw std::runtime_error("Cover texture unavailable");
            impl->images[file]={texture,512,512,SDL_GetTicks()};
        }
        auto& image=impl->images.at(file);image.used=SDL_GetTicks();impl->list.image(image.texture,{float(x),float(y),float(size),float(size)},{0,0,1,1},{1,1,1,1},12);
        // Evict at frame start, never a texture still referenced by this draw list.
    }catch(...){rect(x,y,size,size,{23,39,52,255});text("♪",x+size/3,y+size/4,size/2,{101,228,218,255},size);}
}
void Canvas::screenshot(const std::string& file){impl->draw();auto* s=SDL_CreateRGBSurfaceWithFormat(0,impl->width,impl->height,32,SDL_PIXELFORMAT_RGBA32);if(!s)throw std::runtime_error("Screenshot memory unavailable");glReadPixels(0,0,impl->width,impl->height,GL_RGBA,GL_UNSIGNED_BYTE,s->pixels);auto* bytes=static_cast<uint8_t*>(s->pixels);for(int y=0;y<impl->height/2;y++)for(int x=0;x<s->pitch;x++)std::swap(bytes[y*s->pitch+x],bytes[(impl->height-y-1)*s->pitch+x]);IMG_SavePNG(s,file.c_str());SDL_FreeSurface(s);}
}
