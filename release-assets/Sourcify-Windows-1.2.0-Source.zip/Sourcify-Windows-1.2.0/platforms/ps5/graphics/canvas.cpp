#include "canvas.hpp"
#include <stdexcept>
#include <algorithm>
namespace sourcify {
Canvas::Canvas(std::string a,bool windowed):assets(std::move(a)){
    if(TTF_Init()<0)throw std::runtime_error("Font system unavailable");IMG_Init(IMG_INIT_PNG|IMG_INIT_JPG);
    SDL_DisplayMode mode{};SDL_GetCurrentDisplayMode(0,&mode);const int width=windowed?1280:(mode.w?mode.w:1920),height=windowed?720:(mode.h?mode.h:1080);
    window=SDL_CreateWindow("Sourcify Player",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,width,height,windowed?SDL_WINDOW_RESIZABLE:SDL_WINDOW_FULLSCREEN_DESKTOP);if(!window)throw std::runtime_error("Video output unavailable");
    renderer=SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);if(!renderer)renderer=SDL_CreateRenderer(window,-1,SDL_RENDERER_SOFTWARE);if(!renderer)throw std::runtime_error("Renderer unavailable");SDL_RenderSetLogicalSize(renderer,1920,1080);SDL_SetRenderDrawBlendMode(renderer,SDL_BLENDMODE_BLEND);SDL_ShowCursor(SDL_DISABLE);
}
Canvas::~Canvas(){for(auto& [key,t]:text_cache)SDL_DestroyTexture(t.texture);for(auto& [key,t]:image_cache)SDL_DestroyTexture(t.texture);for(auto& [n,f]:fonts)TTF_CloseFont(f);SDL_DestroyRenderer(renderer);SDL_DestroyWindow(window);IMG_Quit();TTF_Quit();}
void Canvas::clear(){SDL_SetRenderDrawColor(renderer,9,14,25,255);SDL_RenderClear(renderer);}
void Canvas::present(){SDL_RenderPresent(renderer);}
void Canvas::rect(int x,int y,int w,int h,SDL_Color color,bool border){SDL_SetRenderDrawColor(renderer,color.r,color.g,color.b,color.a);SDL_Rect r{x,y,w,h};if(border)SDL_RenderDrawRect(renderer,&r);else SDL_RenderFillRect(renderer,&r);}
void Canvas::trim(std::map<std::string,Texture>& cache,size_t maximum){while(cache.size()>maximum){auto old=std::min_element(cache.begin(),cache.end(),[](const auto& a,const auto& b){return a.second.used<b.second.used;});SDL_DestroyTexture(old->second.texture);cache.erase(old);}}
void Canvas::text(std::string value,int x,int y,int size,SDL_Color color,int max_width){
    if(value.empty())return;const auto key=std::to_string(size)+":"+std::to_string(color.r)+":"+std::to_string(color.g)+":"+std::to_string(color.b)+":"+value;
    if(!text_cache.count(key)){
        if(!fonts.count(size)){auto font=TTF_OpenFont((fs::path(assets)/"font.ttf").c_str(),size);if(!font)throw std::runtime_error("Font missing. Install assets.");fonts[size]=font;}
        auto* surface=TTF_RenderUTF8_Blended(fonts[size],value.c_str(),color);if(!surface)return;auto* texture=SDL_CreateTextureFromSurface(renderer,surface);Texture t{texture,surface->w,surface->h,SDL_GetTicks()};SDL_FreeSurface(surface);text_cache[key]=t;
    }
    auto& t=text_cache.at(key);t.used=SDL_GetTicks();SDL_Rect src{0,0,std::min(t.width,max_width),t.height},dst{x,y,src.w,t.height};SDL_RenderCopy(renderer,t.texture,&src,&dst);trim(text_cache,200);
}
Canvas::Texture& Canvas::image(const std::string& file){
    if(!image_cache.count(file)){
        auto data=read_file(file,4*1024*1024);uint32_t width=0,height=0;const auto* bytes=reinterpret_cast<const unsigned char*>(data.data());
        auto be32=[&](size_t at){return (uint32_t(bytes[at])<<24)|(uint32_t(bytes[at+1])<<16)|(uint32_t(bytes[at+2])<<8)|bytes[at+3];};
        if(data.size()>=24&&std::memcmp(data.data(),"\x89PNG\r\n\x1a\n",8)==0){width=be32(16);height=be32(20);}
        else if(data.size()>4&&bytes[0]==0xff&&bytes[1]==0xd8){size_t at=2;while(at+4<data.size()){if(bytes[at++]!=0xff)break;while(at<data.size()&&bytes[at]==0xff)at++;if(at+3>=data.size())break;unsigned char marker=bytes[at++];if(marker==0xd9||marker==0xda)break;size_t length=(size_t(bytes[at])<<8)|bytes[at+1];if(length<2||at+length>data.size())break;if((marker>=0xc0&&marker<=0xc3)||(marker>=0xc5&&marker<=0xc7)||(marker>=0xc9&&marker<=0xcb)||(marker>=0xcd&&marker<=0xcf)){if(length>=7){height=(uint32_t(bytes[at+3])<<8)|bytes[at+4];width=(uint32_t(bytes[at+5])<<8)|bytes[at+6];}break;}at+=length;}}
        if(!width||!height||width>4096||height>4096||uint64_t(width)*height>4*1024*1024)throw std::runtime_error("Cover dimensions exceed limit");
        auto* surface=IMG_Load_RW(SDL_RWFromConstMem(data.data(),static_cast<int>(data.size())),1);if(!surface)throw std::runtime_error("Cover unavailable");
        if(surface->w>512||surface->h>512){auto* resized=SDL_CreateRGBSurfaceWithFormat(0,512,512,32,SDL_PIXELFORMAT_ARGB8888);if(resized){int side=std::min(surface->w,surface->h);SDL_Rect crop{(surface->w-side)/2,(surface->h-side)/2,side,side};SDL_BlitScaled(surface,&crop,resized,nullptr);SDL_FreeSurface(surface);surface=resized;}}
        auto* texture=SDL_CreateTextureFromSurface(renderer,surface);Texture t{texture,surface->w,surface->h,SDL_GetTicks()};SDL_FreeSurface(surface);image_cache[file]=t;
    }
    auto& t=image_cache.at(file);t.used=SDL_GetTicks();return t;
}
void Canvas::cover(const std::string& file,int x,int y,int size){
    try{auto& t=image(fs::exists(file)?file:(fs::path(assets)/"icon.png").string());int side=std::min(t.width,t.height);SDL_Rect src{(t.width-side)/2,(t.height-side)/2,side,side},dst{x,y,size,size};SDL_RenderCopy(renderer,t.texture,&src,&dst);trim(image_cache,32);}catch(...){rect(x,y,size,size,{23,39,52,255});text("♪",x+size/3,y+size/4,size/2,{101,228,218,255},size);}
}
void Canvas::screenshot(const std::string& file){int w=0,h=0;SDL_GetRendererOutputSize(renderer,&w,&h);auto* s=SDL_CreateRGBSurfaceWithFormat(0,w,h,32,SDL_PIXELFORMAT_ARGB8888);if(s){if(SDL_RenderReadPixels(renderer,nullptr,s->format->format,s->pixels,s->pitch)==0)IMG_SavePNG(s,file.c_str());SDL_FreeSurface(s);}}
}
