#pragma once
#include "storage.hpp"
#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_image.h>
#include <map>
namespace sourcify {
class Canvas {
#ifdef SOURCIFY_OPENGL
    struct Impl;
    std::unique_ptr<Impl> impl;
#else
    SDL_Window* window=nullptr;
    SDL_Renderer* renderer=nullptr;
    std::map<int,TTF_Font*> fonts;
    struct Texture {SDL_Texture* texture;int width,height;Uint32 used;};
    std::map<std::string,Texture> text_cache,image_cache;
    std::string assets;
    Texture& image(const std::string& file);
    void trim(std::map<std::string,Texture>& cache,size_t maximum);
#endif
public:
    explicit Canvas(std::string assets,bool windowed=false);~Canvas();
    void clear();void present();
    void rect(int x,int y,int w,int h,SDL_Color color,bool border=false);
    void text(std::string value,int x,int y,int size=30,SDL_Color color={241,246,251,255},int max_width=1400);
    void cover(const std::string& file,int x,int y,int size);
    void screenshot(const std::string& file);
#ifndef SOURCIFY_OPENGL
    SDL_Renderer* native(){return renderer;}
#endif
};
}
