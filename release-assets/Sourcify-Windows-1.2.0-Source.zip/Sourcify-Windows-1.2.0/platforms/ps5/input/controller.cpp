#include "controller.hpp"
#include <cstdlib>
namespace sourcify {
Input::Input(){for(int i=0;i<SDL_NumJoysticks();i++)if(SDL_IsGameController(i)){controller=SDL_GameControllerOpen(i);if(controller)break;}}
Input::~Input(){if(controller)SDL_GameControllerClose(controller);}
Action Input::event(const SDL_Event& e){
    if(e.type==SDL_QUIT)return Action::Quit;
    if(e.type==SDL_CONTROLLERDEVICEADDED&&!controller)controller=SDL_GameControllerOpen(e.cdevice.which);
    if(e.type==SDL_CONTROLLERDEVICEREMOVED&&controller&&SDL_JoystickInstanceID(SDL_GameControllerGetJoystick(controller))==e.cdevice.which){SDL_GameControllerClose(controller);controller=nullptr;axis=Action::None;}
    if(e.type==SDL_CONTROLLERBUTTONDOWN){switch(e.cbutton.button){
        case SDL_CONTROLLER_BUTTON_DPAD_UP:return Action::Up;case SDL_CONTROLLER_BUTTON_DPAD_DOWN:return Action::Down;case SDL_CONTROLLER_BUTTON_DPAD_LEFT:return Action::Left;case SDL_CONTROLLER_BUTTON_DPAD_RIGHT:return Action::Right;
        case SDL_CONTROLLER_BUTTON_A:return Action::Accept;case SDL_CONTROLLER_BUTTON_B:return Action::Back;case SDL_CONTROLLER_BUTTON_X:return Action::Favorite;case SDL_CONTROLLER_BUTTON_Y:return Action::Enqueue;
        case SDL_CONTROLLER_BUTTON_LEFTSHOULDER:return Action::PageLeft;case SDL_CONTROLLER_BUTTON_RIGHTSHOULDER:return Action::PageRight;case SDL_CONTROLLER_BUTTON_START:return Action::Menu;default:break;
    }}
    if(e.type==SDL_CONTROLLERAXISMOTION){
        if(e.caxis.axis==SDL_CONTROLLER_AXIS_LEFTX)x=e.caxis.value;
        if(e.caxis.axis==SDL_CONTROLLER_AXIS_LEFTY)y=e.caxis.value;
        if(e.caxis.axis==SDL_CONTROLLER_AXIS_TRIGGERLEFT)left_trigger=e.caxis.value;
        if(e.caxis.axis==SDL_CONTROLLER_AXIS_TRIGGERRIGHT)right_trigger=e.caxis.value;
        Action next=Action::None;
        if(left_trigger>20000)next=Action::SeekBack;else if(right_trigger>20000)next=Action::SeekForward;
        else if(std::abs(x)>16000||std::abs(y)>16000){if(std::abs(x)>=std::abs(y))next=x<0?Action::Left:Action::Right;else next=y<0?Action::Up:Action::Down;}
        if(next!=axis){axis=next;repeat_at=SDL_GetTicks()+350;return next;}
    }
    if(e.type==SDL_KEYDOWN){switch(e.key.keysym.sym){case SDLK_UP:return Action::Up;case SDLK_DOWN:return Action::Down;case SDLK_LEFT:return Action::Left;case SDLK_RIGHT:return Action::Right;case SDLK_RETURN:return Action::Accept;case SDLK_ESCAPE:return Action::Back;case SDLK_f:return Action::Favorite;case SDLK_q:return Action::Enqueue;case SDLK_PAGEUP:return Action::PageLeft;case SDLK_PAGEDOWN:return Action::PageRight;case SDLK_LEFTBRACKET:return Action::SeekBack;case SDLK_RIGHTBRACKET:return Action::SeekForward;case SDLK_TAB:case SDLK_SPACE:return Action::Menu;default:break;}}
    return Action::None;
}
Action Input::repeat(){if(axis!=Action::None&&SDL_GetTicks()>=repeat_at){repeat_at=SDL_GetTicks()+150;return axis;}return Action::None;}
}
