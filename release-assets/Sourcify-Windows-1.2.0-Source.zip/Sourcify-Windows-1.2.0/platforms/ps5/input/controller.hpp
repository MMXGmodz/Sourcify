#pragma once
#include <SDL.h>
#include <functional>
namespace sourcify {
enum class Action {None,Up,Down,Left,Right,Accept,Back,Favorite,Enqueue,PageLeft,PageRight,SeekBack,SeekForward,Menu,Quit};
class Input {
    SDL_GameController* controller=nullptr;
    Uint32 repeat_at=0;
    Action axis=Action::None;
    Sint16 x=0,y=0,left_trigger=0,right_trigger=0;
public:
    Input();~Input();
    Action event(const SDL_Event& e);
    Action repeat();
};
}
