#pragma once
#include "model.hpp"
namespace sourcify {bool song_notification(const Json& track,const std::string& icon);}
