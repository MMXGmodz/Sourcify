// JSON envelope adapted from ps5-payload-sdk samples/notify (LightningMods, GPL-3.0+).
#include "song.hpp"
#include <ctime>
#ifdef SOURCIFY_PS5
extern "C" int sceNotificationSend(int userId,bool isLogged,const char* payload);
#endif
namespace sourcify {
bool song_notification(const Json& track,const std::string& icon){
#ifdef SOURCIFY_PS5
    auto now=std::time(nullptr);std::tm utc{};gmtime_r(&now,&utc);char date[32];std::strftime(date,sizeof(date),"%Y-%m-%dT%H:%M:%S.000Z",&utc);
    Json view={{"icon",{{"type","Url"},{"parameters",{{"url",icon}}}}},{"message",{{"body","♪ Sourcify · "+track.value("title",std::string())}}},{"subMessage",{{"body",track.value("artist",std::string())}}}};
    Json payload={{"rawData",{{"viewTemplateType","InteractiveToastTemplateB"},{"channelType","Downloads"},{"useCaseId","IDC"},{"toastOverwriteType","No"},{"isImmediate",true},{"priority",100},{"viewData",view}}},{"createdDateTime",date},{"localNotificationId",std::to_string(now)}};
    auto text=payload.dump();return sceNotificationSend(0xFE,true,text.c_str())>=0;
#else
    (void)track;(void)icon;return false;
#endif
}
}
