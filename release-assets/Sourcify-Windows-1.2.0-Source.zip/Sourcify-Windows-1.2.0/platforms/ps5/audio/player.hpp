#pragma once
#include "http.hpp"
#include <SDL.h>
#include <array>
#include <algorithm>
#include <cmath>
namespace sourcify {
class Player {
    static constexpr uint64_t capacity=48000*2*10;
    std::vector<int16_t> ring=std::vector<int16_t>(capacity);
    std::atomic<uint64_t> written{0},read{0},played{0},serial{0};
    std::atomic<bool> stopping{false},paused{true},loading{false},finished{false};
    std::atomic<float> gain{.75f};
    std::atomic<double> base{0},duration{0};
    std::atomic<uint64_t> underruns{0};
    std::atomic<int> buffer_ms{2000};
    std::mutex mutex;
    std::condition_variable cv;
    struct Source {std::string uri,headers,ca;double position=0;int64_t length=-1;bool query_ranges=false;};
    Source source;
    std::string failure;
    SDL_AudioDeviceID device=0;
    std::thread thread;
    void run();
    void decode(const Source& src,uint64_t generation);
    static void callback(void* self,Uint8* stream,int length);
public:
    Player();~Player();
    void play(std::string uri,std::string headers,std::string ca,double position=0,int64_t content_length=-1,bool query_ranges=false);
    void pause(bool value);
    void stop();
    void seek(double seconds);
    void volume(float value){gain=std::clamp(value,0.f,1.f);}
    void buffer(int ms){buffer_ms=std::clamp(ms,250,10000);}
    double position() const{return base.load()+static_cast<double>(played.load())/(48000*2);}
    Json state();
    bool take_finished(){return finished.exchange(false);}
};
}
