#include "player.hpp"
#include "media.hpp"
#include <stdexcept>
#include <cstring>
#include <memory>
extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libswresample/swresample.h>
#include <libavutil/opt.h>
}
namespace sourcify {
Player::Player(){
    SDL_AudioSpec want{},got{};want.freq=48000;want.channels=2;want.format=AUDIO_S16SYS;want.samples=1024;want.callback=callback;want.userdata=this;
    device=SDL_OpenAudioDevice(nullptr,0,&want,&got,0);if(!device)throw std::runtime_error("Audio device unavailable");
    av_log_set_level(AV_LOG_QUIET);thread=std::thread([this]{run();});
}
Player::~Player(){stopping=true;serial++;cv.notify_all();if(thread.joinable())thread.join();SDL_CloseAudioDevice(device);}
void Player::play(std::string uri,std::string headers,std::string ca,double position,int64_t content_length,bool query_ranges){
    if(!std::isfinite(position)||position<0||position>86400)throw std::runtime_error("Invalid position");
    SDL_PauseAudioDevice(device,1);
    {std::lock_guard<std::mutex> lock(mutex);source={std::move(uri),std::move(headers),std::move(ca),position,content_length,query_ranges};failure.clear();serial++;}
    paused=false;loading=true;finished=false;cv.notify_all();
}
void Player::pause(bool value){paused=value;SDL_PauseAudioDevice(device,value?1:0);cv.notify_all();}
void Player::stop(){{std::lock_guard<std::mutex> lock(mutex);source.uri.clear();serial++;}paused=true;loading=false;SDL_PauseAudioDevice(device,1);cv.notify_all();}
void Player::seek(double seconds){if(!std::isfinite(seconds)||seconds<0)return;Source s;{std::lock_guard<std::mutex> lock(mutex);s=source;}if(s.uri.empty())return;bool was=paused;play(s.uri,s.headers,s.ca,seconds,s.length,s.query_ranges);if(was)pause(true);}
Json Player::state(){std::lock_guard<std::mutex> lock(mutex);return {{"paused",paused.load()},{"loading",loading.load()},{"position",position()},{"duration",duration.load()},{"volume",gain.load()},{"error",failure},{"underruns",underruns.load()}};}
void Player::callback(void* ptr,Uint8* stream,int length){
    auto& p=*static_cast<Player*>(ptr);auto* out=reinterpret_cast<int16_t*>(stream);auto wanted=static_cast<uint64_t>(length/2);
    const auto at=p.read.load(std::memory_order_relaxed),end=p.written.load(std::memory_order_acquire);const auto count=std::min(wanted,end-at);const float volume=p.gain.load(std::memory_order_relaxed);
    for(uint64_t i=0;i<count;i++)out[i]=static_cast<int16_t>(static_cast<float>(p.ring[(at+i)%capacity])*volume);
    if(count<wanted){std::memset(out+count,0,static_cast<size_t>(wanted-count)*2);if(!p.loading.load(std::memory_order_relaxed))p.underruns++;}
    p.read.store(at+count,std::memory_order_release);p.played.fetch_add(count,std::memory_order_relaxed);p.cv.notify_one();
}
void Player::run(){uint64_t generation=0;while(!stopping){Source s;{
        std::unique_lock<std::mutex> lock(mutex);cv.wait(lock,[&]{return stopping||serial.load()!=generation;});if(stopping)return;generation=serial;s=source;
    }
    SDL_LockAudioDevice(device);written=0;read=0;played=0;base=s.position;duration=0;SDL_UnlockAudioDevice(device);
    if(s.uri.empty())continue;
    if(!paused)SDL_PauseAudioDevice(device,0);
    try{decode(s,generation);}catch(...){if(serial==generation&&!stopping){loading=false;paused=true;SDL_PauseAudioDevice(device,1);std::lock_guard<std::mutex> lock(mutex);failure="Audio stream unavailable or decoder failed";}}
}}
void Player::decode(const Source& src,uint64_t generation){
    struct Context {
        AVFormatContext* format=avformat_alloc_context();AVCodecContext* codec=nullptr;AVPacket* packet=av_packet_alloc();AVFrame* frame=av_frame_alloc();SwrContext* swr=nullptr;AVIOContext* io=nullptr;std::unique_ptr<MediaReader> reader;
        ~Context(){swr_free(&swr);av_frame_free(&frame);av_packet_free(&packet);avcodec_free_context(&codec);avformat_close_input(&format);if(io){av_freep(&io->buffer);avio_context_free(&io);}}
    } c;
    if(!c.format||!c.packet||!c.frame)throw std::runtime_error("Decoder allocation failed");
    struct Interrupt {Player* p;uint64_t generation;} interrupt{this,generation};
    c.format->interrupt_callback={[](void* opaque){auto* i=static_cast<Interrupt*>(opaque);return (i->p->stopping||i->p->serial.load()!=i->generation)?1:0;},&interrupt};
    if(src.uri.rfind("https://",0)==0||src.uri.rfind("http://",0)==0){
        std::string auth=src.headers;while(!auth.empty()&&(auth.back()=='\r'||auth.back()=='\n'))auth.pop_back();
        c.reader=std::make_unique<MediaReader>(src.uri,auth,src.ca,[this,generation]{return stopping||serial!=generation;},src.length,src.query_ranges);
        auto* buf=static_cast<unsigned char*>(av_malloc(32768));if(!buf)throw std::runtime_error("Stream buffer unavailable");
        c.io=avio_alloc_context(buf,32768,0,c.reader.get(),[](void* r,uint8_t* b,int n){return static_cast<MediaReader*>(r)->read(b,n);},nullptr,[](void* r,int64_t n,int w){return static_cast<MediaReader*>(r)->seek(n,w);});
        if(!c.io){av_free(buf);throw std::runtime_error("AVIO unavailable");}c.format->pb=c.io;c.format->flags|=AVFMT_FLAG_CUSTOM_IO;
    }
    c.format->probesize=1024*1024;c.format->max_analyze_duration=5*AV_TIME_BASE;
    AVDictionary* options=nullptr;av_dict_set(&options,"protocol_whitelist","file",0);av_dict_set(&options,"enable_drefs","0",0);av_dict_set(&options,"format_whitelist","mp3,aac,mov,ogg,flac,wav,matroska,webm",0);
    int rc=avformat_open_input(&c.format,src.uri.c_str(),nullptr,&options);av_dict_free(&options);if(rc<0||avformat_find_stream_info(c.format,nullptr)<0)throw std::runtime_error("Stream open failed");
    const int stream=av_find_best_stream(c.format,AVMEDIA_TYPE_AUDIO,-1,-1,nullptr,0);if(stream<0)throw std::runtime_error("No audio stream");const auto* codec=avcodec_find_decoder(c.format->streams[stream]->codecpar->codec_id);if(!codec)throw std::runtime_error("Audio format unavailable");
    c.codec=avcodec_alloc_context3(codec);if(!c.codec||avcodec_parameters_to_context(c.codec,c.format->streams[stream]->codecpar)<0||avcodec_open2(c.codec,codec,nullptr)<0)throw std::runtime_error("Decoder open failed");
    duration=c.format->duration>0?static_cast<double>(c.format->duration)/AV_TIME_BASE:0;
    if(src.position>0){if(avformat_seek_file(c.format,-1,INT64_MIN,static_cast<int64_t>(src.position*AV_TIME_BASE),INT64_MAX,0)<0)throw std::runtime_error("Seek unavailable");avcodec_flush_buffers(c.codec);}
    std::vector<int16_t> pcm(48000*2);int input_rate=0,input_format=-1;AVChannelLayout input_layout{};
    struct LayoutCleanup {AVChannelLayout* layout;~LayoutCleanup(){av_channel_layout_uninit(layout);}} cleanup{&input_layout};
    double skip_until=src.position;bool eof=false,flush=false;
    while(!stopping&&serial==generation){
        {std::unique_lock<std::mutex> lock(mutex);cv.wait(lock,[&]{return stopping||serial!=generation||!paused;});}
        if(stopping||serial!=generation)return;
        rc=avcodec_receive_frame(c.codec,c.frame);
        if(rc==AVERROR(EAGAIN)){
            if(eof){if(!flush){avcodec_send_packet(c.codec,nullptr);flush=true;continue;}break;}
            rc=av_read_frame(c.format,c.packet);if(rc==AVERROR_EOF){eof=true;continue;}if(rc<0)throw std::runtime_error("Stream interrupted");
            if(c.packet->stream_index==stream&&avcodec_send_packet(c.codec,c.packet)<0){av_packet_unref(c.packet);throw std::runtime_error("Corrupt packet");}av_packet_unref(c.packet);continue;
        }
        if(rc==AVERROR_EOF)break;if(rc<0)throw std::runtime_error("Decoder failed");
        auto* frame=c.frame;if(frame->nb_samples<=0||frame->nb_samples>192000||frame->sample_rate<=0||frame->ch_layout.nb_channels<=0||frame->ch_layout.nb_channels>16)throw std::runtime_error("Invalid audio frame");
        double frame_time=frame->best_effort_timestamp==AV_NOPTS_VALUE?-1:static_cast<double>(frame->best_effort_timestamp)*av_q2d(c.format->streams[stream]->time_base);
        if(frame_time>=0&&frame_time+static_cast<double>(frame->nb_samples)/frame->sample_rate<skip_until){av_frame_unref(frame);continue;}
        if(!c.swr||input_rate!=frame->sample_rate||input_format!=frame->format||av_channel_layout_compare(&input_layout,&frame->ch_layout)){
            swr_free(&c.swr);av_channel_layout_uninit(&input_layout);AVChannelLayout stereo=AV_CHANNEL_LAYOUT_STEREO;
            if(swr_alloc_set_opts2(&c.swr,&stereo,AV_SAMPLE_FMT_S16,48000,&frame->ch_layout,static_cast<AVSampleFormat>(frame->format),frame->sample_rate,0,nullptr)<0||swr_init(c.swr)<0)throw std::runtime_error("Resampler failed");
            input_rate=frame->sample_rate;input_format=frame->format;av_channel_layout_copy(&input_layout,&frame->ch_layout);
        }
        int max=swr_get_out_samples(c.swr,frame->nb_samples);if(max<0||max>48000*4)throw std::runtime_error("Audio block limit");if(static_cast<size_t>(max*2)>pcm.size())pcm.resize(static_cast<size_t>(max*2));uint8_t* out=reinterpret_cast<uint8_t*>(pcm.data());int samples=swr_convert(c.swr,&out,max,const_cast<const uint8_t**>(frame->extended_data),frame->nb_samples);if(samples<0)throw std::runtime_error("Conversion failed");
        size_t skip=0;if(frame_time>=0&&frame_time<skip_until)skip=static_cast<size_t>(std::min(static_cast<double>(samples),std::ceil((skip_until-frame_time)*48000)))*2;skip_until=0;
        size_t count=static_cast<size_t>(samples)*2,at=skip;
        while(at<count&&!stopping&&serial==generation){const auto start=written.load(std::memory_order_relaxed),end=read.load(std::memory_order_acquire),limit=static_cast<uint64_t>(buffer_ms.load())*96;
            const auto queued=start-end,maximum=std::min(capacity,limit);
            const auto available=queued<maximum?maximum-queued:0;
            if(!available){std::unique_lock<std::mutex> lock(mutex);cv.wait_for(lock,std::chrono::milliseconds(20),[&]{return stopping||serial!=generation||written-read<static_cast<uint64_t>(buffer_ms.load())*96;});continue;}
            const auto amount=std::min(static_cast<uint64_t>(count-at),available);for(uint64_t i=0;i<amount;i++)ring[(start+i)%capacity]=pcm[at+i];written.store(start+amount,std::memory_order_release);at+=static_cast<size_t>(amount);loading=false;
        }
        av_frame_unref(frame);
    }
    // Drain buffered PCM before reporting track end. Pause remains interruptible.
    while(!stopping&&serial==generation&&read<written){std::unique_lock<std::mutex> lock(mutex);cv.wait_for(lock,std::chrono::milliseconds(20));}
    if(!stopping&&serial==generation){loading=false;paused=true;SDL_PauseAudioDevice(device,1);finished=true;}
}
}
