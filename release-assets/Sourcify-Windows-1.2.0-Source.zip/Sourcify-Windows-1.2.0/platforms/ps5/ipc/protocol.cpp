#include "protocol.hpp"
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <unistd.h>
#include <poll.h>
#include <chrono>
#include <cstring>
#include <stdexcept>
#include <map>
namespace sourcify {
static std::mutex local_mutex;
static std::map<std::string,std::function<Json(const Json&)>> local_handlers;
void register_local_rpc(const fs::path& path,std::function<Json(const Json&)> handler){std::lock_guard<std::mutex> lock(local_mutex);if(!handler||!local_handlers.emplace(path.string(),std::move(handler)).second)throw std::runtime_error("Local service already registered");}
void unregister_local_rpc(const fs::path& path){std::lock_guard<std::mutex> lock(local_mutex);local_handlers.erase(path.string());}
static std::function<Json(const Json&)> local_handler(const fs::path& path){std::lock_guard<std::mutex> lock(local_mutex);auto it=local_handlers.find(path.string());return it==local_handlers.end()?std::function<Json(const Json&)>{}:it->second;}
static int64_t timestamp(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();}
Json envelope(const std::string& command,Json payload){return {{"protocol_version",protocol_version},{"command",command},{"payload",std::move(payload)},{"timestamp",timestamp()}};}
void validate_request(const Json& r){
    if(!r.is_object()||r.size()!=4||r.at("protocol_version")!=protocol_version||!r.at("command").is_string()||!r.at("payload").is_object()||!r.at("timestamp").is_number_integer())throw std::runtime_error("Invalid IPC request");
    const auto command=r.at("command").get<std::string>();const auto now=timestamp(),sent=r.at("timestamp").get<int64_t>();
    if(command.empty()||command.size()>32||!std::all_of(command.begin(),command.end(),[](char c){return (c>='A'&&c<='Z')||c=='_';})||sent<now-300000||sent>now+300000)throw std::runtime_error("IPC request expired or malformed");
}
static sockaddr_un address(const fs::path& path){sockaddr_un a{};a.sun_family=AF_UNIX;const auto s=path.string();if(s.size()>=sizeof(a.sun_path))throw std::runtime_error("IPC path too long");std::memcpy(a.sun_path,s.c_str(),s.size()+1);return a;}
static void send_text(int fd,const std::string& text){size_t at=0;while(at<text.size()){auto n=send(fd,text.data()+at,text.size()-at,MSG_NOSIGNAL);if(n<=0)throw std::runtime_error("IPC disconnected");at+=static_cast<size_t>(n);}}
static std::string receive(int fd,size_t limit){std::string text;char buffer[4096];for(;;){auto n=recv(fd,buffer,sizeof(buffer),0);if(n<=0)throw std::runtime_error("IPC unavailable");text.append(buffer,static_cast<size_t>(n));if(text.size()>limit)throw std::runtime_error("IPC size limit");auto end=text.find('\n');if(end!=std::string::npos){if(end!=text.size()-1)throw std::runtime_error("IPC framing error");text.resize(end);return text;}}}
static void timeout(int fd){timeval t{2,0};setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&t,sizeof(t));setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&t,sizeof(t));}
Json rpc(const fs::path& path,const std::string& command,Json payload){if(auto handler=local_handler(path)){auto request=envelope(command,std::move(payload));validate_request(request);if(request.dump().size()>16384)throw std::runtime_error("IPC size limit");try{auto result=handler(request);if(result.dump().size()>4*1024*1024)throw std::runtime_error("IPC state too large");return result;}catch(...){throw std::runtime_error("Command failed. Check connection, input or source availability.");}}auto a=address(path);int fd=socket(AF_UNIX,SOCK_STREAM,0);if(fd<0)throw std::runtime_error("IPC socket unavailable");timeout(fd);try{if(connect(fd,reinterpret_cast<sockaddr*>(&a),sizeof(a)))throw std::runtime_error("Playback service unavailable");auto request=envelope(command,std::move(payload));send_text(fd,request.dump()+"\n");auto r=parse_json(receive(fd,4*1024*1024));close(fd);fd=-1;if(r.value("protocol_version",0)!=protocol_version)throw std::runtime_error("IPC version mismatch");if(r.contains("error"))throw std::runtime_error(r["error"].get<std::string>());return r.at("payload");}catch(...){if(fd>=0)close(fd);throw;}}
IpcServer::IpcServer(const fs::path& path,std::function<Json(const Json&)> handler):socket_path(path){
    if(fs::exists(path)){
        try{rpc(path,"GET_STATE");throw std::runtime_error("Service already running");}catch(const std::exception& e){if(std::string(e.what())=="Service already running")throw;}
        if(fs::is_symlink(path))throw std::runtime_error("Unsafe IPC path");struct stat st{};if(lstat(path.c_str(),&st)==0&&!S_ISSOCK(st.st_mode))throw std::runtime_error("IPC path occupied");unlink(path.c_str());
    }
    const auto a=address(path);listener=socket(AF_UNIX,SOCK_STREAM,0);if(listener<0)throw std::runtime_error("IPC unavailable");if(bind(listener,reinterpret_cast<const sockaddr*>(&a),sizeof(a))||listen(listener,8)){close(listener);listener=-1;throw std::runtime_error("IPC bind failed");}chmod(path.c_str(),0600);thread=std::thread([this,handler]{run(handler);});
}
IpcServer::~IpcServer(){stopping=true;if(thread.joinable())thread.join();if(listener>=0)close(listener);unlink(socket_path.c_str());}
void IpcServer::run(const std::function<Json(const Json&)>& handler){while(!stopping){pollfd p{listener,POLLIN,0};if(poll(&p,1,200)<=0)continue;int fd=accept(listener,nullptr,nullptr);if(fd<0)continue;timeout(fd);try{
        auto request=parse_json(receive(fd,16384),16384);validate_request(request);Json result={{"protocol_version",protocol_version},{"payload",handler(request)},{"timestamp",timestamp()}};auto text=result.dump();if(text.size()>4*1024*1024)throw std::runtime_error("IPC state too large");send_text(fd,text+"\n");
    }catch(const std::exception&){try{send_text(fd,Json{{"protocol_version",protocol_version},{"error","Command failed. Check connection, input or source availability."}}.dump()+"\n");}catch(...){} }close(fd);}}
}
