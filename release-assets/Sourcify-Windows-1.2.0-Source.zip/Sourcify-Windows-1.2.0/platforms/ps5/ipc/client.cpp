#include "protocol.hpp"
#include <iostream>
int main(int argc,char** argv){using namespace sourcify;try{if(argc<3){std::cerr<<"Usage: sourcify-ctl SOCKET COMMAND [JSON_PAYLOAD]\n";return 2;}auto payload=argc>3?parse_json(argv[3],8192):Json::object();auto result=rpc(argv[1],argv[2],payload);std::cout<<result.dump(2)<<'\n';return 0;}catch(...){std::cerr<<"IPC command failed\n";return 1;}}
