#pragma once
#include "storage.hpp"
#include <atomic>
#include <functional>
#include <thread>
namespace sourcify {
constexpr int protocol_version=1;
Json envelope(const std::string& command,Json payload=Json::object());
void validate_request(const Json& request);
Json rpc(const fs::path& socket,const std::string& command,Json payload=Json::object());
void register_local_rpc(const fs::path& socket,std::function<Json(const Json&)> handler);
void unregister_local_rpc(const fs::path& socket);
class IpcServer {
    int listener=-1;
    fs::path socket_path;
    std::atomic<bool> stopping{false};
    std::thread thread;
    void run(const std::function<Json(const Json&)>& handler);
public:
    IpcServer(const fs::path& path,std::function<Json(const Json&)> handler);
    ~IpcServer();
};
}
