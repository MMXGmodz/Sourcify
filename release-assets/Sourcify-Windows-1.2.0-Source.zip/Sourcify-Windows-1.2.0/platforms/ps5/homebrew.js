async function main() {
    const cwd = window.workingDir;
    return {
        mainText: 'Sourcify Player',
        secondaryText: 'Music · MMXG · Vibecoded',
        imgPath: baseURL + '/fs/' + cwd + '/assets/icon.png',
        onclick: async () => ({
            path: cwd + '/sourcify.elf', cwd,
            args: ['--assets', cwd + '/assets'],
            env: {CURL_CA_BUNDLE: cwd + '/assets/ca-bundle.crt'}
        })
    };
}
