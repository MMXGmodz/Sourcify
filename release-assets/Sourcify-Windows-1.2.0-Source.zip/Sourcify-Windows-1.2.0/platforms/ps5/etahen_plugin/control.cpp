#include "protocol.hpp"
#include "song.hpp"
#include <signal.h>
#include <set>
#include <iostream>
namespace {volatile sig_atomic_t quit=0;void handler(int){quit=1;}}
int main(){using namespace sourcify;
    try{
        signal(SIGTERM,handler);signal(SIGINT,handler);signal(SIGPIPE,SIG_IGN);Paths p;Log log(p);
        const std::set<std::string> commands={"GET_STATE","GET_QUEUE","PLAY","PAUSE","RESUME","TOGGLE_PLAYBACK","NEXT","PREVIOUS","SEEK","SET_VOLUME","SET_REPEAT","SET_SHUFFLE"};
        IpcServer server(p.root/"control.sock",[&](const Json& r){const auto command=r.at("command").get<std::string>();if(command=="PLUGIN_STATUS")return Json{{"protocol_version",1},{"plugin","Sourcify Control"},{"overlay",false},{"shortcut",false}};if(!commands.count(command))throw std::runtime_error("Unsupported control command");log.write("ETAHEN","Forwarded "+command);return rpc(p.socket(),command,r.at("payload"));});
        log.write("ETAHEN","Thin control plugin started; in-game overlay unavailable");
        std::string previous;while(!quit){try{auto state=rpc(p.socket(),"GET_STATE");log.enable(state["settings"].value("logging",true));int i=state.value("index",-1);auto current=i>=0?state["queue"].at(i).get<std::string>():"";if(current!=previous){previous=current;log.write("ETAHEN","Now Playing updated TrackID="+current);if(!current.empty()&&state["settings"].value("notifications",false)){if(!song_notification(state["tracks"].at(current),(p.root/"app/assets/icon.png").string()))log.write("ETAHEN","System notification unavailable");}}}catch(...){/* Service may start after this plugin or restart. */}std::this_thread::sleep_for(std::chrono::milliseconds(750));}
        log.write("ETAHEN","Control plugin stopped");return 0;
    }catch(...){std::cerr<<"Sourcify control plugin could not start. Check storage and IPC.\n";return 1;}
}
