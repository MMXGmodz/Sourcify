#!/usr/bin/env python3
"""etaHEN-Plugins lib/make_plugin.py wire format, without ELF modification."""
import pathlib, re, sys
if len(sys.argv) != 4:
    raise SystemExit('Usage: make_plugin.py ELF TITLE_ID VERSION')
file, title, version = sys.argv[1:]
if not re.fullmatch(r'[A-Za-z]{4}\d{5}', title) or not re.fullmatch(r'\d\.\d{2}', version):
    raise SystemExit('Invalid etaHEN title ID or version')
data = pathlib.Path(file).read_bytes()
if data[:4] != b'\x7fELF':
    raise SystemExit('Expected a real ELF executable')
pathlib.Path(file).with_suffix('.plugin').write_bytes(
    b'etaHEN_PLUGIN\0' + title.encode() + b'\0' + version.encode() + b'\0' + data)
