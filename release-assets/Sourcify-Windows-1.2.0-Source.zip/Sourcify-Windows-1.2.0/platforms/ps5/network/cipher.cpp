// Native adaptation of InnerTubeX EjsChallengeSolver and QuickJsEngine (GPL-3.0).
#include "cipher.hpp"
#include <chrono>
extern "C" {
#include "quickjs.h"
}
namespace sourcify {
Json CipherSolver::solve(const std::string& player,const std::string& signature,const std::string& n,DirectHttps::Cancel cancelled) const{
    if(player.empty()||player.size()>8*1024*1024||signature.size()>65536||n.size()>65536)throw std::runtime_error("YouTube player signature could not be resolved");
    struct Runtime {JSRuntime* rt=JS_NewRuntime();JSContext* ctx=nullptr;~Runtime(){if(ctx)JS_FreeContext(ctx);if(rt)JS_FreeRuntime(rt);}} r;
    if(!r.rt)throw std::runtime_error("Native JavaScript engine unavailable");JS_SetMemoryLimit(r.rt,192*1024*1024);JS_SetMaxStackSize(r.rt,512*1024);
    struct Budget {DirectHttps::Cancel cancelled;std::chrono::steady_clock::time_point deadline;};Budget budget{cancelled,std::chrono::steady_clock::now()+std::chrono::seconds(15)};
    JS_SetInterruptHandler(r.rt,+[](JSRuntime*,void* p){auto& b=*static_cast<Budget*>(p);return (b.cancelled&&b.cancelled())||std::chrono::steady_clock::now()>b.deadline?1:0;},&budget);r.ctx=JS_NewContext(r.rt);if(!r.ctx)throw std::runtime_error("Native JavaScript context unavailable");
    auto eval=[&](const std::string& script,bool result=false){JS_UpdateStackTop(r.rt);JSValue v=JS_Eval(r.ctx,script.data(),script.size(),"native-player",JS_EVAL_TYPE_GLOBAL);if(JS_IsException(v)){JS_FreeValue(r.ctx,v);JSValue e=JS_GetException(r.ctx);JS_FreeValue(r.ctx,e);throw std::runtime_error("YouTube player signature could not be resolved");}std::string out;if(result){size_t size=0;const char* text=JS_ToCStringLen(r.ctx,&size,v);if(!text||size>256*1024){if(text)JS_FreeCString(r.ctx,text);JS_FreeValue(r.ctx,v);throw std::runtime_error("Invalid player solver result");}out.assign(text,size);JS_FreeCString(r.ctx,text);}JS_FreeValue(r.ctx,v);return out;};
    eval("globalThis.XMLHttpRequest={prototype:{}};globalThis.location={hash:'',host:'www.youtube.com',hostname:'www.youtube.com',href:'https://www.youtube.com/watch?v=yt-dlp-wins',origin:'https://www.youtube.com',pathname:'/watch',protocol:'https:',search:'?v=yt-dlp-wins'};globalThis.document=Object.create(null);globalThis.navigator=Object.create(null);globalThis.self=globalThis;globalThis.window=globalThis;");
    eval(R"INTL(                if (typeof globalThis.Intl === "undefined") {
                    const NumberFormat = function(locale, options) {
                        this.options = options || {};
                    };
                    NumberFormat.supportedLocalesOf = function(locales) {
                        return Array.isArray(locales) ? locales : [locales];
                    };
                    NumberFormat.prototype.format = function(value) {
                        let formatted = String(value);
                        const minimumDigits = this.options.minimumIntegerDigits || 0;
                        while (formatted.length < minimumDigits) formatted = "0" + formatted;
                        return formatted;
                    };
                    const DateTimeFormat = function() {};
                    DateTimeFormat.prototype.resolvedOptions = function() {
                        return { timeZone: "UTC" };
                    };
                    DateTimeFormat.prototype.format = function(value) {
                        return String(value);
                    };
                    globalThis.Intl = { NumberFormat, DateTimeFormat };
                }
)INTL");
    eval(read_file(assets/"yt_ejs/yt.solver.lib.min.js",512*1024));eval("Object.assign(globalThis,lib);");eval(read_file(assets/"yt_ejs/yt.solver.core.min.js",512*1024));
    Json requests=Json::array();if(!signature.empty())requests.push_back({{"type","sig"},{"challenges",Json::array({signature})}});if(!n.empty())requests.push_back({{"type","n"},{"challenges",Json::array({n})}});
    Json payload={{"type","player"},{"player",player},{"output_preprocessed",false},{"requests",requests}};
    auto raw=eval("(function(){var r=jsc("+payload.dump()+");if(!r||r.type!=='result')throw Error('solver');var out=[];for(var i=0;i<r.responses.length;i++){var q=r.responses[i],plain={};if(q.type!=='result')throw Error('challenge');for(var k of Object.keys(q.data)){var v=String(q.data[k]);if(v.length>65536)throw Error('limit');plain[k]=v;}out.push(plain);}return JSON.stringify(out);})()",true);
    auto out=parse_json(raw,256*1024);if(!out.is_array()||out.size()!=requests.size())throw std::runtime_error("Invalid player solver response");Json solved=Json::object();size_t at=0;for(const auto& request:requests){const auto& challenge=request["challenges"][0].get_ref<const std::string&>();if(!out[at].contains(challenge)||!out[at][challenge].is_string()||out[at][challenge].get<std::string>().empty())throw std::runtime_error("YouTube player signature could not be resolved");solved[request["type"].get<std::string>()]=out[at++][challenge];}return solved;
}
}
