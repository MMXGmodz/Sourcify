#pragma once
#include "http.hpp"
#include <curl/curl.h>
namespace sourcify {
enum class UrlRole {Api,Page,Script,Cover,Media};
bool approved_youtube_url(const std::string&,UrlRole);
std::string url_parameter(const std::string&,const std::string&);
std::string set_url_parameter(const std::string&,const std::string&,const std::string&);
// Host-only test routing is compiled out of the PS5 target; TLS still checks the original host.
void native_test_route(CURL*,const std::string&,curl_slist*&);
struct DirectResponse {long status=0;std::string body;};
class DirectHttps {
public:
    using Cancel=std::function<bool()>;
    std::string ca;
    Cancel cancelled;
    DirectHttps(std::string certificate,Cancel cancel):ca(std::move(certificate)),cancelled(std::move(cancel)){}
    DirectResponse request(const std::string& url,UrlRole role,const std::string& body="",const std::vector<std::string>& headers={},size_t limit=8*1024*1024,Cancel operation_cancel={}) const;
    void cover(const std::string& url,const fs::path& file) const;
};
}
