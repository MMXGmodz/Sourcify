#pragma once
#include "storage.hpp"
#include <atomic>
#include <functional>
#include <condition_variable>
#include <thread>
#include <deque>
namespace sourcify {
bool safe_bridge(const std::string& url);
class Http {
public:
    std::string base,token,ca;
    std::atomic<bool>* shutdown=nullptr;
    Http(const Settings& s,const std::string& bundled_ca,std::atomic<bool>* shutdown=nullptr);
    Json get(const std::string& endpoint) const;
    Json pair(const std::string& code) const;
    std::string encoded(const std::string& value) const;
    void download(const std::string& endpoint,const fs::path& file,bool resume,
                  uint64_t limit,std::atomic<bool>& stop,const std::function<void(uint64_t,uint64_t)>& progress={}) const;
};
class Worker {
    std::mutex mutex;
    std::condition_variable cv;
    std::deque<std::function<void()>> jobs;
    bool stopping=false;
    std::thread thread;
public:
    Worker();~Worker();
    bool submit(std::function<void()> job);
};
}
