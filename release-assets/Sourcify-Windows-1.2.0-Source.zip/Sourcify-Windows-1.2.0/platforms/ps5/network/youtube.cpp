// Request profiles and search renderer parsing adapted from existing Sourcify/InnerTubeX.
#include "youtube.hpp"
#include <regex>
#include <set>
#include <algorithm>
#include <fcntl.h>
#include <unistd.h>
#include <array>
namespace sourcify {
namespace {
std::string text(const Json& j,size_t maximum=300){if(!j.is_string())return "";auto s=j.get<std::string>();if(s.find('\0')!=std::string::npos)return "";if(s.size()>maximum){size_t end=maximum;while(end>0&&(static_cast<unsigned char>(s[end])&0xc0)==0x80)end--;s.resize(end);}return s;}
const Json& field(const Json& j,const char* name){static const Json absent;return j.is_object()&&j.contains(name)?j[name]:absent;}
const Json& path(const Json& j,std::initializer_list<const char*> names){const Json* item=&j;for(auto name:names)item=&field(*item,name);return *item;}
std::string runs(const Json& j){auto simple=text(field(j,"simpleText"));if(!simple.empty())return simple;std::string out;auto list=field(j,"runs");if(list.is_array())for(const auto& run:list)out+=text(field(run,"text"));return text(Json(out));}
double seconds(const std::string& value){if(value.empty()||value.size()>12)return 0;double total=0;size_t at=0;int parts=0;while(at<value.size()){size_t end=value.find(':',at);if(end==std::string::npos)end=value.size();auto token=value.substr(at,end-at);if(token.empty()||token.size()>5||!std::all_of(token.begin(),token.end(),[](char c){return c>='0'&&c<='9';}))return 0;int n=std::stoi(token);if(parts>0&&n>59)return 0;total=total*60+n;parts++;at=end+1;}return parts>=2&&total<=86400?total:0;}
int64_t integer_string(const Json& value){if(value.is_number_integer()){auto n=value.get<int64_t>();return n>=0?n:0;}auto s=text(value,24);if(s.empty()||s.size()>12||!std::all_of(s.begin(),s.end(),[](char c){return c>='0'&&c<='9';}))return 0;try{return std::stoll(s);}catch(...){return 0;}}
std::string thumbnail(const Json& renderer){
    const Json* list=&path(renderer,{"thumbnail","musicThumbnailRenderer","thumbnail","thumbnails"});if(!list->is_array())list=&path(renderer,{"thumbnail","thumbnails"});
    std::string best;int width=-1;if(list->is_array())for(const auto& item:*list){auto url=text(field(item,"url"),2048);int w=field(item,"width").is_number_integer()?std::clamp(field(item,"width").get<int>(),0,4096):0;if(approved_youtube_url(url,UrlRole::Cover)&&w>=width&&w<=1200){best=url;width=w;}}return best;
}
std::string video_id(const Json& renderer){for(auto endpoint:{path(renderer,{"playlistItemData","videoId"}),path(renderer,{"navigationEndpoint","watchEndpoint","videoId"}),path(renderer,{"overlay","musicItemThumbnailOverlayRenderer","content","musicPlayButtonRenderer","playNavigationEndpoint","watchEndpoint","videoId"}),field(renderer,"videoId")}){auto id=text(endpoint,42);if(id.size()==11&&valid_id(id))return id;}return "";}
Track music_item(const Json& r){Track t;t.id=video_id(r);const auto& columns=field(r,"flexColumns");if(t.id.empty()||!columns.is_array()||columns.empty())return t;
    t.title=runs(path(columns[0],{"musicResponsiveListItemFlexColumnRenderer","text"}));if(t.id.empty())return t;
    if(columns.size()>1){const auto& metadata=path(columns[1],{"musicResponsiveListItemFlexColumnRenderer","text","runs"});std::string fallback;
        if(metadata.is_array())for(const auto& run:metadata){auto label=text(field(run,"text"),200);auto browse=path(run,{"navigationEndpoint","browseEndpoint"});auto id=text(field(browse,"browseId"),100);auto type=text(path(browse,{"browseEndpointContextSupportedConfigs","browseEndpointContextMusicConfig","pageType"}),100);
            if(id.rfind("UC",0)==0||type=="MUSIC_PAGE_TYPE_ARTIST"){if(!t.artist.empty())t.artist+=", ";t.artist+=label;}
            else if(id.rfind("MPRE",0)==0||type=="MUSIC_PAGE_TYPE_ALBUM")t.album=label;
            else if(seconds(label)>0)t.duration=seconds(label);
            else if(fallback.empty()&&label!=" · "&&label!="•"&&label!="Song"&&label!="Video"&&label!="Titel"&&label!="Lied")fallback=label;
        }if(t.artist.empty())t.artist=fallback;
    }
    const auto& fixed=field(r,"fixedColumns");if(fixed.is_array())for(const auto& column:fixed){auto time=runs(path(column,{"musicResponsiveListItemFixedColumnRenderer","text"}));if(seconds(time)>0)t.duration=seconds(time);}
    t.artist=text(Json(t.artist),200);t.thumbnail=thumbnail(r);t.kind="youtube";return t;
}
}
std::vector<Track> parse_youtube_search(const Json& response){
    if(!response.is_object()||response.contains("error"))throw std::runtime_error("Invalid YouTube search response");std::vector<Track> out;std::set<std::string> ids;size_t visited=0;
    std::function<void(const Json&,int)> walk=[&](const Json& j,int depth){if(depth>32||++visited>50000)throw std::runtime_error("YouTube response nesting limit");if(out.size()>=50)return;
        if(j.is_object()){if(j.contains("musicResponsiveListItemRenderer")){auto t=music_item(j["musicResponsiveListItemRenderer"]);if(!t.id.empty()&&!t.title.empty()&&ids.insert(t.id).second)out.push_back(Track::parse(t.json()));return;}
            if(j.contains("videoRenderer")){auto r=j["videoRenderer"];Track t;t.id=video_id(r);t.title=runs(field(r,"title"));t.artist=runs(field(r,"ownerText"));t.duration=seconds(runs(field(r,"lengthText")));t.thumbnail=thumbnail(r);t.kind="youtube";if(!t.id.empty()&&!t.title.empty()&&ids.insert(t.id).second)out.push_back(Track::parse(t.json()));return;}
            for(const auto& entry:j.items())walk(entry.value(),depth+1);
        }else if(j.is_array())for(const auto& entry:j)walk(entry,depth+1);
    };walk(response,0);return out;
}
Track parse_youtube_metadata(const Json& response,const std::string& id){const auto& details=field(response,"videoDetails");if(!details.is_object()||text(field(details,"videoId"),42)!=id)throw std::runtime_error("YouTube metadata ID mismatch");Track t;t.id=id;t.title=text(field(details,"title"));t.artist=text(field(details,"author"),200);t.thumbnail=thumbnail(details);t.duration=static_cast<double>(integer_string(field(details,"lengthSeconds")));t.kind="youtube";return Track::parse(t.json());}
std::string youtube_player_script_url(const std::string& html){if(html.size()>8*1024*1024)throw std::runtime_error("Player page too large");std::regex pattern(R"(/s/player/[A-Za-z0-9_./-]+/base\.js)");std::smatch match;if(!std::regex_search(html,match,pattern))throw std::runtime_error("YouTube player signature could not be resolved");auto url="https://www.youtube.com"+match.str();if(!approved_youtube_url(url,UrlRole::Script))throw std::runtime_error("Invalid player script URL");return url;}
Json NativeYouTube::api(const std::string& endpoint,const Json& client,int client_id,const std::string& user_agent,Json payload,const std::string& language,DirectHttps::Cancel cancel){auto context=client;context["hl"]=language;context["gl"]="DE";std::vector<std::string> headers={"Accept: application/json","X-Goog-Api-Format-Version: 1","X-YouTube-Client-Name: "+std::to_string(client_id),"X-YouTube-Client-Version: "+client.at("clientVersion").get<std::string>(),"User-Agent: "+user_agent,"Origin: https://music.youtube.com","Referer: https://music.youtube.com/"};{
    std::lock_guard<std::mutex> lock(mutex);if(!visitor.empty()){context["visitorData"]=visitor;headers.push_back("X-Goog-Visitor-Id: "+visitor);}}
    payload["context"]={{"client",context},{"user",{{"lockedSafetyMode",false}}}};auto r=https.request("https://music.youtube.com/youtubei/v1/"+endpoint+"?prettyPrint=false",UrlRole::Api,payload.dump(),headers,8*1024*1024,cancel);auto j=parse_json(r.body,8*1024*1024);auto value=text(path(j,{"responseContext","visitorData"}),2048);if(!value.empty()&&value.find_first_of("\r\n")==std::string::npos){std::lock_guard<std::mutex> lock(mutex);visitor=value;}return j;
}
std::vector<Track> NativeYouTube::search(const std::string& query,const std::string& language){if(query.empty()||query.size()>200||query.find('\0')!=std::string::npos)throw std::runtime_error("Invalid search");auto j=api("search",{{"clientName","WEB_REMIX"},{"clientVersion","1.20260707.12.00"}},67,"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0",{{"query",query},{"params","EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D"}},language,{});return parse_youtube_search(j);}
std::string NativeYouTube::player_script(const std::string& id,DirectHttps::Cancel cancel){
    {std::lock_guard<std::mutex> lock(mutex);if(!script.empty())return script;}
    auto page=https.request("https://www.youtube.com/watch?v="+id,UrlRole::Page,"",{},8*1024*1024,cancel);auto url=youtube_player_script_url(page.body);auto js=https.request(url,UrlRole::Script,"",{},8*1024*1024,cancel).body;
    {std::lock_guard<std::mutex> lock(mutex);script_url=url;script=js;}return js;
}
NativeMedia NativeYouTube::resolve(const std::string& id,const std::string& language,DirectHttps::Cancel cancel,bool refresh){
    if(id.size()!=11||!valid_id(id))throw std::runtime_error("Native playback needs a YouTube song");{
        std::lock_guard<std::mutex> lock(mutex);auto found=cache.find(id);if(!refresh&&found!=cache.end()&&found->second.expires>std::chrono::steady_clock::now())return found->second.media;
        if(refresh){script.clear();script_url.clear();cache.erase(id);}}
    const Json vision={{"clientName","VISIONOS"},{"clientVersion","1.02"},{"deviceMake","Apple"},{"deviceModel","RealityDevice17,1"},{"osName","visionOS"},{"osVersion","26.5.23O471"}};
    const Json vr={{"clientName","ANDROID_VR"},{"clientVersion","1.43.32"},{"deviceMake","Oculus"},{"deviceModel","Quest 3"},{"androidSdkVersion",32},{"osName","Android"},{"osVersion","12"}};
    std::string failure="YouTube returned no playable audio";
    for(int client=0;client<2;client++)try{
        if(https.cancelled()||(cancel&&cancel()))throw std::runtime_error("YouTube request cancelled");
        auto user_agent=client?"com.google.android.apps.youtube.vr.oculus/1.43.32 (Linux; U; Android 12; en_US; Quest 3; Build/SQ3A.220605.009.A1; Cronet/107.0.5284.2)":"Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15";
        auto j=api("player",client?vr:vision,client?28:101,user_agent,{{"videoId",id},{"contentCheckOk",true},{"racyCheckOk",true}},language,cancel);
        auto status=text(path(j,{"playabilityStatus","status"}),80);if(status!="OK")throw std::runtime_error("YouTube rejected playback; login or verification required");
        if(field(field(j,"videoDetails"),"isLiveContent").is_boolean()&&j["videoDetails"]["isLiveContent"].get<bool>())throw std::runtime_error("Live streams are not supported");
        NativeMedia media;media.track=parse_youtube_metadata(j,id);media.client=client?"ANDROID_VR":"VISIONOS";media.query_ranges=client!=0;
        auto formats=path(j,{"streamingData","adaptiveFormats"});if(!formats.is_array()||formats.size()>256)throw std::runtime_error("YouTube returned no playable audio");
        std::vector<Json> choices;for(const auto& format:formats){auto mime=text(field(format,"mimeType"),200);auto length=integer_string(field(format,"contentLength"));if(mime.rfind("audio/",0)==0&&(mime.find("mp4")!=std::string::npos||mime.find("webm")!=std::string::npos)&&length>0&&length<=512*1024*1024)choices.push_back(format);}
        std::sort(choices.begin(),choices.end(),[](const Json& a,const Json& b){return integer_string(field(a,"bitrate"))>integer_string(field(b,"bitrate"));});
        for(const auto& format:choices)try{
            auto url=text(field(format,"url"),16384);std::string sig,sp="signature";auto encrypted=text(field(format,"signatureCipher"),20000);if(encrypted.empty())encrypted=text(field(format,"cipher"),20000);
            if(url.empty()&&!encrypted.empty()){auto query="https://www.youtube.com/?"+encrypted;url=url_parameter(query,"url");sig=url_parameter(query,"s");auto key=url_parameter(query,"sp");if(!key.empty()){if(key.size()>32||!std::all_of(key.begin(),key.end(),[](unsigned char c){return std::isalnum(c)||c=='_';}))throw std::runtime_error("Invalid signature parameter");sp=key;}}
            if(!approved_youtube_url(url,UrlRole::Media))continue;auto n=url_parameter(url,"n");if(!sig.empty()||!n.empty()){auto solved=cipher.solve(player_script(id,cancel),sig,n,[&]{return https.cancelled()||(cancel&&cancel());});if(!sig.empty())url=set_url_parameter(url,sp,solved.at("sig").get<std::string>());if(!n.empty())url=set_url_parameter(url,"n",solved.at("n").get<std::string>());}
            if(!approved_youtube_url(url,UrlRole::Media))continue;media.uri=url;media.length=integer_string(field(format,"contentLength"));media.itag=std::to_string(integer_string(field(format,"itag")));media.last_modified=text(field(format,"lastModified"),30);
            // Validate one bounded byte before marking a stream playable. No full-file probe.
            MediaReader probe(url,"",https.ca,[&]{return https.cancelled()||(cancel&&cancel());},media.length,media.query_ranges);uint8_t byte;if(probe.read(&byte,1)!=1)throw std::runtime_error("YouTube stream rejected; retry or use offline music");
            int64_t ttl=integer_string(path(j,{"streamingData","expiresInSeconds"}));ttl=std::clamp<int64_t>(ttl>0?ttl-60:300,15,600);{std::lock_guard<std::mutex> lock(mutex);if(cache.size()>=64)cache.erase(cache.begin());cache[id]={media,std::chrono::steady_clock::now()+std::chrono::seconds(ttl)};}return media;
        }catch(const std::exception& e){failure=e.what();if(https.cancelled()||(cancel&&cancel()))throw;}
    }catch(const std::exception& e){failure=e.what();if(https.cancelled()||(cancel&&cancel()))throw;}
    throw std::runtime_error(failure);
}
void NativeYouTube::download(const NativeMedia& media,const fs::path& file,std::atomic<bool>& cancel,const std::function<void(uint64_t,uint64_t)>& progress) const{
    if(!approved_youtube_url(media.uri,UrlRole::Media)||media.length<=0||media.length>512*1024*1024)throw std::runtime_error("Invalid native download");
    auto metadata=file.string()+".json";const Json identity={{"id",media.track.id},{"itag",media.itag},{"bytes",media.length},{"last_modified",media.last_modified}};int64_t offset=0;
    if(fs::exists(file)&&!fs::is_symlink(file))try{if(parse_json(read_file(metadata,4096))==identity)offset=static_cast<int64_t>(fs::file_size(file));}catch(...){}
    if(offset<0||offset>media.length)offset=0;atomic_file(metadata,identity.dump());
    int fd=open(file.c_str(),O_WRONLY|O_CREAT|O_NOFOLLOW|(offset?O_APPEND:O_TRUNC),0600);if(fd<0)throw std::runtime_error("Download storage unavailable");
    try{MediaReader reader(media.uri,"",https.ca,[&]{return cancel.load()||https.cancelled();},media.length,media.query_ranges);if(reader.seek(offset,SEEK_SET)!=offset)throw std::runtime_error("Download resume failed");std::array<uint8_t,65536> bytes{};
        while(offset<media.length){int count=reader.read(bytes.data(),static_cast<int>(std::min<int64_t>(bytes.size(),media.length-offset)));if(count<=0)throw std::runtime_error("Download interrupted");size_t at=0;while(at<static_cast<size_t>(count)){auto n=write(fd,bytes.data()+at,static_cast<size_t>(count)-at);if(n<=0)throw std::runtime_error("Download storage full");at+=static_cast<size_t>(n);}offset+=count;if(progress)progress(static_cast<uint64_t>(offset),static_cast<uint64_t>(media.length));}
        if(fsync(fd)!=0)throw std::runtime_error("Download flush failed");close(fd);
    }catch(...){close(fd);throw;}
}
}
