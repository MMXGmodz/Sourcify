#include "http.hpp"
#include <curl/curl.h>
#include <arpa/inet.h>
#include <stdexcept>
#include <fstream>
#include <fcntl.h>
#include <unistd.h>
#include <algorithm>
namespace sourcify {
bool safe_bridge(const std::string& url) {
    CURLU* u=curl_url();if(!u)return false;bool valid=false;
    if(curl_url_set(u,CURLUPART_URL,url.c_str(),0)==CURLUE_OK){char *scheme=nullptr,*host=nullptr,*user=nullptr,*query=nullptr,*fragment=nullptr,*path=nullptr;
        curl_url_get(u,CURLUPART_SCHEME,&scheme,0);curl_url_get(u,CURLUPART_HOST,&host,0);curl_url_get(u,CURLUPART_USER,&user,0);curl_url_get(u,CURLUPART_QUERY,&query,0);curl_url_get(u,CURLUPART_FRAGMENT,&fragment,0);curl_url_get(u,CURLUPART_PATH,&path,0);
        if(scheme&&host&&!user&&!query&&!fragment&&path&&std::string(path)=="/"){
            valid=std::string(scheme)=="https";
            if(std::string(scheme)=="http"){in_addr address{};if(inet_pton(AF_INET,host,&address)==1){uint32_t n=ntohl(address.s_addr);valid=(n>>24)==10||(n>>24)==127||(n>>16)==0xc0a8||((n>>20)==0xac1);}}
        }
        for(char* p:{scheme,host,user,query,fragment,path})curl_free(p);
    }curl_url_cleanup(u);return valid;
}
Http::Http(const Settings& s,const std::string& bundled_ca,std::atomic<bool>* cancel):base(s.bridge),token(s.token),ca(s.ca_file.empty()?bundled_ca:s.ca_file),shutdown(cancel){while(base.size()>1&&base.back()=='/')base.pop_back();if(!safe_bridge(base))throw std::runtime_error("Use HTTPS or a private IPv4 companion address");}
struct Request {
    CURL* curl=curl_easy_init();curl_slist* headers=nullptr;
    Request(const Http& h,const std::string& endpoint){if(!curl)throw std::runtime_error("HTTP initialization failed");curl_easy_setopt(curl,CURLOPT_URL,(h.base+endpoint).c_str());curl_easy_setopt(curl,CURLOPT_PROTOCOLS_STR,"http,https");curl_easy_setopt(curl,CURLOPT_FOLLOWLOCATION,0L);curl_easy_setopt(curl,CURLOPT_SSL_VERIFYPEER,1L);curl_easy_setopt(curl,CURLOPT_SSL_VERIFYHOST,2L);curl_easy_setopt(curl,CURLOPT_CAINFO,h.ca.c_str());curl_easy_setopt(curl,CURLOPT_CONNECTTIMEOUT,8L);curl_easy_setopt(curl,CURLOPT_NOSIGNAL,1L);curl_easy_setopt(curl,CURLOPT_LOW_SPEED_LIMIT,128L);curl_easy_setopt(curl,CURLOPT_LOW_SPEED_TIME,20L);headers=curl_slist_append(headers,("Authorization: Bearer "+h.token).c_str());headers=curl_slist_append(headers,"Accept: application/json");curl_easy_setopt(curl,CURLOPT_HTTPHEADER,headers);}
    ~Request(){curl_slist_free_all(headers);curl_easy_cleanup(curl);}
};
static size_t append(char* data,size_t size,size_t count,void* ptr){auto& s=*static_cast<std::string*>(ptr);size_t n=size*count;if(s.size()+n>4*1024*1024)return 0;s.append(data,n);return n;}
Json Http::get(const std::string& endpoint) const {
    for(int attempt=0;attempt<3;attempt++){
        Request r(*this,endpoint);std::string body;curl_easy_setopt(r.curl,CURLOPT_TIMEOUT,100L);curl_easy_setopt(r.curl,CURLOPT_WRITEFUNCTION,append);curl_easy_setopt(r.curl,CURLOPT_WRITEDATA,&body);
        if(shutdown){curl_easy_setopt(r.curl,CURLOPT_NOPROGRESS,0L);curl_easy_setopt(r.curl,CURLOPT_XFERINFODATA,shutdown);curl_easy_setopt(r.curl,CURLOPT_XFERINFOFUNCTION,+[](void* p,curl_off_t,curl_off_t,curl_off_t,curl_off_t){return static_cast<std::atomic<bool>*>(p)->load()?1:0;});}
        auto rc=curl_easy_perform(r.curl);long code=0;curl_easy_getinfo(r.curl,CURLINFO_RESPONSE_CODE,&code);
        if(shutdown&&shutdown->load())throw std::runtime_error("Request cancelled");
        if(rc==CURLE_OK&&code==200){auto j=parse_json(body);if(j.value("protocol_version",0)!=1)throw std::runtime_error("Companion version mismatch");return j;}
        if(code==401||code==403)throw std::runtime_error("Pair console with companion");
        if(code==400||code==404)throw std::runtime_error("Source unavailable");
        if(attempt==2)throw std::runtime_error("Companion unreachable or request failed");
        std::this_thread::sleep_for(std::chrono::milliseconds(250*(attempt+1)));
    }throw std::runtime_error("Network failed");
}
Json Http::pair(const std::string& code) const{if(code.size()!=8||!std::all_of(code.begin(),code.end(),[](char c){return c>='0'&&c<='9';}))throw std::runtime_error("Eight digit pairing code required");Request r(*this,"/v1/pair");std::string body;auto payload=Json{{"code",code}}.dump();curl_easy_setopt(r.curl,CURLOPT_POSTFIELDS,payload.c_str());curl_easy_setopt(r.curl,CURLOPT_TIMEOUT,10L);curl_easy_setopt(r.curl,CURLOPT_WRITEFUNCTION,append);curl_easy_setopt(r.curl,CURLOPT_WRITEDATA,&body);auto rc=curl_easy_perform(r.curl);long status=0;curl_easy_getinfo(r.curl,CURLINFO_RESPONSE_CODE,&status);if(rc!=CURLE_OK||status!=200)throw std::runtime_error("Pairing failed or expired");auto j=parse_json(body,4096);Settings validation;validation.apply(Json{{"token",j.at("token")}});return j;}
std::string Http::encoded(const std::string& value) const{char* e=curl_easy_escape(nullptr,value.c_str(),static_cast<int>(value.size()));if(!e)throw std::runtime_error("Encoding failed");std::string result=e;curl_free(e);return result;}
struct Transfer {int fd=-1;uint64_t bytes=0,limit=0,offset=0;std::atomic<bool>* stop;std::function<void(uint64_t,uint64_t)> progress;long status=0;bool range_ok=false;};
static size_t transfer_header(char* data,size_t size,size_t count,void* ptr){auto& t=*static_cast<Transfer*>(ptr);std::string line(data,size*count);if(line.rfind("HTTP/",0)==0){auto at=line.find(' ');t.status=at==std::string::npos?0:std::strtol(line.c_str()+at+1,nullptr,10);t.range_ok=t.offset==0;}
    if(line.rfind("Content-Range:",0)==0||line.rfind("content-range:",0)==0){auto pos=line.find("bytes ");if(pos!=std::string::npos)t.range_ok=std::strtoull(line.c_str()+pos+6,nullptr,10)==t.offset;}return size*count;}
static size_t transfer_write(char* data,size_t size,size_t count,void* ptr){auto& t=*static_cast<Transfer*>(ptr);size_t n=size*count;if(t.stop->load()||t.bytes+n>t.limit||!(t.status==200||t.status==206)||(t.offset>0&&(t.status!=206||!t.range_ok)))return 0;size_t at=0;while(at<n){auto got=write(t.fd,data+at,n-at);if(got<=0)return 0;at+=static_cast<size_t>(got);}t.bytes+=n;return n;}
static int transfer_progress(void* ptr,curl_off_t total,curl_off_t done,curl_off_t,curl_off_t){auto& t=*static_cast<Transfer*>(ptr);if(t.progress)t.progress(t.offset+static_cast<uint64_t>(done),total>0?t.offset+static_cast<uint64_t>(total):0);return t.stop->load()?1:0;}
void Http::download(const std::string& endpoint,const fs::path& file,bool resume,uint64_t limit,std::atomic<bool>& stop,const std::function<void(uint64_t,uint64_t)>& progress) const {
    uint64_t offset=resume&&fs::exists(file)?fs::file_size(file):0;if(offset>=limit)throw std::runtime_error("Download size limit");Request r(*this,endpoint);Transfer t;t.bytes=offset;t.offset=offset;t.limit=limit;t.stop=&stop;t.progress=progress;t.fd=open(file.c_str(),O_WRONLY|O_CREAT|O_NOFOLLOW|(offset?O_APPEND:O_TRUNC),0600);if(t.fd<0)throw std::runtime_error("Download storage unavailable");
    if(offset)curl_easy_setopt(r.curl,CURLOPT_RESUME_FROM_LARGE,static_cast<curl_off_t>(offset));curl_easy_setopt(r.curl,CURLOPT_TIMEOUT,1800L);curl_easy_setopt(r.curl,CURLOPT_WRITEFUNCTION,transfer_write);curl_easy_setopt(r.curl,CURLOPT_WRITEDATA,&t);curl_easy_setopt(r.curl,CURLOPT_HEADERFUNCTION,transfer_header);curl_easy_setopt(r.curl,CURLOPT_HEADERDATA,&t);curl_easy_setopt(r.curl,CURLOPT_NOPROGRESS,0L);curl_easy_setopt(r.curl,CURLOPT_XFERINFOFUNCTION,transfer_progress);curl_easy_setopt(r.curl,CURLOPT_XFERINFODATA,&t);auto rc=curl_easy_perform(r.curl);long code=0;curl_easy_getinfo(r.curl,CURLINFO_RESPONSE_CODE,&code);const bool synced=fsync(t.fd)==0;close(t.fd);
    if(offset&&code==200&&!stop){fs::remove(file);download(endpoint,file,false,limit,stop,progress);return;}
    if(rc!=CURLE_OK||!(code==200||code==206)||!synced)throw std::runtime_error(stop?"Download cancelled":"Download incomplete; retry to resume");
}
Worker::Worker():thread([this]{for(;;){std::function<void()> job;{std::unique_lock<std::mutex> lock(mutex);cv.wait(lock,[this]{return stopping||!jobs.empty();});if(stopping)return;job=std::move(jobs.front());jobs.pop_front();}try{job();}catch(...){}}}){}
Worker::~Worker(){{std::lock_guard<std::mutex> lock(mutex);stopping=true;jobs.clear();}cv.notify_all();if(thread.joinable())thread.join();}
bool Worker::submit(std::function<void()> job){{std::lock_guard<std::mutex> lock(mutex);if(stopping||jobs.size()>=16)return false;jobs.push_back(std::move(job));}cv.notify_one();return true;}
}
