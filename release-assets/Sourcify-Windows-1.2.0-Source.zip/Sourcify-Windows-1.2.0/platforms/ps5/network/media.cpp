#include "media.hpp"
#include "direct.hpp"
#include <stdexcept>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <thread>
#include <chrono>
extern "C" {
#include <libavformat/avio.h>
#include <libavutil/error.h>
}
namespace sourcify {
static constexpr size_t chunk=256*1024;
MediaReader::MediaReader(const std::string& uri,const std::string& auth,const std::string& ca,std::function<bool()> stop,int64_t content_length,bool use_query_ranges):uri(uri),query_ranges(use_query_ranges),cancelled(std::move(stop)){
    curl=curl_easy_init();if(!curl)throw std::runtime_error("Media HTTP unavailable");buffer.reserve(chunk);
    if(!auth.empty())headers=curl_slist_append(nullptr,auth.c_str());curl_easy_setopt(curl,CURLOPT_HTTPHEADER,headers);curl_easy_setopt(curl,CURLOPT_URL,uri.c_str());curl_easy_setopt(curl,CURLOPT_PROTOCOLS_STR,"http,https");curl_easy_setopt(curl,CURLOPT_FOLLOWLOCATION,0L);curl_easy_setopt(curl,CURLOPT_SSL_VERIFYPEER,1L);curl_easy_setopt(curl,CURLOPT_SSL_VERIFYHOST,2L);curl_easy_setopt(curl,CURLOPT_CAINFO,ca.c_str());curl_easy_setopt(curl,CURLOPT_CONNECTTIMEOUT,8L);curl_easy_setopt(curl,CURLOPT_TIMEOUT,100L);curl_easy_setopt(curl,CURLOPT_LOW_SPEED_LIMIT,128L);curl_easy_setopt(curl,CURLOPT_LOW_SPEED_TIME,20L);curl_easy_setopt(curl,CURLOPT_NOSIGNAL,1L);curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,write);curl_easy_setopt(curl,CURLOPT_WRITEDATA,this);curl_easy_setopt(curl,CURLOPT_HEADERFUNCTION,header);curl_easy_setopt(curl,CURLOPT_HEADERDATA,this);curl_easy_setopt(curl,CURLOPT_NOPROGRESS,0L);curl_easy_setopt(curl,CURLOPT_XFERINFOFUNCTION,progress);curl_easy_setopt(curl,CURLOPT_XFERINFODATA,this);
    try{native_test_route(curl,uri,route);if(content_length>0){if(content_length>512*1024*1024)throw std::runtime_error("Media size limit");total=content_length;return;}perform(true);curl_off_t size=-1;curl_easy_getinfo(curl,CURLINFO_CONTENT_LENGTH_DOWNLOAD_T,&size);if(size<=0||size>512*1024*1024)throw std::runtime_error("Media length unavailable or too large");total=size;}catch(...){curl_slist_free_all(headers);curl_slist_free_all(route);curl_easy_cleanup(curl);curl=nullptr;headers=nullptr;throw;}
}
MediaReader::~MediaReader(){curl_slist_free_all(headers);curl_slist_free_all(route);curl_easy_cleanup(curl);}
int MediaReader::progress(void* ptr,curl_off_t,curl_off_t,curl_off_t,curl_off_t){return static_cast<MediaReader*>(ptr)->cancelled()?1:0;}
size_t MediaReader::write(char* data,size_t size,size_t count,void* ptr){auto* self=static_cast<MediaReader*>(ptr);size_t n=size*count;if(self->cancelled()||self->buffer.size()+n>chunk)return 0;self->buffer.insert(self->buffer.end(),reinterpret_cast<uint8_t*>(data),reinterpret_cast<uint8_t*>(data)+n);return n;}
size_t MediaReader::header(char* data,size_t size,size_t count,void* ptr){auto& self=*static_cast<MediaReader*>(ptr);std::string line(data,size*count);std::transform(line.begin(),line.end(),line.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});if(line.rfind("content-range: bytes ",0)==0){long long start=0,end=0,total=0;if(std::sscanf(line.c_str(),"content-range: bytes %lld-%lld/%lld",&start,&end,&total)==3&&start>=0&&end>=start&&total>0){self.range_start=start;if(self.total>=0&&self.total!=total)return 0;}}return size*count;}
void MediaReader::perform(bool head){curl_easy_setopt(curl,CURLOPT_NOBODY,head?1L:0L);for(int attempt=0;attempt<3;attempt++){buffer.clear();range_start=-1;auto rc=curl_easy_perform(curl);long status=0;curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&status);response_status=status;if(rc==CURLE_OK&&(head?status==200:(status==206||(query_ranges&&status==200))))return;if(cancelled()||rc==CURLE_PEER_FAILED_VERIFICATION||status==401||status==403||status==404||attempt==2)throw std::runtime_error("Media transfer failed");std::this_thread::sleep_for(std::chrono::milliseconds(250*(attempt+1)));}throw std::runtime_error("Media transfer failed");}
int MediaReader::read(uint8_t* data,int size){try{
    if(cancelled())return AVERROR_EXIT;if(position>=total)return AVERROR_EOF;
    if(position<buffer_at||position>=buffer_at+static_cast<int64_t>(buffer.size())){
        buffer.clear();buffer_at=position;range_start=-1;auto end=std::min(total-1,position+static_cast<int64_t>(chunk)-1);auto range=std::to_string(position)+"-"+std::to_string(end);if(query_ranges){auto ranged=set_url_parameter(uri,"range",range);curl_easy_setopt(curl,CURLOPT_URL,ranged.c_str());curl_easy_setopt(curl,CURLOPT_RANGE,nullptr);}else curl_easy_setopt(curl,CURLOPT_RANGE,range.c_str());perform(false);if(query_ranges&&response_status==200&&range_start<0)range_start=position;if(range_start!=position||static_cast<int64_t>(buffer.size())!=end-position+1)throw std::runtime_error("Invalid media range");
    }
    auto offset=static_cast<size_t>(position-buffer_at),n=std::min(static_cast<size_t>(size),buffer.size()-offset);std::memcpy(data,buffer.data()+offset,n);position+=static_cast<int64_t>(n);return static_cast<int>(n);
}catch(...){return cancelled()?AVERROR_EXIT:AVERROR(EIO);}}
int64_t MediaReader::seek(int64_t offset,int whence){if(whence==AVSEEK_SIZE)return total;whence&=~AVSEEK_FORCE;int64_t origin=whence==SEEK_SET?0:whence==SEEK_CUR?position:whence==SEEK_END?total:-1;if(origin<0||offset>total-origin||offset< -origin)return AVERROR(EINVAL);position=origin+offset;return position;}
}
