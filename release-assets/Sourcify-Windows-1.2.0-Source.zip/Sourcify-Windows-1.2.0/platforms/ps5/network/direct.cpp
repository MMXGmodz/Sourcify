#include "direct.hpp"
#include <algorithm>
#include <stdexcept>
#include <cstdlib>
namespace sourcify {
namespace {
struct Url {
    CURLU* handle=curl_url();
    explicit Url(const std::string& text){if(!handle||curl_url_set(handle,CURLUPART_URL,text.c_str(),0)!=CURLUE_OK){curl_url_cleanup(handle);handle=nullptr;}}
    ~Url(){curl_url_cleanup(handle);}
    std::string part(CURLUPart p) const {char* s=nullptr;if(!handle||curl_url_get(handle,p,&s,0)!=CURLUE_OK)return "";std::string out=s;curl_free(s);return out;}
};
bool suffix(const std::string& host,const std::string& domain){return host==domain||(host.size()>domain.size()+1&&host.compare(host.size()-domain.size(),domain.size(),domain)==0&&host[host.size()-domain.size()-1]=='.');}
std::string decoded(const std::string& value){int length=0;char* s=curl_easy_unescape(nullptr,value.c_str(),static_cast<int>(value.size()),&length);if(!s)throw std::runtime_error("URL decoding failed");std::string out(s,static_cast<size_t>(length));curl_free(s);if(out.find('\0')!=std::string::npos)throw std::runtime_error("Invalid URL parameter");return out;}
std::string encoded(const std::string& value){char* s=curl_easy_escape(nullptr,value.c_str(),static_cast<int>(value.size()));if(!s)throw std::runtime_error("URL encoding failed");std::string out=s;curl_free(s);return out;}
}
bool approved_youtube_url(const std::string& text,UrlRole role){
    if(text.empty()||text.size()>16384||std::any_of(text.begin(),text.end(),[](unsigned char c){return c<=32||c==127;}))return false;
    Url u(text);if(!u.handle||u.part(CURLUPART_SCHEME)!="https"||!u.part(CURLUPART_USER).empty()||!u.part(CURLUPART_PASSWORD).empty()||!u.part(CURLUPART_FRAGMENT).empty())return false;
    auto port=u.part(CURLUPART_PORT);if(!port.empty()&&port!="443")return false;auto host=u.part(CURLUPART_HOST);std::transform(host.begin(),host.end(),host.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});auto path=u.part(CURLUPART_PATH);
    if(role==UrlRole::Media)return suffix(host,"googlevideo.com")&&path=="/videoplayback";
    if(role==UrlRole::Cover)return suffix(host,"ytimg.com")||host=="lh3.googleusercontent.com";
    if(host!="music.youtube.com"&&host!="www.youtube.com")return false;
    if(role==UrlRole::Api)return path=="/youtubei/v1/search"||path=="/youtubei/v1/player";
    if(role==UrlRole::Page)return path=="/"||path=="/watch"||(path.rfind("/embed/",0)==0&&valid_id(path.substr(7)));
    return role==UrlRole::Script&&host=="www.youtube.com"&&path.rfind("/s/player/",0)==0&&path.size()>17&&path.substr(path.size()-8)=="/base.js"&&path.find("..") == std::string::npos&&std::all_of(path.begin(),path.end(),[](unsigned char c){return std::isalnum(c)||c=='/'||c=='_'||c=='-'||c=='.';});
}
std::string url_parameter(const std::string& url,const std::string& key){Url u(url);auto query=u.part(CURLUPART_QUERY);size_t at=0;while(at<query.size()){auto end=query.find('&',at);if(end==std::string::npos)end=query.size();auto eq=query.find('=',at);if(eq<end&&decoded(query.substr(at,eq-at))==key)return decoded(query.substr(eq+1,end-eq-1));at=end+1;}return "";}
std::string set_url_parameter(const std::string& url,const std::string& key,const std::string& value){Url u(url);if(!u.handle)throw std::runtime_error("Invalid URL");auto query=u.part(CURLUPART_QUERY);std::string out;size_t at=0;while(at<query.size()){auto end=query.find('&',at);if(end==std::string::npos)end=query.size();auto eq=query.find('=',at);auto name=decoded(query.substr(at,std::min(eq,end)-at));if(name!=key){if(!out.empty())out+='&';out+=query.substr(at,end-at);}at=end+1;}if(!out.empty())out+='&';out+=encoded(key)+'='+encoded(value);if(curl_url_set(u.handle,CURLUPART_QUERY,out.c_str(),0)!=CURLUE_OK)throw std::runtime_error("Invalid URL");return u.part(CURLUPART_URL);}
void native_test_route(CURL* curl,const std::string& uri,curl_slist*& route){
#ifndef SOURCIFY_PS5
    const char* target=std::getenv("SOURCIFY_NATIVE_TEST_PORT");if(!target)return;std::string port=target;
    if(port.empty()||port.size()>5||!std::all_of(port.begin(),port.end(),[](char c){return c>='0'&&c<='9';})||std::stoul(port)<1024||std::stoul(port)>65535)throw std::runtime_error("Invalid host test port");
    Url u(uri);auto host=u.part(CURLUPART_HOST);if(!(suffix(host,"youtube.com")||suffix(host,"googlevideo.com")||suffix(host,"ytimg.com")))return;
    route=curl_slist_append(route,(host+":443:127.0.0.1:"+port).c_str());curl_easy_setopt(curl,CURLOPT_CONNECT_TO,route);curl_easy_setopt(curl,CURLOPT_NOPROXY,"*");
#else
    (void)curl;(void)uri;(void)route;
#endif
}
DirectResponse DirectHttps::request(const std::string& url,UrlRole role,const std::string& body,const std::vector<std::string>& headers,size_t limit,Cancel operation_cancel) const{
    if(!approved_youtube_url(url,role)||body.size()>65536||limit>8*1024*1024)throw std::runtime_error("Invalid YouTube endpoint");
    for(int attempt=0;attempt<3;attempt++){
        struct Request {CURL* curl=curl_easy_init();curl_slist *headers=nullptr,*route=nullptr;~Request(){curl_slist_free_all(headers);curl_slist_free_all(route);curl_easy_cleanup(curl);}} r;
        if(!r.curl)throw std::runtime_error("YouTube HTTP unavailable");
        struct Context {std::string out;size_t limit;Cancel cancel;};Context context{"",limit,[&]{return cancelled()||(operation_cancel&&operation_cancel());}};
        curl_easy_setopt(r.curl,CURLOPT_URL,url.c_str());curl_easy_setopt(r.curl,CURLOPT_PROTOCOLS_STR,"https");curl_easy_setopt(r.curl,CURLOPT_FOLLOWLOCATION,0L);curl_easy_setopt(r.curl,CURLOPT_SSL_VERIFYPEER,1L);curl_easy_setopt(r.curl,CURLOPT_SSL_VERIFYHOST,2L);curl_easy_setopt(r.curl,CURLOPT_CAINFO,ca.c_str());curl_easy_setopt(r.curl,CURLOPT_CONNECTTIMEOUT,8L);curl_easy_setopt(r.curl,CURLOPT_TIMEOUT,25L);curl_easy_setopt(r.curl,CURLOPT_NOSIGNAL,1L);curl_easy_setopt(r.curl,CURLOPT_USERAGENT,"Mozilla/5.0 (Sourcify native client)");curl_easy_setopt(r.curl,CURLOPT_ACCEPT_ENCODING,"");
        curl_easy_setopt(r.curl,CURLOPT_WRITEFUNCTION,+[](char* b,size_t s,size_t n,void* p)->size_t{auto& c=*static_cast<Context*>(p);size_t length=s*n;if(c.cancel()||c.out.size()+length>c.limit)return 0;c.out.append(b,length);return length;});curl_easy_setopt(r.curl,CURLOPT_WRITEDATA,&context);curl_easy_setopt(r.curl,CURLOPT_NOPROGRESS,0L);curl_easy_setopt(r.curl,CURLOPT_XFERINFOFUNCTION,+[](void* p,curl_off_t,curl_off_t,curl_off_t,curl_off_t){return static_cast<Context*>(p)->cancel()?1:0;});curl_easy_setopt(r.curl,CURLOPT_XFERINFODATA,&context);
        for(const auto& h:headers){if(h.size()>4096||h.find('\r')!=std::string::npos||h.find('\n')!=std::string::npos)throw std::runtime_error("Invalid request header");r.headers=curl_slist_append(r.headers,h.c_str());}
        if(!body.empty()){r.headers=curl_slist_append(r.headers,"Content-Type: application/json");curl_easy_setopt(r.curl,CURLOPT_POSTFIELDS,body.c_str());curl_easy_setopt(r.curl,CURLOPT_POSTFIELDSIZE,static_cast<long>(body.size()));}
        curl_easy_setopt(r.curl,CURLOPT_HTTPHEADER,r.headers);native_test_route(r.curl,url,r.route);auto rc=curl_easy_perform(r.curl);long status=0;curl_easy_getinfo(r.curl,CURLINFO_RESPONSE_CODE,&status);
        if(context.cancel())throw std::runtime_error("YouTube request cancelled");
        if(rc==CURLE_OK&&status==200)return {status,std::move(context.out)};
        if(rc==CURLE_PEER_FAILED_VERIFICATION||rc==CURLE_WRITE_ERROR||status==400||status==401||status==403||status==404||(status>=300&&status<400)||attempt==2)throw std::runtime_error("YouTube request failed; check console internet");
        std::this_thread::sleep_for(std::chrono::milliseconds(250*(attempt+1)));
    }throw std::runtime_error("YouTube request failed; check console internet");
}
void DirectHttps::cover(const std::string& url,const fs::path& file) const{auto r=request(url,UrlRole::Cover,"",{},4*1024*1024);atomic_file(file,r.body);}
}
