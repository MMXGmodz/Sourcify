#pragma once
#include "cipher.hpp"
#include "media.hpp"
#include <map>
namespace sourcify {
struct NativeMedia {Track track;std::string uri,client,itag,last_modified;int64_t length=0;bool query_ranges=false;};
std::vector<Track> parse_youtube_search(const Json& response);
Track parse_youtube_metadata(const Json& response,const std::string& id);
std::string youtube_player_script_url(const std::string& html);
class NativeYouTube {
    DirectHttps https;
    CipherSolver cipher;
    std::mutex mutex;
    std::string visitor,script_url,script;
    struct Entry {NativeMedia media;std::chrono::steady_clock::time_point expires;};
    std::map<std::string,Entry> cache;
    std::string player_script(const std::string& id,DirectHttps::Cancel cancel);
    Json api(const std::string& endpoint,const Json& client,int client_id,const std::string& user_agent,Json payload,const std::string& language,DirectHttps::Cancel cancel);
public:
    NativeYouTube(const std::string& ca,const fs::path& assets,DirectHttps::Cancel cancel):https(ca,cancel),cipher(assets){}
    std::vector<Track> search(const std::string& query,const std::string& language);
    NativeMedia resolve(const std::string& id,const std::string& language,DirectHttps::Cancel cancel,bool refresh=false);
    void cover(const std::string& uri,const fs::path& file) const{https.cover(uri,file);}
    void download(const NativeMedia& media,const fs::path& file,std::atomic<bool>& cancel,const std::function<void(uint64_t,uint64_t)>& progress) const;
};
}
