#pragma once
#include "direct.hpp"
namespace sourcify {
class CipherSolver {
    fs::path assets;
public:
    explicit CipherSolver(fs::path path):assets(std::move(path)){}
    Json solve(const std::string& player,const std::string& signature,const std::string& n,DirectHttps::Cancel cancelled) const;
};
}
