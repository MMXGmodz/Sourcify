#pragma once
#include <curl/curl.h>
#include <string>
#include <vector>
#include <functional>
#include <cstdint>
namespace sourcify {
// curl owns HTTP/TLS, FFmpeg receives only bytes through AVIO. No redirect can leak auth.
class MediaReader {
    CURL* curl=nullptr;
    curl_slist* headers=nullptr;
    curl_slist* route=nullptr;
    std::string uri;
    bool query_ranges=false;
    long response_status=0;
    std::function<bool()> cancelled;
    std::vector<uint8_t> buffer;
    int64_t position=0,total=-1,buffer_at=0,range_start=-1;
    static size_t write(char*,size_t,size_t,void*);
    static size_t header(char*,size_t,size_t,void*);
    static int progress(void*,curl_off_t,curl_off_t,curl_off_t,curl_off_t);
    void perform(bool head);
public:
    MediaReader(const std::string& uri,const std::string& auth,const std::string& ca,std::function<bool()> cancelled,int64_t content_length=-1,bool query_ranges=false);
    ~MediaReader();
    int read(uint8_t* data,int size);
    int64_t seek(int64_t offset,int whence);
};
}
