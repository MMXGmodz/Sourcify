#!/usr/bin/env python3
import hashlib,json,pathlib,shutil,sys,zipfile
root=pathlib.Path(__file__).resolve().parents[2]
config=sys.argv[1] if len(sys.argv)>1 else 'release'
if config not in ('debug','release'):raise SystemExit('Invalid configuration')
build=root/'build/ps5'/config
package=build/'Sourcify-PS5'
if package.exists():shutil.rmtree(package)
(package/'app').mkdir(parents=True)
(package/'plugins').mkdir()
for name in ['sourcify.elf','sourcify-ctl.elf']:shutil.copy(build/name,package/'app'/name)
for name in ['sourcify-service.plugin','sourcify-control.plugin']:shutil.copy(build/name,package/'plugins'/name)
shutil.copytree(root/'platforms/ps5/assets',package/'app/assets')
shutil.copy(root/'platforms/ps5/homebrew.js',package/'app/homebrew.js')
shutil.copytree(root/'docs',package/'docs')
shutil.copy(root/'LICENSE',package/'LICENSE')
shutil.copy(root/'platforms/ps5/vendor/json.LICENSE',package/'json.LICENSE')
shutil.copy(root/'platforms/ps5/compat/capabilities.json',package/'capabilities.json')
shutil.copytree(root/'platforms/ps5/third_party/licenses',package/'licenses')
shutil.copy(root/'platforms/ps5/third_party/sources.json',package/'third-party-sources.json')
shutil.copy(root/'platforms/ps5/INSTALLIEREN.txt',package/'INSTALLIEREN.txt')
hashes={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in package.rglob('*') if p.is_file()}
(package/'SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n')
archive=build/f'Sourcify-PS5-{config}.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in package.rglob('*'):
  if p.is_file():z.write(p,'Sourcify-PS5/'+str(p.relative_to(package)))
print(archive)
