#!/usr/bin/env python3
"""Install pinned public SDK and libraries, keeping existing installations intact."""
import argparse,hashlib,os,pathlib,shutil,tarfile,tempfile,urllib.request,zipfile
files={
 'ps5-payload-sdk.zip':('https://github.com/ps5-payload-dev/sdk/releases/download/v0.43/ps5-payload-sdk.zip','a9cc9929f21b2b2c5d5b309f3bab4997067c45281c0622cf4838b1aecba66fcb'),
 'ps5-payload-dev.tar.gz':('https://github.com/ps5-payload-dev/pacbrew-repo/releases/download/v0.40.2/ps5-payload-dev.tar.gz','a85f65de418a8e6a898c6c3e3c870d50fff7618a200e4dd59ea9692af6ecec4d')}
def digest(file):
 h=hashlib.sha256()
 with file.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument('--destination',required=True);a.add_argument('--cache',default=str(pathlib.Path.home()/'.cache/sourcify-ps5-sdk'));args=a.parse_args()
 dest=pathlib.Path(args.destination).resolve();cache=pathlib.Path(args.cache).resolve();cache.mkdir(parents=True,exist_ok=True)
 dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists() and any(dest.iterdir()):raise SystemExit('Destination is not empty. Choose a new SDK directory.')
 for name,(url,hash_) in files.items():
  p=cache/name
  if not p.exists() or digest(p)!=hash_:
   print('Downloading',name,flush=True)
   with urllib.request.urlopen(url,timeout=120) as response,(cache/(name+'.part')).open('wb') as f:shutil.copyfileobj(response,f)
   partial=cache/(name+'.part')
   if digest(partial)!=hash_:partial.unlink();raise SystemExit('SDK checksum mismatch')
   partial.replace(p)
  print('Verified',name,flush=True)
 with tempfile.TemporaryDirectory(dir=dest.parent) as tmp:
  tmp=pathlib.Path(tmp)
  with tarfile.open(cache/'ps5-payload-dev.tar.gz') as t:t.extractall(tmp/'libs',filter='data')
  sdk=tmp/'sdk';shutil.copytree(tmp/'libs/opt/ps5-payload-sdk',sdk,symlinks=True)
  with zipfile.ZipFile(cache/'ps5-payload-sdk.zip') as z:
   for n in z.namelist():
    if pathlib.PurePosixPath(n).is_absolute() or '..' in pathlib.PurePosixPath(n).parts:raise SystemExit('Unsafe SDK archive')
   z.extractall(tmp/'base')
  base=tmp/'base/ps5-payload-sdk'
  for p in base.rglob('*'):
   relative=p.relative_to(base);target=sdk/relative
   if p.is_dir():target.mkdir(parents=True,exist_ok=True)
   else:
    if target.is_symlink():target.unlink()
    shutil.copy2(p,target)
  for p in (sdk/'bin').iterdir():
   if p.is_file():p.chmod(0o755)
  if dest.exists():dest.rmdir()
  shutil.move(str(sdk),str(dest))
 print('SDK ready:',dest);print('export PS5_PAYLOAD_SDK='+str(dest))
if __name__=='__main__':main()
