#pragma once
#include "player.hpp"
#include "protocol.hpp"
#include "youtube.hpp"
#include <set>
#include <memory>
namespace sourcify {
class Service {
    Paths paths;
    Log log;
    std::string assets;
    bool daemon;
    Library library;
    std::map<std::string,std::string> local_files;
    std::mutex mutex;
    std::string message;
    uint64_t revision=0;
    bool searching=false,online=false,control_available=false,resolving=false,requested_pause=false;
    std::atomic<uint64_t> play_request{0};
    std::atomic<bool> ipc_available{false};
    uint64_t last_probe=0;
    Json downloads=Json::object();
    std::set<std::string> cover_jobs;
    std::atomic<bool> stopping{false},cancel_download{false};
    std::unique_ptr<Player> player;
    std::shared_ptr<NativeYouTube> native;
    std::unique_ptr<Worker> api_worker,cover_worker,download_worker;
    void save_locked();
    void start_locked(double position=0);
    void error(const std::string& text,const std::string& category);
    Http connection();
    void covers(const std::vector<Track>& tracks);
    void download(const std::string& id);
    void import_local();
public:
    Service(Paths paths,std::string assets,bool daemon=false);
    ~Service();
    Json command(const Json& request);
    Json state();
    void tick();
    void set_ipc_available(bool available){ipc_available=available;}
};
}
