#ifdef SOURCIFY_SERVICE_PLUGIN
#include "service.hpp"
#else
#include "ui.hpp"
#endif
#include <curl/curl.h>
#include <signal.h>
#include <iostream>
#ifdef SOURCIFY_PS5_APP
#include "platform/ps5/system.hpp"
#endif
namespace {
volatile sig_atomic_t quit=0;
void signal_handler(int){quit=1;}
}
int main(int argc,char** argv){
    using namespace sourcify;std::string directory,assets="assets",screenshot;bool daemon=false;[[maybe_unused]] bool windowed=false;[[maybe_unused]] int frames=0;
#ifdef SOURCIFY_PS5_APP
    // The shell owns native title arguments; payload/host CLI switches are separate.
    (void)argc;(void)argv;
#else
    for(int i=1;i<argc;i++){std::string a=argv[i];if(a=="--daemon")daemon=true;else if(a=="--windowed")windowed=true;else if(i+1<argc&&a=="--data")directory=argv[++i];else if(i+1<argc&&a=="--assets")assets=argv[++i];else if(i+1<argc&&a=="--frames")frames=std::stoi(argv[++i]);else if(i+1<argc&&a=="--screenshot")screenshot=argv[++i];else {std::cerr<<"Usage: sourcify [--daemon] [--data DIR] [--assets DIR] [--windowed]\n";return 2;}}
#endif
#ifdef SOURCIFY_SERVICE_PLUGIN
    daemon=true;
#endif
    try {
        signal(SIGINT,signal_handler);signal(SIGTERM,signal_handler);signal(SIGPIPE,SIG_IGN);curl_global_init(CURL_GLOBAL_DEFAULT);
        {
            Paths paths(directory);std::unique_ptr<Service> service;std::unique_ptr<IpcServer> ipc;std::unique_ptr<std::thread> ticker;std::atomic<bool> stop_tick{false};
            struct LocalGuard{fs::path path;~LocalGuard(){unregister_local_rpc(path);}} local_guard{paths.socket()};
#ifdef SOURCIFY_PS5_APP
            hui::sys::log("[APP] storage ready: %s",paths.root.c_str());
#endif
#ifdef SOURCIFY_SERVICE_PLUGIN
            assets=(paths.root/"app/assets").string();
#elif defined(SOURCIFY_PS5_APP)
            if(assets=="assets")assets="/app0/assets";
#elif defined(SOURCIFY_PS5)
            if(assets=="assets")assets=(paths.root/"app/assets").string();
#endif
            bool available=false;try{rpc(paths.socket(),"GET_STATE");available=true;}catch(...){}
            Uint32 ui_flags=SDL_INIT_GAMECONTROLLER;
#ifndef SOURCIFY_OPENGL
            ui_flags|=SDL_INIT_VIDEO;
#endif
            if(SDL_Init((available?0:SDL_INIT_AUDIO)|SDL_INIT_TIMER|(daemon?0:ui_flags))<0)throw std::runtime_error("SDL initialization failed");
#ifdef SOURCIFY_PS5_APP
            hui::sys::log("[APP] SDL audio/input ready");
#endif
            if(!available){service=std::make_unique<Service>(paths,assets,daemon);
#ifdef SOURCIFY_OPENGL
                try{ipc=std::make_unique<IpcServer>(paths.socket(),[&](const Json& r){return service->command(r);});}catch(...){Log log(paths);log.write("IPC","Socket unavailable; embedded service uses local dispatch");}
                register_local_rpc(paths.socket(),[&](const Json& r){return service->command(r);});
#else
                ipc=std::make_unique<IpcServer>(paths.socket(),[&](const Json& r){return service->command(r);});
#endif
                service->set_ipc_available(bool(ipc));ticker=std::make_unique<std::thread>([&]{while(!stop_tick){try{service->tick();}catch(...){}std::this_thread::sleep_for(std::chrono::milliseconds(100));}});}
            struct TickGuard {std::atomic<bool>& stop;std::unique_ptr<std::thread>& thread;~TickGuard(){stop=true;if(thread&&thread->joinable())thread->join();}} guard{stop_tick,ticker};
            if(daemon){while(!quit)std::this_thread::sleep_for(std::chrono::milliseconds(200));}
#ifndef SOURCIFY_SERVICE_PLUGIN
            else {Ui ui(paths,assets,windowed);
#ifdef SOURCIFY_PS5_APP
                hui::sys::log("[APP] Sourcify UI ready");
#endif
                ui.run(frames,screenshot);}
#endif
            stop_tick=true;if(ticker)ticker->join();ipc.reset();unregister_local_rpc(paths.socket());service.reset();
        }
        SDL_Quit();curl_global_cleanup();
#ifdef SOURCIFY_PS5_APP
        hui::sys::quit();
#endif
        return 0;
    }catch(const std::exception&){std::cerr<<"Sourcify startup failed. Check writable data directory, audio/video backend, assets and sourcify.log.\n";SDL_Quit();curl_global_cleanup();return 1;}
}
