#pragma once
#include "canvas.hpp"
#include "controller.hpp"
#include "service.hpp"
namespace sourcify {
class Ui {
    Paths paths;
    Log log;
    Canvas canvas;
    Input input;
    Json state=Json::object();
    std::mutex mutex;
    Json pending;
    std::string pending_error,toast,last_message,last_audio_error;
    Uint32 toast_until=0,last_poll=0,notification_until=0;
    std::atomic<bool> polling{false};
    Worker worker;
    int page=0,focus=0,selection=0,menu_selection=0,key_selection=0;
    bool running=true,menu=false,typing=false;
    std::string filter,edit,title,last_track;
    std::function<void(std::string)> submit_text;
    std::vector<std::string> row_ids,group_names;
    std::vector<std::string> keys;
    bool de() const;
    std::string tr(const std::string& en,const std::string& german) const;
    std::string translated_message(const std::string& message) const;
    void notify(const std::string& message);
    void poll();
    void command(const std::string& cmd,Json payload=Json::object());
    void keyboard(std::string heading,std::string initial,std::function<void(std::string)> submit);
    void action(Action a);
    void render();
    void rows();
    std::string chosen() const;
    std::vector<int> settings_rows() const;
    void settings_action();
    void menu_action();
    std::vector<std::pair<int,std::string>> menu_items() const;
    void now_playing();
public:
    Ui(Paths paths,std::string assets,bool windowed=false);
    void run(int frames=0,const std::string& screenshot="");
};
}
