#include "ui.hpp"
#include <algorithm>
#include <set>
#include <cstdio>
#include <sstream>
namespace sourcify {
static constexpr SDL_Color cyan{101,228,218,255},muted{156,172,192,255},white{241,246,251,255},panel{19,29,46,255};
static const std::vector<std::string> pages={"Home","Search","Artists","Albums","Songs","Playlists","Library","Favorites","Queue","History","Downloads","Now Playing","Settings"};
static const std::vector<std::string> german={"Start","Suche","Künstler","Alben","Songs","Playlists","Bibliothek","Favoriten","Warteschlange","Verlauf","Downloads","Jetzt läuft","Einstellungen"};
static std::string clock_time(double seconds){if(!std::isfinite(seconds)||seconds<0)seconds=0;int s=static_cast<int>(seconds);char b[32];std::snprintf(b,sizeof(b),"%d:%02d",s/60,s%60);return b;}
Ui::Ui(Paths p,std::string assets,bool windowed):paths(std::move(p)),log(paths),canvas(std::move(assets),windowed){
    for(char c:std::string("abcdefghijklmnopqrstuvwxyz0123456789 .:/_-?&=,@+"))keys.emplace_back(1,c);
    for(auto k:{"ä","ö","ü","ß","SHIFT","SPACE","DEL","OK","CANCEL"})keys.emplace_back(k);
    state=rpc(paths.socket(),"GET_STATE");
    log.enable(state["settings"].value("logging",true));log.write("UI","Native TV frontend initialized");
    const auto start=state.at("settings").value("start_page",std::string("Home"));auto it=std::find(pages.begin(),pages.end(),start);if(it!=pages.end())page=static_cast<int>(it-pages.begin());
    if(state.at("settings").value("source",std::string("native"))=="companion"&&!state.at("settings").value("bridge",std::string()).empty())command("SYNC_LIBRARY");
}
bool Ui::de() const{return state.contains("settings")&&state["settings"].value("language",std::string("de"))=="de";}
std::string Ui::tr(const std::string& en,const std::string& g) const{return de()?g:en;}
std::string Ui::translated_message(const std::string& text) const{
    if(!de())return text;
    static const std::map<std::string,std::string> messages={
        {"State was corrupt; restored defaults","Gespeicherte Daten beschädigt; Standardwerte wiederhergestellt"},
        {"YouTube request failed; check console internet","YouTube nicht erreichbar; Internetverbindung der Konsole prüfen"},
        {"YouTube rejected playback; login or verification required","YouTube verlangt Anmeldung oder Verifizierung; dieser Song ist nicht verfügbar"},
        {"YouTube player signature could not be resolved","YouTube-Signatur konnte nicht aufgelöst werden"},
        {"YouTube returned no playable audio","YouTube liefert keinen abspielbaren Audiostream"},
        {"YouTube stream rejected; retry or use offline music","YouTube-Audiostream abgelehnt; erneut versuchen oder Offline-Musik wählen"},
        {"YouTube request cancelled","YouTube-Anfrage abgebrochen"},
        {"Live streams are not supported","Livestreams werden nicht unterstützt"},
        {"YouTube response invalid","Ungültige YouTube-Antwort"},
        {"Companion configuration invalid","Begleitserver-Konfiguration ungültig"},
        {"Download directory unavailable; using default","Downloadordner nicht verfügbar; Standardordner wird genutzt"},
        {"Saved song unavailable; select another track","Letzter Song nicht verfügbar; wähle einen anderen Song"},
        {"Offline file damaged; download again","Offline-Datei beschädigt; bitte erneut herunterladen"},
        {"Companion request failed; check pairing and network","Begleitserver nicht erreichbar; Kopplung und Netzwerk prüfen"},
        {"Console paired","Konsole gekoppelt"},{"Pairing failed or expired","Kopplung fehlgeschlagen oder Code abgelaufen"},
        {"Imported music is already offline","Importierte Musik ist bereits offline verfügbar"},
        {"Download complete","Download abgeschlossen"},
        {"Download cancelled; partial file retained","Download abgebrochen; Teildatei bleibt zum Fortsetzen erhalten"},
        {"Download failed; retry to resume","Download fehlgeschlagen; erneut starten zum Fortsetzen"},
        {"Import failed","Musik konnte nicht importiert werden"},
        {"Audio stream unavailable or decoder failed","Audiostream nicht verfügbar oder Decoderfehler"}
    };auto found=messages.find(text);return found==messages.end()?text:found->second;
}
void Ui::notify(const std::string& text){toast=text;toast_until=SDL_GetTicks()+6000;}
void Ui::command(const std::string& cmd,Json payload){if(!worker.submit([this,cmd,payload]{try{rpc(paths.socket(),cmd,payload);}catch(...){std::lock_guard<std::mutex> lock(mutex);pending_error="Command failed. Check service, connection and input.";}}))notify(tr("Service busy","Dienst ausgelastet"));}
void Ui::poll(){
    {std::lock_guard<std::mutex> lock(mutex);if(!pending.is_null()&&!pending.empty()){state=std::move(pending);pending=Json();const auto msg=state.value("message",std::string());if(!msg.empty()&&msg!=last_message)notify(translated_message(msg));last_message=msg;const auto audio_error=state["playback"].value("error",std::string());if(!audio_error.empty()&&audio_error!=last_audio_error)notify(translated_message(audio_error));last_audio_error=audio_error;auto id=state["index"].get<int>()>=0?state["queue"][state["index"].get<int>()].get<std::string>():"";if(id!=last_track){last_track=id;if(state["settings"].value("notifications",false))notification_until=SDL_GetTicks()+state["settings"].value("notification_seconds",3)*1000;}}if(!pending_error.empty()){notify(tr("Service or source unavailable. Check the connection.","Dienst oder Quelle nicht verfügbar. Verbindung prüfen."));pending_error.clear();}}
    if(SDL_GetTicks()-last_poll<250||polling.exchange(true))return;last_poll=SDL_GetTicks();
    if(!worker.submit([this]{try{auto s=rpc(paths.socket(),"GET_STATE");std::lock_guard<std::mutex> lock(mutex);pending=std::move(s);}catch(...){std::lock_guard<std::mutex> lock(mutex);pending_error="Service disconnected";}polling=false;}))polling=false;
}
std::string Ui::chosen() const{const int at=page==1?selection-1:selection;if(at>=0&&at<static_cast<int>(row_ids.size()))return row_ids[at];return last_track;}
void Ui::keyboard(std::string heading,std::string initial,std::function<void(std::string)> submit){title=std::move(heading);edit=std::move(initial);submit_text=std::move(submit);typing=true;key_selection=0;
#ifndef SOURCIFY_PS5
    SDL_StartTextInput();
#endif
}
void Ui::action(Action a){
    if(a==Action::None)return;
#ifdef SOURCIFY_DEBUG
    log.enable(state["settings"].value("logging",true));log.write("INPUT","Controller action="+std::to_string(static_cast<int>(a)));
#endif
    if(a==Action::Quit){running=false;return;}
    if(typing){
        if(a==Action::Back){typing=false;SDL_StopTextInput();return;}
        if(a==Action::Up)key_selection=std::max(0,key_selection-10);if(a==Action::Down)key_selection=std::min(static_cast<int>(keys.size()-1),key_selection+10);if(a==Action::Left)key_selection=std::max(0,key_selection-1);if(a==Action::Right)key_selection=std::min(static_cast<int>(keys.size()-1),key_selection+1);
        if(a==Action::Accept){auto key=keys[key_selection];if(key=="OK"){typing=false;SDL_StopTextInput();submit_text(edit);}else if(key=="CANCEL"){typing=false;SDL_StopTextInput();}else if(key=="DEL"){if(!edit.empty()){size_t at=edit.size()-1;while(at>0&&(static_cast<unsigned char>(edit[at])&0xc0)==0x80)at--;edit.resize(at);}}else if(key=="SHIFT"){for(auto& k:keys)if(k.size()==1&&std::isalpha(static_cast<unsigned char>(k[0])))k[0]=std::islower(static_cast<unsigned char>(k[0]))?static_cast<char>(std::toupper(k[0])):static_cast<char>(std::tolower(k[0]));}else if(edit.size()<200)edit+=key=="SPACE"?" ":key;}
        return;
    }
    if(a==Action::Menu){menu=!menu;menu_selection=0;log.write("OVERLAY",menu?"In-app Quick Menu opened":"In-app Quick Menu closed");return;}
    if(menu){auto items=menu_items();if(a==Action::Back){menu=false;return;}if(a==Action::Up)menu_selection=std::max(0,menu_selection-1);if(a==Action::Down)menu_selection=std::min(static_cast<int>(items.size()-1),menu_selection+1);if(a==Action::Left||a==Action::Right){if(menu_selection<static_cast<int>(items.size())&&items[menu_selection].first==3){float v=state["settings"].value("volume",.75f)+(a==Action::Left?-.05f:.05f);command("SET_VOLUME",{{"volume",std::clamp(v,0.f,1.f)}});}}if(a==Action::Accept)menu_action();return;}
    if(a==Action::PageLeft||a==Action::PageRight){page=(page+(a==Action::PageLeft?-1:1)+static_cast<int>(pages.size()))%static_cast<int>(pages.size());selection=0;filter.clear();focus=1;return;}
    if(a==Action::Back){if(!filter.empty()){filter.clear();selection=0;}else if(focus)focus=0;else page=0;return;}
    if(a==Action::SeekBack||a==Action::SeekForward){auto pos=state["playback"].value("position",0.0)+(a==Action::SeekBack?-10:10);command("SEEK",{{"position",std::max(0.0,pos)}});return;}
    if(a==Action::Favorite){auto id=chosen();if(!id.empty())command("FAVORITE",{{"id",id}});return;}
    if(a==Action::Enqueue){auto id=chosen();if(!id.empty()){command("ENQUEUE",{{"id",id}});notify(tr("Added to queue","Zur Warteschlange hinzugefügt"));}return;}
    if(a==Action::Left){focus=0;return;}if(a==Action::Right){focus=1;return;}
    if(!focus){if(a==Action::Up)page=std::max(0,page-1);if(a==Action::Down)page=std::min(static_cast<int>(pages.size()-1),page+1);selection=0;filter.clear();if(a==Action::Accept)focus=1;return;}
    int count=page==12?static_cast<int>(settings_rows().size()):page==11?7:static_cast<int>((page==2||page==3||page==5)&&filter.empty()?group_names.size():row_ids.size());
    if(page==1)count=std::max(1,count+1);
    if(a==Action::Up)selection=std::max(0,selection-1);if(a==Action::Down)selection=std::min(std::max(0,count-1),selection+1);
    if(a!=Action::Accept)return;
    if(page==12){settings_action();return;}
    if(page==11){switch(selection){case 0:command("PREVIOUS");break;case 1:command("TOGGLE_PLAYBACK");break;case 2:command("NEXT");break;case 3:command("SET_SHUFFLE",{{"shuffle",!state["settings"].value("shuffle",false)}});break;case 4:command("SET_REPEAT",{{"repeat",(state["settings"].value("repeat",0)+1)%3}});break;case 5:page=8;selection=0;break;case 6:{auto v=state["settings"].value("volume",.75f);command("SET_VOLUME",{{"volume",v>=.95f?0:v+.05f}});break;}}return;}
    if(page==1&&selection==0){keyboard(tr("Search music","Musik suchen"),"",[this](std::string q){command("SEARCH",{{"query",q}});selection=0;});return;}
    if((page==2||page==3||page==5)&&filter.empty()){if(selection<static_cast<int>(group_names.size())){filter=group_names[selection];selection=0;}return;}
    int at=page==1?selection-1:selection;
    if(at<0||at>=static_cast<int>(row_ids.size()))return;
    if(page==8)command("SELECT",{{"index",at}});else command("PLAY",{{"id",row_ids[at]}});
}
std::vector<std::pair<int,std::string>> Ui::menu_items() const{
    std::vector<std::pair<int,std::string>> items;
    if(!last_track.empty()){items.push_back({0,tr("Play / Pause","Abspielen / Pause")});items.push_back({1,tr("Previous track","Vorheriger Song")});items.push_back({2,tr("Next track","Nächster Song")});}
    items.push_back({3,tr("Volume ← / →","Lautstärke ← / →")});items.push_back({4,tr("Shuffle","Zufall")});items.push_back({5,tr("Repeat","Wiederholen")});items.push_back({6,tr("Queue","Warteschlange")});
    const auto id=chosen();if(!id.empty()){
        items.push_back({7,tr("Add selected song to playlist","Gewählten Song zur Playlist")});
        auto offline=state["offline"].get<std::vector<std::string>>();if(std::find(offline.begin(),offline.end(),id)==offline.end())items.push_back({8,tr("Download selected song","Gewählten Song herunterladen")});
    }
    if((page==8&&!row_ids.empty())||(page==5&&!filter.empty()&&!row_ids.empty()))items.push_back({9,tr("Remove selected entry","Gewählten Eintrag entfernen")});
    if(page==8&&selection>0&&!row_ids.empty())items.push_back({13,tr("Move queue entry up","Queue-Eintrag nach oben")});
    if(page==8&&selection+1<static_cast<int>(row_ids.size()))items.push_back({14,tr("Move queue entry down","Queue-Eintrag nach unten")});
    if(page==10&&!id.empty()){auto imported=state["imported"].get<std::vector<std::string>>();if(std::find(imported.begin(),imported.end(),id)==imported.end())items.push_back({10,tr("Delete offline file","Offline-Datei löschen")});}
    if(!state["active_downloads"].empty())items.push_back({16,tr("Cancel active download","Aktiven Download abbrechen")});
    items.push_back({11,page==5&&!filter.empty()?tr("Play playlist","Playlist abspielen"):(state["settings"].value("source",std::string("native"))=="native"?tr("Scan imported music","Importierte Musik einlesen"):tr("Sync library","Bibliothek laden"))});
    if(page==5&&!filter.empty())items.push_back({15,tr("Delete playlist","Playlist löschen")});
    items.push_back({12,tr("Exit Sourcify","Sourcify beenden")});return items;
}
void Ui::menu_action(){
    auto items=menu_items();if(menu_selection>=static_cast<int>(items.size()))return;
    switch(items[menu_selection].first){
        case 0:command("TOGGLE_PLAYBACK");break;case 1:command("PREVIOUS");break;case 2:command("NEXT");break;case 3:command("SET_VOLUME",{{"volume",.75}});break;
        case 4:command("SET_SHUFFLE",{{"shuffle",!state["settings"].value("shuffle",false)}});break;case 5:command("SET_REPEAT",{{"repeat",(state["settings"].value("repeat",0)+1)%3}});break;
        case 6:page=8;selection=0;focus=1;menu=false;break;
        case 7:{auto id=chosen();if(!id.empty()){menu=false;keyboard(tr("Add to playlist: enter a name","Zur Playlist: Namen eingeben"),filter,[this,id](std::string name){command("PLAYLIST_ADD",{{"name",name},{"id",id}});});}break;}
        case 8:{auto id=chosen();if(!id.empty())command("DOWNLOAD",{{"id",id}});break;}
        case 9:if(page==8&&!row_ids.empty())command("REMOVE",{{"index",selection}});else if(page==5&&!filter.empty()&&!chosen().empty())command("PLAYLIST_REMOVE",{{"name",filter},{"id",chosen()}});break;
        case 10:if(page==10&&!chosen().empty())command("DELETE_DOWNLOAD",{{"id",chosen()}});else command("CANCEL_DOWNLOAD");break;
        case 11:if(page==5&&!filter.empty())command("PLAYLIST_PLAY",{{"name",filter}});else command("SYNC_LIBRARY");break;
        case 12:running=false;break;
        case 13:command("MOVE",{{"from",selection},{"to",selection-1}});selection--;break;
        case 14:command("MOVE",{{"from",selection},{"to",selection+1}});selection++;break;
        case 15:command("PLAYLIST_DELETE",{{"name",filter}});filter.clear();selection=0;menu=false;break;
        case 16:command("CANCEL_DOWNLOAD");break;
    }
}
std::vector<int> Ui::settings_rows() const{std::vector<int> out={20};if(state["settings"].value("source",std::string("native"))=="companion")for(int i=0;i<3;i++)out.push_back(i);for(int i=3;i<20;i++)out.push_back(i);return out;}
void Ui::settings_action(){auto& s=state["settings"];auto order=settings_rows();if(selection>=static_cast<int>(order.size()))return;switch(order[selection]){
    case 20:command("SETTINGS",{{"source",s.value("source",std::string("native"))=="native"?"companion":"native"}});selection=0;break;
    case 0:keyboard(tr("Companion URL (private IPv4 HTTP or HTTPS)","Begleitserver-Adresse (private IPv4 HTTP oder HTTPS)"),s.value("bridge",std::string("http://192.168.1.2:17840")),[this](std::string address){command("SETTINGS",{{"bridge",address}});});break;
    case 1:keyboard(tr("One-time pairing code","Einmaliger Kopplungscode"),"",[this](std::string code){command("PAIR",{{"code",code}});});break;
    case 2:command("SYNC_LIBRARY");break;
    case 3:command("SETTINGS",{{"language",de()?"en":"de"}});break;
    case 4:command("SET_VOLUME",{{"volume",s.value("volume",.75f)>=.95f?0:s.value("volume",.75f)+.05f}});break;
    case 5:command("SET_SHUFFLE",{{"shuffle",!s.value("shuffle",false)}});break;
    case 6:command("SET_REPEAT",{{"repeat",(s.value("repeat",0)+1)%3}});break;
    case 7:command("SETTINGS",{{"buffer_ms",s.value("buffer_ms",2000)>=10000?500:s.value("buffer_ms",2000)+500}});break;
    case 8:command("SETTINGS",{{"resume",!s.value("resume",true)}});break;
    case 9:command("SETTINGS",{{"start_page",s.value("start_page",std::string("Home"))=="Home"?"Library":s.value("start_page",std::string())=="Library"?"Now Playing":s.value("start_page",std::string())=="Now Playing"?"Settings":"Home"}});break;
    case 10:command("SETTINGS",{{"notifications",!s.value("notifications",false)}});break;
    case 11:command("SETTINGS",{{"notification_seconds",s.value("notification_seconds",3)%5+1}});break;
    case 12:command("SETTINGS",{{"cache_mb",s.value("cache_mb",512)>=2048?128:s.value("cache_mb",512)*2}});break;
    case 13:command("CLEAR_CACHE");break;
    case 14:command("SCAN_IMPORTS");break;
    case 15:running=false;break;
    case 16:command("SETTINGS",{{"logging",!s.value("logging",true)}});break;
    case 17:command("SETTINGS",{{"debug_overlay",!s.value("debug_overlay",false)}});break;
    case 18:command("SETTINGS",{{"api_debug",!s.value("api_debug",false)}});break;
    case 19:command("SETTINGS",{{"ipc_debug",!s.value("ipc_debug",false)}});break;
}}
void Ui::rows(){
    row_ids.clear();group_names.clear();auto& tracks=state["tracks"];
    if(page==2||page==3){std::set<std::string> names;const auto field=page==2?"artist":"album";for(const auto& item:tracks.items()){auto name=item.value().value(field,std::string());if(!name.empty()){if(filter.empty())names.insert(name);else if(name==filter)row_ids.push_back(item.key());}}group_names.assign(names.begin(),names.end());}
    else if(page==5){for(const auto& item:state["playlists"].items())group_names.push_back(item.key());if(!filter.empty()&&state["playlists"].contains(filter))row_ids=state["playlists"][filter].get<std::vector<std::string>>();}
    else if(page==1)row_ids=state["results"].get<std::vector<std::string>>();
    else if(page==7)row_ids=state["favorites"].get<std::vector<std::string>>();
    else if(page==8)row_ids=state["queue"].get<std::vector<std::string>>();
    else if(page==9||page==0)row_ids=state["recent"].get<std::vector<std::string>>();
    else if(page==10)row_ids=state["offline"].get<std::vector<std::string>>();
    else for(const auto& item:tracks.items())row_ids.push_back(item.key());
    row_ids.erase(std::remove_if(row_ids.begin(),row_ids.end(),[&](const std::string& id){return !tracks.contains(id);}),row_ids.end());
}
void Ui::now_playing(){
    const auto id=last_track;if(id.empty()||!state["tracks"].contains(id)){canvas.text(tr("Your next favorite song.","Dein nächster Lieblingssong."),490,300,54,white,1320);canvas.text(tr("Choose music in Search or your Library.","Wähle Musik in der Suche oder Bibliothek."),490,385,32,muted,1320);return;}
    auto t=state["tracks"][id];canvas.cover((paths.covers/(file_key(id)+".img")).string(),475,240,470);canvas.text(t.value("title",std::string()),1010,265,46,white,800);canvas.text(t.value("artist",std::string()),1010,337,32,cyan,800);canvas.text(t.value("album",std::string()),1010,390,27,muted,800);
    const auto p=state["playback"];double position=p.value("position",0.0),duration=p.value("duration",0.0);canvas.rect(1010,490,750,8,{46,62,79,255});canvas.rect(1010,490,duration>0?static_cast<int>(std::clamp(position/duration,0.0,1.0)*750):0,8,cyan);canvas.text(clock_time(position),1010,520,26,muted);canvas.text(clock_time(duration),1680,520,26,muted);
    std::vector<std::string> controls={tr("Previous","Zurück"),p.value("paused",true)?tr("Play","Abspielen"):"Pause",tr("Next","Weiter"),tr("Shuffle","Zufall"),tr("Repeat","Wiederholen"),tr("Queue","Warteschlange"),tr("Volume","Lautstärke")};
    for(int i=0;i<7;i++){int x=i<3?1010+i*250:475+(i-3)*340,y=i<3?590:790,w=i<3?225:315;canvas.rect(x,y,w,80,panel);if(focus&&selection==i){canvas.rect(x,y,w,80,cyan,true);canvas.rect(x,y,5,80,cyan);}canvas.text(controls[i],x+20,y+25,i==5?25:28,white,w-40);}
    auto& s=state["settings"];canvas.text(tr("Shuffle: ","Zufall: ")+(s.value("shuffle",false)?tr("On","An"):tr("Off","Aus"))+"   •   "+tr("Repeat: ","Wiederholung: ")+std::to_string(s.value("repeat",0))+"   •   "+tr("Volume: ","Lautstärke: ")+std::to_string(static_cast<int>(s.value("volume",.75f)*100))+"%",475,910,28,muted,1280);
}
void Ui::render(){
    rows();canvas.clear();canvas.rect(0,0,370,1080,{13,21,36,255});canvas.cover("",50,45,68);canvas.text("SOURCIFY",140,58,32,cyan,200);canvas.text("PLAYER",140,100,19,muted,200);
    for(int i=0;i<static_cast<int>(pages.size());i++){int y=190+i*52;if(page==i){canvas.rect(30,y-4,310,47,panel);canvas.rect(30,y-4,4,47,cyan);}canvas.text(de()?german[i]:pages[i],55,y+3,27,page==i?cyan:muted,270);if(!focus&&page==i)canvas.rect(30,y-4,310,47,cyan,true);}
    canvas.text("MMXG · Vibecoded",48,984,20,muted,300);
    canvas.text(filter.empty()?(de()?german[page]:pages[page]):filter,465,55,51,white,1270);
    const bool online=state.value("online",false),native=state["settings"].value("source",std::string("native"))=="native";canvas.text(native?tr("NATIVE YOUTUBE · NO PC REQUIRED","NATIVES YOUTUBE · KEIN PC ERFORDERLICH"):online?tr("COMPANION CONNECTED","BEGLEITSERVER VERBUNDEN"):tr("OFFLINE / NOT PAIRED","OFFLINE / NICHT GEKOPPELT"),465,128,22,online?cyan:muted,1320);
    if(page==11)now_playing();
    else if(page==12){auto& s=state["settings"];std::vector<std::string> labels={tr("Companion: ","Begleitserver: ")+s.value("bridge",std::string("")),tr("Pair console with code","Konsole mit Code koppeln"),tr("Sync companion library","Begleitserver-Bibliothek laden"),tr("Language: English / Deutsch","Sprache: Deutsch / English"),tr("Volume: ","Lautstärke: ")+std::to_string(static_cast<int>(s.value("volume",.75f)*100))+"%",tr("Shuffle: ","Zufall: ")+(s.value("shuffle",false)?tr("On","An"):tr("Off","Aus")),tr("Repeat (0 off / 1 song / 2 queue): ","Wiederholen (0 aus / 1 Song / 2 Queue): ")+std::to_string(s.value("repeat",0)),tr("Buffer: ","Audiopuffer: ")+std::to_string(s.value("buffer_ms",2000))+" ms",tr("Resume on launch: ","Beim Start fortsetzen: ")+(s.value("resume",true)?tr("On","An"):tr("Off","Aus")),tr("Start page: ","Startseite: ")+([&]{auto start=s.value("start_page",std::string());auto at=std::find(pages.begin(),pages.end(),start);return de()&&at!=pages.end()?german[static_cast<size_t>(at-pages.begin())]:start;})(),tr("Song notifications (in app): ","Song-Benachrichtigungen (in App): ")+(s.value("notifications",false)?tr("On","An"):tr("Off","Aus")),tr("Notification duration: ","Benachrichtigungsdauer: ")+std::to_string(s.value("notification_seconds",3))+" s",tr("Cover cache limit: ","Cover-Cache-Limit: ")+std::to_string(s.value("cache_mb",512))+" MB",tr("Clear cover cache","Cover-Cache leeren"),tr("Scan imported audio files","Importierte Audiodateien einlesen"),tr("Exit Sourcify","Sourcify beenden"),tr("Logging: ","Protokollierung: ")+(s.value("logging",true)?tr("On","An"):tr("Off","Aus")),tr("Debug overlay (in app): ","Debug-Anzeige (in App): ")+(s.value("debug_overlay",false)?tr("On","An"):tr("Off","Aus")),"API Debug: "+std::string(s.value("api_debug",false)?tr("On","An"):tr("Off","Aus")),"IPC Debug: "+std::string(s.value("ipc_debug",false)?tr("On","An"):tr("Off","Aus")),tr("Music source: ","Musikquelle: ")+(native?tr("Native YouTube","YouTube direkt"):tr("Optional companion","Optionaler Begleitserver"))};auto order=settings_rows();selection=std::min(selection,static_cast<int>(order.size())-1);int offset=std::max(0,selection-8);for(int i=offset;i<std::min(offset+10,static_cast<int>(order.size()));i++){int y=210+(i-offset)*64;canvas.rect(455,y,1365,58,panel);if(focus&&selection==i)canvas.rect(455,y,1365,58,cyan,true);canvas.text(labels[order[i]],478,y+12,28,white,1320);}canvas.text(tr("In-game overlay unavailable • Background audio not hardware-tested","In-Game-Overlay nicht verfügbar • Hintergrundton nicht hardware-getestet"),465,910,24,muted,1360);}
    else {
        int top=210,selected=selection;
        if(page==1){canvas.rect(455,200,1365,65,panel);if(focus&&selection==0)canvas.rect(455,200,1365,65,cyan,true);canvas.text(tr("Search by song, artist or album…  X to enter","Song, Künstler oder Album suchen…  X zur Eingabe"),478,215,30,cyan,1320);top=285;selected=selection-1;}
        const bool groups=(page==2||page==3||page==5)&&filter.empty();int total=static_cast<int>(groups?group_names.size():row_ids.size()),offset=std::max(0,selected-7);
        if(total==0){canvas.text(tr("Nothing here yet.","Hier ist noch keine Musik."),480,top+65,40,white,1300);canvas.text(tr("Use Search or copy your audio files into imports/.","Nutze die Suche oder kopiere eigene Audiodateien nach imports/."),480,top+135,27,muted,1290);if(page==5)canvas.text(tr("Options → Add to playlist on a song creates your playlist.","Options → Zur Playlist bei einem Song erstellt deine Playlist."),480,top+200,27,cyan,1290);}
        for(int i=offset;i<std::min(total,offset+8);i++){int y=top+(i-offset)*80;canvas.rect(455,y,1365,74,panel);if(focus&&selected==i){canvas.rect(455,y,1365,74,cyan,true);canvas.rect(455,y,5,74,cyan);}
            if(groups){canvas.text(group_names[i],485,y+17,33,white,1260);canvas.text("›",1745,y+15,34,cyan);}
            else {auto id=row_ids[i];auto t=state["tracks"][id];canvas.cover((paths.covers/(file_key(id)+".img")).string(),472,y+7,60);canvas.text(t.value("title",std::string()),552,y+8,28,white,1090);canvas.text(t.value("artist",std::string()),552,y+43,22,muted,1090);const auto favorites=state["favorites"].get<std::vector<std::string>>();if(std::find(favorites.begin(),favorites.end(),id)!=favorites.end())canvas.text("♥",1670,y+19,29,cyan);canvas.text(clock_time(t.value("duration",0.0)),1740,y+24,23,muted,70);}
        }
        if(page==10)canvas.text(tr("Offline files: ","Offline-Dateien: ")+std::to_string(state.value("storage_bytes",uint64_t(0))/1024/1024)+" MB",465,915,24,muted,1300);
        if(state.value("searching",false))canvas.text(tr("Loading music…","Musik wird geladen…"),1470,145,24,cyan,340);
    }
    canvas.rect(370,960,1550,120,{15,24,39,255});canvas.cover(last_track.empty()?"":(paths.covers/(file_key(last_track)+".img")).string(),415,978,65);
    if(!last_track.empty()&&state["tracks"].contains(last_track)){auto t=state["tracks"][last_track];canvas.text(t.value("title",std::string()),505,980,25,white,1040);canvas.text(t.value("artist",std::string()),505,1018,22,muted,1040);}else canvas.text(tr("Choose a song to start listening","Wähle einen Song zum Abspielen"),505,997,28,muted,1030);
    canvas.text("L1/R1 · "+tr("Pages","Seiten")+"   □ · ♥   △ · Queue   Options · "+tr("Quick menu","Musikmenü"),505,1052,18,muted,1260);
    if(menu){canvas.rect(0,0,1920,1080,{0,0,0,165});canvas.rect(640,70,840,930,{23,35,54,255});canvas.text("SOURCIFY",680,105,39,cyan);auto labels=menu_items();int offset=std::max(0,menu_selection-11);for(int i=offset;i<std::min(static_cast<int>(labels.size()),offset+12);i++){int y=190+(i-offset)*57;if(menu_selection==i)canvas.rect(665,y-4,790,52,cyan,true);canvas.text(labels[i].second,685,y+5,28,white,745);}}
    if(typing){canvas.rect(0,0,1920,1080,{0,0,0,220});canvas.rect(370,140,1380,810,panel);canvas.text(title,420,175,32,cyan,1280);canvas.rect(420,250,1260,95,{9,14,25,255});canvas.text(edit+"▏",440,274,33,white,1220);for(int i=0;i<static_cast<int>(keys.size());i++){int x=420+(i%10)*126,y=385+(i/10)*76;canvas.rect(x,y,116,65,key_selection==i?cyan:SDL_Color{35,49,70,255});canvas.text(keys[i],x+12,y+19,keys[i].size()>3?19:27,key_selection==i?SDL_Color{9,14,25,255}:white,95);}}
    if(state["settings"].value("debug_overlay",false)){canvas.rect(1260,20,620,85,panel);canvas.text("IPC v1 · rev "+std::to_string(state.value("revision",uint64_t(0)))+" · underruns "+std::to_string(state["playback"].value("underruns",uint64_t(0))),1280,38,21,cyan,580);canvas.text(state["capabilities"].value("service_mode",std::string()),1280,72,18,muted,580);}
    if(SDL_GetTicks()<toast_until){canvas.rect(455,875,1365,72,{37,58,72,255});canvas.text(toast,478,895,25,white,1320);}
    if(SDL_GetTicks()<notification_until&&!last_track.empty()&&state["tracks"].contains(last_track)){canvas.rect(1280,20,610,125,panel);canvas.text("♪ Sourcify",1300,30,23,cyan);canvas.text(state["tracks"][last_track].value("title",std::string()),1300,66,26,white,570);canvas.text(state["tracks"][last_track].value("artist",std::string()),1300,105,21,muted,570);}
}
void Ui::run(int frames,const std::string& screenshot){int n=0;while(running){poll();SDL_Event e{};while(SDL_PollEvent(&e)){
        if(typing&&e.type==SDL_TEXTINPUT){if(edit.size()+std::strlen(e.text.text)<=200)edit+=e.text.text;continue;}
        if(typing&&e.type==SDL_KEYDOWN){if(e.key.keysym.sym==SDLK_RETURN){typing=false;SDL_StopTextInput();submit_text(edit);continue;}if(e.key.keysym.sym==SDLK_BACKSPACE){if(!edit.empty()){size_t at=edit.size()-1;while(at>0&&(static_cast<unsigned char>(edit[at])&0xc0)==0x80)--at;edit.erase(at);}continue;}if(e.key.keysym.sym!=SDLK_ESCAPE&&e.key.keysym.sym!=SDLK_UP&&e.key.keysym.sym!=SDLK_DOWN&&e.key.keysym.sym!=SDLK_LEFT&&e.key.keysym.sym!=SDLK_RIGHT)continue;}
        if(e.type==SDL_APP_WILLENTERBACKGROUND&&state["capabilities"].value("service_mode",std::string())=="foreground")command("PAUSE");action(input.event(e));
    }action(input.repeat());render();if(frames>0&&++n>=frames){if(!screenshot.empty())canvas.screenshot(screenshot);break;}canvas.present();SDL_Delay(16);}}
}
