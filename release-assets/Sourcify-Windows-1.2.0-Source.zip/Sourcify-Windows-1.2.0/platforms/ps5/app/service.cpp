#include "service.hpp"
#include <openssl/evp.h>
#include <algorithm>
#include <sys/statvfs.h>
#include <fstream>
#include <iomanip>
#include <set>
extern "C" {
#include <libavformat/avformat.h>
}
namespace sourcify {
namespace {
int open_local_audio(const fs::path& path,AVFormatContext** format,std::atomic<bool>* stopping){
    *format=avformat_alloc_context();if(!*format)return AVERROR(ENOMEM);
    (*format)->probesize=1024*1024;(*format)->max_analyze_duration=5*AV_TIME_BASE;
    (*format)->interrupt_callback={[](void* p){return static_cast<std::atomic<bool>*>(p)->load()?1:0;},stopping};
    AVDictionary* options=nullptr;av_dict_set(&options,"protocol_whitelist","file",0);av_dict_set(&options,"enable_drefs","0",0);av_dict_set(&options,"format_whitelist","mp3,aac,mov,ogg,flac,wav,matroska,webm",0);
    int result=avformat_open_input(format,path.c_str(),nullptr,&options);av_dict_free(&options);return result;
}
}
Service::Service(Paths p,std::string a,bool d):paths(std::move(p)),log(paths),assets(std::move(a)),daemon(d){
    bool restored=false;
    if(fs::exists(paths.config/"state.json"))try{
        auto j=parse_json(read_file(paths.config/"state.json"));library.restore(j);restored=true;
        const auto restored_files=j.value("local_files",Json::object());
        for(const auto& item:restored_files.items()){
            if(!valid_id(item.key())||!item.value().is_string())continue;auto name=item.value().get<std::string>();
            if(fs::path(name).filename()==fs::path(name)&&name!="."&&name!=".."&&name.size()<256)local_files[item.key()]=name;
        }
    }catch(...){fs::copy_file(paths.config/"state.json",paths.config/"state.corrupt.json",fs::copy_options::overwrite_existing);message="State was corrupt; restored defaults";log.write("STORAGE","Corrupt state recovered");}
    // client.json seeds first startup; persisted UI preferences win on restart.
    if(!restored&&fs::exists(paths.config/"client.json"))try{auto s=library.settings;auto seed=parse_json(read_file(paths.config/"client.json",8192));if(!seed.contains("source")&&seed.contains("bridge")&&seed["bridge"].is_string()&&!seed["bridge"].get<std::string>().empty())seed["source"]="companion";s.apply(seed);if(!s.bridge.empty()&&!safe_bridge(s.bridge))throw std::runtime_error("Invalid address");library.settings=s;}catch(...){message="Companion configuration invalid";}
    if(!library.settings.download_dir.empty()){
        try{auto custom=fs::path(library.settings.download_dir);if(!custom.is_absolute())throw std::runtime_error("Absolute download directory required");fs::create_directories(custom);paths.downloads=fs::canonical(custom);}catch(...){message="Download directory unavailable; using default";library.settings.download_dir="";}
    }
    native=std::make_shared<NativeYouTube>(library.settings.ca_file.empty()?(fs::path(assets)/"ca-bundle.crt").string():library.settings.ca_file,assets,[this]{return stopping.load();});
    log.enable(library.settings.logging);player=std::make_unique<Player>();player->volume(library.settings.volume);player->buffer(library.settings.buffer_ms);
    api_worker=std::make_unique<Worker>();cover_worker=std::make_unique<Worker>();download_worker=std::make_unique<Worker>();
    api_worker->submit([this]{try{import_local();std::lock_guard<std::mutex> lock(mutex);if(library.settings.resume&&!library.current().empty())start_locked(library.position);}catch(...){error("Saved song unavailable; select another track","AUDIO");}});
    log.write("APP",daemon?"Playback daemon started; background audio unverified":"Foreground playback started");
}
Service::~Service(){stopping=true;cancel_download=true;download_worker.reset();cover_worker.reset();api_worker.reset();{std::lock_guard<std::mutex> lock(mutex);try{library.position=player->position();save_locked();}catch(...){} }player.reset();log.write("APP","Playback stopped cleanly");}
Http Service::connection(){return Http(library.settings,(fs::path(assets)/"ca-bundle.crt").string(),&stopping);}
void Service::save_locked(){auto j=library.json(true);j["local_files"]=local_files;atomic_file(paths.config/"state.json",j.dump());revision++;}
void Service::error(const std::string& text,const std::string& category){std::lock_guard<std::mutex> lock(mutex);message=text;log.write(category,"Operation failed; recoverable");revision++;}
void Service::start_locked(double position){
    const auto id=library.current();if(id.empty())throw std::runtime_error("Select a song first");const auto key=file_key(id);message.clear();const auto generation=++play_request;resolving=false;requested_pause=false;
    std::string uri,headers,ca=(fs::path(assets)/"ca-bundle.crt").string();
    if(fs::exists(paths.downloads/(key+".audio"))){
        // Verification happens on the worker, never on the UI or audio output thread.
        player->stop();
        api_worker->submit([this,id,position,generation]{if(!verified_audio(paths,id)){error("Offline file damaged; download again","STORAGE");return;}std::lock_guard<std::mutex> lock(mutex);if(library.current()==id&&play_request==generation)player->play((paths.downloads/(file_key(id)+".audio")).string(),"",(fs::path(assets)/"ca-bundle.crt").string(),position);});return;
    }
    if(local_files.count(id)){uri=(paths.imports/local_files.at(id)).string();if(!fs::is_regular_file(uri)||fs::is_symlink(uri))throw std::runtime_error("Imported file missing");}
    else if(library.settings.source=="native"){
        const auto language=library.settings.language;auto provider=native;player->stop();resolving=true;
        if(!api_worker->submit([this,id,position,generation,language,provider]{try{
            auto media=provider->resolve(id,language,[this,generation]{return stopping.load()||play_request.load()!=generation;});
            std::lock_guard<std::mutex> lock(mutex);if(play_request!=generation||library.current()!=id)return;
            auto metadata=library.tracks.at(id);if(metadata.title.empty())metadata.title=media.track.title;if(metadata.artist.empty())metadata.artist=media.track.artist;if(metadata.thumbnail.empty())metadata.thumbnail=media.track.thumbnail;metadata.duration=media.track.duration;library.add(metadata);
            atomic_file(paths.metadata/(file_key(id)+".server.json"),metadata.json().dump());covers({metadata});player->play(media.uri,"",library.settings.ca_file.empty()?(fs::path(assets)/"ca-bundle.crt").string():library.settings.ca_file,position,media.length,media.query_ranges);if(requested_pause)player->pause(true);online=true;resolving=false;message.clear();save_locked();log.write("API","Native audio resolved TrackID="+id);
        }catch(const std::exception& e){std::lock_guard<std::mutex> lock(mutex);if(play_request==generation){resolving=false;const std::string why=e.what();static const std::set<std::string> safe={"YouTube rejected playback; login or verification required","YouTube player signature could not be resolved","YouTube returned no playable audio","Live streams are not supported","YouTube stream rejected; retry or use offline music","YouTube request cancelled"};message=safe.count(why)?why:"YouTube response invalid";revision++;log.write("API","Native stream resolution failed");}}})){resolving=false;throw std::runtime_error("API worker busy");}return;
    }
    else {auto http=connection();uri=http.base+"/v1/media/"+http.encoded(id);headers="Authorization: Bearer "+http.token+"\r\n";ca=http.ca;
        api_worker->submit([this,http,id]{try{auto j=http.get("/v1/track/"+http.encoded(id));auto track=Track::parse(j.at("track"));if(track.id!=id)throw std::runtime_error("ID mismatch");std::lock_guard<std::mutex> lock(mutex);library.add(track);atomic_file(paths.metadata/(file_key(id)+".server.json"),track.json().dump());covers({track});save_locked();}catch(...){log.write("API","Optional metadata unavailable");}});
    }
    player->play(uri,headers,ca,position);message.clear();log.write("AUDIO","Started TrackID="+id);
}
void Service::covers(const std::vector<Track>& tracks){
    for(const auto& t:tracks){if(t.thumbnail.empty())continue;const auto id=t.id,key=file_key(id);const bool direct=library.settings.source=="native";auto provider=native;const auto cover_url=t.thumbnail;std::shared_ptr<Http> http;if(!direct)http=std::make_shared<Http>(connection());
        if(fs::exists(paths.covers/(key+".img"))||cover_jobs.count(id))continue;cover_jobs.insert(id);
        if(!cover_worker->submit([this,id,key,http,provider,direct,cover_url]{try{
            auto f=paths.covers/(key+".part");if(direct)provider->cover(cover_url,f);else http->download("/v1/cover/"+http->encoded(id),f,false,4*1024*1024,stopping);fs::rename(f,paths.covers/(key+".img"));
            std::lock_guard<std::mutex> lock(mutex);if(directory_bytes(paths.covers)>static_cast<uint64_t>(library.settings.cache_mb)*1024*1024){for(const auto& e:directory_entries(paths.covers))if(e.is_regular_file()&&e.path().filename()!=key+".img")fs::remove(e.path());}cover_jobs.erase(id);revision++;
        }catch(...){std::lock_guard<std::mutex> lock(mutex);cover_jobs.erase(id);}}))cover_jobs.erase(id);
    }
}
void Service::import_local(){
    std::vector<Track> tracks;std::map<std::string,std::string> files;
    for(const auto& e:directory_entries(paths.imports)){
        if(stopping)return;if(!e.is_regular_file()||e.is_symlink())continue;auto ext=e.path().extension().string();std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
        if(ext!=".mp3"&&ext!=".m4a"&&ext!=".aac"&&ext!=".flac"&&ext!=".wav"&&ext!=".ogg"&&ext!=".opus"&&ext!=".webm")continue;
        auto name=e.path().filename().string();if(name.size()>255)continue;unsigned char digest[32];unsigned int length=0;EVP_Digest(name.data(),name.size(),digest,&length,EVP_sha256(),nullptr);std::ostringstream hex;for(int i=0;i<16;i++)hex<<std::hex<<std::setfill('0')<<std::setw(2)<<static_cast<int>(digest[i]);auto h=hex.str();
        Track t;t.id="local:"+h.substr(0,8)+"-"+h.substr(8,4)+"-"+h.substr(12,4)+"-"+h.substr(16,4)+"-"+h.substr(20,12);t.title=e.path().stem().string().substr(0,300);t.artist="Local music";t.kind="local";
        AVFormatContext* format=nullptr;if(open_local_audio(e.path(),&format,&stopping)>=0){if(avformat_find_stream_info(format,nullptr)>=0){t.duration=format->duration>0?static_cast<double>(format->duration)/AV_TIME_BASE:0;for(auto key:{"title","artist","album"}){auto tag=av_dict_get(format->metadata,key,nullptr,0);if(tag){auto text=std::string(tag->value).substr(0,key==std::string("title")?300:200);if(key==std::string("title"))t.title=text;else if(key==std::string("artist"))t.artist=text;else t.album=text;}}}avformat_close_input(&format);}
        tracks.push_back(t);files[t.id]=name;
    }
    std::lock_guard<std::mutex> lock(mutex);for(const auto& t:tracks)library.add(t);local_files=std::move(files);save_locked();
}
void Service::download(const std::string& id){
    if(!library.tracks.count(id))throw std::runtime_error("Track missing");if(local_files.count(id)){message="Imported music is already offline";return;}
    if(!downloads.empty())throw std::runtime_error("One download at a time");const bool direct=library.settings.source=="native";auto provider=native;const auto language=library.settings.language;std::shared_ptr<Http> http;if(!direct)http=std::make_shared<Http>(connection());const auto track=library.tracks.at(id);cancel_download=false;downloads[id]={{"bytes",0},{"total",0},{"status","running"}};
    if(!download_worker->submit([this,id,http,track,direct,provider,language]{try{
        const auto key=file_key(id);const auto part=paths.downloads/(key+".part"),final=paths.downloads/(key+".audio");
        #ifndef SOURCIFY_PS5_APP
        struct statvfs disk{};if(statvfs(paths.downloads.c_str(),&disk)||static_cast<uint64_t>(disk.f_bavail)*disk.f_frsize<32*1024*1024)throw std::runtime_error("Storage full");
#endif
        // A native title cannot rely on statvfs/fstatfs. Bounded writes report actual quota/ENOSPC errors.
        
        auto progress=[this,id](uint64_t n,uint64_t total){std::lock_guard<std::mutex> lock(mutex);downloads[id]["bytes"]=n;downloads[id]["total"]=total;};if(direct){auto media=provider->resolve(id,language,[this]{return stopping.load()||cancel_download.load();});provider->download(media,part,cancel_download,progress);}else http->download("/v1/media/"+http->encoded(id),part,true,512*1024*1024,cancel_download,progress);
        AVFormatContext* format=nullptr;if(open_local_audio(part,&format,&stopping)<0)throw std::runtime_error("Invalid download");int rc=avformat_find_stream_info(format,nullptr);int stream=rc>=0?av_find_best_stream(format,AVMEDIA_TYPE_AUDIO,-1,-1,nullptr,0):-1;avformat_close_input(&format);if(stream<0)throw std::runtime_error("No audio in download");
        auto checksum=sha256(part);auto bytes=fs::file_size(part);Json metadata={{"track",track.json()},{"bytes",bytes},{"sha256",checksum},{"schema",1}};fs::rename(part,final);fs::remove(part.string()+".json");atomic_file(paths.metadata/(key+".json"),metadata.dump());
        {std::lock_guard<std::mutex> lock(mutex);downloads.erase(id);message="Download complete";revision++;}log.write("STORAGE","Verified download TrackID="+id);
    }catch(...){std::lock_guard<std::mutex> lock(mutex);downloads.erase(id);message=cancel_download?"Download cancelled; partial file retained":"Download failed; retry to resume";revision++;log.write("NETWORK","Download interrupted");}})){downloads.erase(id);throw std::runtime_error("Download worker busy");}
}
Json Service::state(){std::error_code probe_error;const bool etahen_files=fs::exists("/data/etaHEN/config.ini",probe_error);std::lock_guard<std::mutex> lock(mutex);auto j=library.json();j["playback"]=player->state();if(resolving){j["playback"]["loading"]=true;j["playback"]["paused"]=requested_pause;}j["message"]=message;j["revision"]=revision;j["searching"]=searching;j["online"]=online;j["active_downloads"]=downloads;Json offline=Json::array();for(const auto& [id,t]:library.tracks)if(local_files.count(id)||fs::exists(paths.downloads/(file_key(id)+".audio")))offline.push_back(id);j["offline"]=offline;Json imported=Json::array();for(const auto& item:local_files)imported.push_back(item.first);j["imported"]=imported;j["storage_bytes"]=directory_bytes(paths.downloads);j["capabilities"]={{"background_playback",false},{"playback_service",true},{"ipc_available",ipc_available.load()},{"service_mode",daemon?"etaHEN daemon (hardware test pending)":"foreground"},{"ingame_overlay",false},{"global_shortcut",false},{"control_plugin",control_available},{"quick_menu",true},{"native_music",true},{"companion_required",library.settings.source!="native"},{"etaHEN_files",etahen_files}};return j;}
void Service::tick(){
    auto now=static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count());
    if(now-last_probe>3000){last_probe=now;bool available=false;try{auto status=rpc(paths.root/"control.sock","PLUGIN_STATUS");available=status.value("plugin",std::string())=="Sourcify Control";}catch(...){}std::lock_guard<std::mutex> lock(mutex);control_available=available;}
    if(player->take_finished()){std::lock_guard<std::mutex> lock(mutex);if(library.next(1,true)){start_locked();save_locked();}}
}
Json Service::command(const Json& request){
    validate_request(request);const auto cmd=request.at("command").get<std::string>();const auto p=request.at("payload");
    if(cmd=="GET_STATE"||cmd=="GET_QUEUE"){bool debug;{std::lock_guard<std::mutex> lock(mutex);debug=library.settings.ipc_debug;}if(debug)log.write("IPC","Read playback state");return state();}
    std::unique_lock<std::mutex> lock(mutex);log.write("IPC","Command "+cmd);
    const auto id=p.value("id",std::string());
    if(cmd=="PLAY"){double position=p.value("position",0.0);if(!std::isfinite(position)||position<0||position>86400)throw std::runtime_error("Invalid position");if(!id.empty())library.play(id);library.position=position;start_locked(position);}
    else if(cmd=="PAUSE"){requested_pause=true;player->pause(true);}
    else if(cmd=="RESUME"){requested_pause=false;player->pause(false);}
    else if(cmd=="TOGGLE_PLAYBACK"){if(resolving){requested_pause=!requested_pause;save_locked();return {{"accepted",true}};}auto s=player->state();if(s["duration"].get<double>()==0&&!s["loading"].get<bool>())start_locked(library.position);else player->pause(!s["paused"].get<bool>());}
    else if(cmd=="STOP"){play_request++;resolving=false;player->stop();}
    else if(cmd=="NEXT"||cmd=="PREVIOUS"){if(cmd=="PREVIOUS"&&player->position()>3)player->seek(0);else if(library.next(cmd=="NEXT"?1:-1))start_locked();else player->pause(true);}
    else if(cmd=="SEEK"){auto value=p.at("position").get<double>();if(!std::isfinite(value)||value<0||value>86400)throw std::runtime_error("Invalid seek");if(resolving){const auto paused=requested_pause;library.position=value;start_locked(value);requested_pause=paused;}else player->seek(value);}
    else if(cmd=="SET_VOLUME"||cmd=="SET_REPEAT"||cmd=="SET_SHUFFLE"||cmd=="SETTINGS"){
        if(cmd!="SETTINGS"){const std::string key=cmd=="SET_VOLUME"?"volume":cmd=="SET_REPEAT"?"repeat":"shuffle";if(p.size()!=1||!p.contains(key))throw std::runtime_error("Invalid control payload");}
        auto settings=library.settings;settings.apply(p);if(!settings.bridge.empty()&&!safe_bridge(settings.bridge))throw std::runtime_error("Invalid companion address");if(settings.download_dir!=library.settings.download_dir)throw std::runtime_error("Set download directory in client.json before startup");if(settings.source!=library.settings.source){play_request++;resolving=false;player->stop();online=false;message.clear();}library.settings=settings;log.enable(settings.logging);player->volume(settings.volume);player->buffer(settings.buffer_ms);
    }
    else if(cmd=="ENQUEUE"){if(!library.tracks.count(id)||library.queue.size()>=500)throw std::runtime_error("Queue limit or missing track");library.queue.push_back(id);if(library.index<0)library.index=0;}
    else if(cmd=="SELECT"){auto at=p.at("index").get<int>();if(at<0||at>=static_cast<int>(library.queue.size()))throw std::runtime_error("Invalid queue index");library.index=at;library.position=0;start_locked();}
    else if(cmd=="REMOVE"){auto at=p.at("index").get<size_t>();bool current=static_cast<int>(at)==library.index;library.remove(at);if(current){play_request++;resolving=false;player->stop();if(!library.current().empty())start_locked();}}
    else if(cmd=="MOVE")library.move(p.at("from").get<size_t>(),p.at("to").get<size_t>());
    else if(cmd=="CLEAR_QUEUE"){play_request++;resolving=false;player->stop();library.queue.clear();library.index=-1;}
    else if(cmd=="FAVORITE")library.favorite(id);
    else if(cmd=="PLAYLIST_ADD"||cmd=="PLAYLIST_REMOVE")library.playlist(p.at("name").get<std::string>(),id,cmd=="PLAYLIST_REMOVE");
    else if(cmd=="PLAYLIST_DELETE")library.playlists.erase(p.at("name").get<std::string>());
    else if(cmd=="PLAYLIST_PLAY"){auto name=p.at("name").get<std::string>();if(!library.playlists.count(name)||library.playlists.at(name).empty())throw std::runtime_error("Empty playlist");library.queue=library.playlists.at(name);library.index=0;library.active_playlist=name;start_locked();}
    else if(cmd=="SEARCH"||cmd=="SYNC_LIBRARY"){
        if(searching)throw std::runtime_error("Request in progress");const bool direct=library.settings.source=="native";const auto source=library.settings.source,language=library.settings.language;auto provider=native;
        if(direct&&cmd=="SYNC_LIBRARY"){if(!api_worker->submit([this]{try{import_local();}catch(...){error("Import failed","STORAGE");}}))throw std::runtime_error("API worker busy");return {{"accepted",true}};}
        std::shared_ptr<Http> http;if(!direct)http=std::make_shared<Http>(connection());std::string query=p.value("query",std::string());if(cmd=="SEARCH"&&(query.empty()||query.size()>200))throw std::runtime_error("Invalid query");searching=true;message.clear();if(library.settings.api_debug)log.write("API","Queued "+cmd);
        if(!api_worker->submit([this,http,provider,direct,source,language,query,cmd]{try{
            std::vector<Track> tracks;if(direct)tracks=provider->search(query,language);else {auto j=http->get(cmd=="SEARCH"?"/v1/search?q="+http->encoded(query):"/v1/library");const auto list=j.at("tracks");if(!list.is_array()||list.size()>5000)throw std::runtime_error("Invalid response");for(const auto& t:list)tracks.push_back(Track::parse(t));}
            std::lock_guard<std::mutex> guard(mutex);searching=false;if(library.settings.source!=source)return;if(cmd=="SEARCH")library.results.clear();for(const auto& t:tracks){library.add(t);if(cmd=="SEARCH")library.results.push_back(t.id);}online=true;covers(tracks);save_locked();
        }catch(...){std::lock_guard<std::mutex> guard(mutex);searching=false;online=false;message=direct?"YouTube request failed; check console internet":"Companion request failed; check pairing and network";revision++;log.write("API","Request failed");}})){searching=false;throw std::runtime_error("API worker busy");}
    }
    else if(cmd=="PAIR"){
        if(library.settings.source!="companion")throw std::runtime_error("Pairing only applies to optional companion mode");auto http=connection();auto code=p.at("code").get<std::string>();api_worker->submit([this,http,code]{try{auto j=http.pair(code);std::lock_guard<std::mutex> guard(mutex);library.settings.apply(Json{{"token",j.at("token")}});save_locked();message="Console paired";online=true;}catch(...){error("Pairing failed or expired","NETWORK");}});
    }
    else if(cmd=="DOWNLOAD")download(id);
    else if(cmd=="CANCEL_DOWNLOAD")cancel_download=true;
    else if(cmd=="DELETE_DOWNLOAD"){if(!valid_id(id)||downloads.contains(id))throw std::runtime_error("Invalid or active download");if(library.current()==id){play_request++;resolving=false;player->stop();}const auto key=file_key(id);fs::remove(paths.downloads/(key+".audio"));fs::remove(paths.downloads/(key+".part"));fs::remove(paths.downloads/(key+".part.json"));fs::remove(paths.metadata/(key+".json"));}
    else if(cmd=="CLEAR_CACHE"){if(!cover_jobs.empty())throw std::runtime_error("Cover downloads active");clear_covers(paths);}
    else if(cmd=="SCAN_IMPORTS")api_worker->submit([this]{try{import_local();}catch(...){error("Import failed","STORAGE");}});
    else throw std::runtime_error("Unknown command");
    if(cmd!="PLAY"&&cmd!="SELECT"&&cmd!="NEXT"&&cmd!="PREVIOUS"&&cmd!="PLAYLIST_PLAY")library.position=player->position();save_locked();lock.unlock();return {{"accepted",true}};
}
}
