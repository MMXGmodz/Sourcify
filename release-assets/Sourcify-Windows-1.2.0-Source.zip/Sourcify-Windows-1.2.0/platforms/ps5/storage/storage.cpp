#include "storage.hpp"
#include "dirents.hpp"
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/evp.h>
#include <fstream>
#include <array>
#include <chrono>
#include <cstdio>
#include <stdexcept>
#ifdef SOURCIFY_PS5_APP
#include <dirent.h>
#include <cstring>
#include <cerrno>
#endif
namespace sourcify {
Paths::Paths(const std::string& requested) {
    std::vector<fs::path> choices;
    if(!requested.empty())choices.push_back(requested);
    else if(const char* env=std::getenv("SOURCIFY_DATA"))choices.push_back(env);
    else {
#ifdef SOURCIFY_PS5_APP
        choices={"/download0/sourcify"};
#elif defined(SOURCIFY_PS5)
        choices={"/data/sourcify","/mnt/usb0/sourcify","/mnt/usb1/sourcify"};
#else
        const char* user=std::getenv("HOME");choices={fs::path(user?user:".")/".sourcify-native"};
#endif
    }
    for(const auto& p:choices)try {
        fs::create_directories(p);const auto test=p/".write-test";atomic_file(test,"ok");fs::remove(test);root=fs::canonical(p);break;
    } catch(const std::exception&){}
    if(root.empty())throw std::runtime_error("No writable Sourcify directory. Set SOURCIFY_DATA.");
    chmod(root.c_str(),0700);config=root/"config";covers=root/"cache/covers";audio=root/"cache/audio";metadata=root/"cache/metadata";downloads=root/"downloads";imports=root/"imports";logs=root/"logs";
    for(const auto& p:{root/"cache",config,covers,audio,metadata,downloads,imports,logs}){if(fs::is_symlink(p))throw std::runtime_error("Unsafe storage directory");fs::create_directories(p);chmod(p.c_str(),0700);}
}
std::string read_file(const fs::path& file,size_t limit) {
    int fd=open(file.c_str(),O_RDONLY|O_NOFOLLOW);if(fd<0)throw std::runtime_error("File unavailable");struct stat st{};
    if(fstat(fd,&st)||!S_ISREG(st.st_mode)||st.st_size<0||static_cast<uint64_t>(st.st_size)>limit){close(fd);throw std::runtime_error("Invalid file");}
    std::string out(static_cast<size_t>(st.st_size),'\0');size_t at=0;while(at<out.size()){ssize_t n=read(fd,&out[at],out.size()-at);if(n<=0){close(fd);throw std::runtime_error("File read failed");}at+=static_cast<size_t>(n);}close(fd);return out;
}
void atomic_file(const fs::path& file,const std::string& text) {
    auto temp=file.string()+".tmp";int fd=open(temp.c_str(),O_WRONLY|O_CREAT|O_TRUNC|O_NOFOLLOW,0600);if(fd<0)throw std::runtime_error("Storage unavailable");size_t at=0;
    while(at<text.size()){auto n=write(fd,text.data()+at,text.size()-at);if(n<=0){close(fd);unlink(temp.c_str());throw std::runtime_error("Storage full");}at+=static_cast<size_t>(n);}
    bool ok=fsync(fd)==0;close(fd);if(!ok||rename(temp.c_str(),file.c_str())){unlink(temp.c_str());throw std::runtime_error("Save failed");}chmod(file.c_str(),0600);
}
std::string sha256(const fs::path& file) {
    auto* ctx=EVP_MD_CTX_new();if(!ctx)throw std::runtime_error("Hash initialization failed");std::ifstream in(file,std::ios::binary);
    if(!in){EVP_MD_CTX_free(ctx);throw std::runtime_error("Download missing");}
    EVP_DigestInit_ex(ctx,EVP_sha256(),nullptr);std::array<char,65536> buf{};while(in){in.read(buf.data(),buf.size());if(in.gcount()>0)EVP_DigestUpdate(ctx,buf.data(),static_cast<size_t>(in.gcount()));}
    if(!in.eof()){EVP_MD_CTX_free(ctx);throw std::runtime_error("Hash read failed");}unsigned char digest[32];unsigned int n=0;EVP_DigestFinal_ex(ctx,digest,&n);EVP_MD_CTX_free(ctx);std::string out;char hex[3];for(unsigned int i=0;i<n;i++){std::snprintf(hex,sizeof(hex),"%02x",digest[i]);out+=hex;}return out;
}
std::vector<fs::directory_entry> directory_entries(const fs::path& directory){
    std::vector<fs::directory_entry> out;
#ifdef SOURCIFY_PS5_APP
    // Native titles cannot use opendir's fstatfs import. Read FreeBSD records directly.
    int fd=open(directory.c_str(),O_RDONLY|O_DIRECTORY|O_NOFOLLOW);
    if(fd<0)throw std::runtime_error("Directory unavailable");
    struct Guard{int fd;~Guard(){close(fd);}} guard{fd};
    struct stat st{};fstat(fd,&st);size_t capacity=std::max<size_t>(65536,st.st_blksize>0?st.st_blksize:0);
    if(capacity>1024*1024)throw std::runtime_error("Directory block exceeds limit");
    std::vector<char> bytes(capacity);
    for(;;){int n=getdents(fd,bytes.data(),static_cast<int>(bytes.size()));if(n<0){if(errno==EINTR)continue;throw std::runtime_error("Directory read failed");}if(!n)break;
        static_assert(offsetof(struct dirent,d_name)==8,"Unsupported native directory ABI");
        for(const auto& filename:parse_directory_names(std::string_view(bytes.data(),size_t(n))))out.emplace_back(directory/filename);
        if(out.size()>100000)throw std::runtime_error("Directory entry limit exceeded");
    }
#else
    for(const auto& entry:fs::directory_iterator(directory))out.push_back(entry);
#endif
    return out;
}
uint64_t directory_bytes(const fs::path& directory){uint64_t n=0;for(const auto& e:directory_entries(directory)){if(e.is_regular_file()&&!e.is_symlink())n+=e.file_size();}return n;}
bool verified_audio(const Paths& p,const std::string& id){try{const auto key=file_key(id);auto j=parse_json(read_file(p.metadata/(key+".json"),4096));const auto f=p.downloads/(key+".audio");return fs::is_regular_file(f)&&!fs::is_symlink(f)&&j.at("bytes").get<uint64_t>()==fs::file_size(f)&&j.at("sha256").get<std::string>()==sha256(f);}catch(...){return false;}}
void clear_covers(const Paths& p){for(const auto& e:directory_entries(p.covers))if(e.is_regular_file()&&!e.is_symlink())fs::remove(e.path());}
void Log::write(const std::string& category,const std::string& event){if(!enabled)return;std::lock_guard<std::mutex> lock(mutex);try{if(fs::exists(file)&&fs::file_size(file)>2*1024*1024){fs::remove(file.string()+".1");fs::rename(file,file.string()+".1");}std::ofstream out(file,std::ios::app);auto now=std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());out<<now<<" ["<<category<<"] "<<event<<'\n';chmod(file.c_str(),0600);}catch(...){} }
}
