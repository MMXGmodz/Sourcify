#pragma once
#include "model.hpp"
#include <mutex>
#include <filesystem>
#include <atomic>
namespace sourcify {
namespace fs=std::filesystem;
struct Paths {
    fs::path root,config,covers,audio,metadata,downloads,imports,logs;
    explicit Paths(const std::string& requested="");
    fs::path socket() const{return root/"playback.sock";}
};
std::string read_file(const fs::path& file,size_t limit=4*1024*1024);
void atomic_file(const fs::path& file,const std::string& text);
std::string sha256(const fs::path& file);
uint64_t directory_bytes(const fs::path& directory);
std::vector<fs::directory_entry> directory_entries(const fs::path& directory);
bool verified_audio(const Paths& paths,const std::string& id);
void clear_covers(const Paths& paths);
class Log {
    fs::path file;
    std::mutex mutex;
    std::atomic<bool> enabled{true};
public:
    explicit Log(const Paths& p):file(p.logs/"sourcify.log"){}
    void enable(bool value){enabled=value;}
    void write(const std::string& category,const std::string& event);
};
}
