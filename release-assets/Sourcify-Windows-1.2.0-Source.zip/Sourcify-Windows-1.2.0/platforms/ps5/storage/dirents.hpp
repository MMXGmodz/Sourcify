// Sourcify - bounds-checked FreeBSD directory records (public SDK sys/dirent.h).
// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <string_view>
#include <string>
#include <vector>
#include <stdexcept>
#include <cstdint>
namespace sourcify {
inline std::vector<std::string> parse_directory_names(std::string_view bytes){
    std::vector<std::string> names;size_t at=0;
    while(at<bytes.size()){
        if(bytes.size()-at<8)throw std::runtime_error("Invalid directory header");
        const auto* p=reinterpret_cast<const uint8_t*>(bytes.data()+at);
        const uint32_t inode=uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);
        const size_t record=size_t(p[4])|(size_t(p[5])<<8),length=p[7];
        if(record<12||record%4||record>bytes.size()-at||length+9>record)throw std::runtime_error("Invalid directory record");
        auto name=bytes.substr(at+8,length);
        if(bytes[at+8+length]!='\0'||name.find('\0')!=name.npos||name.find('/')!=name.npos)throw std::runtime_error("Invalid directory name");
        if(inode&&!name.empty()&&name!="."&&name!="..")names.emplace_back(name);
        at+=record;
    }
    return names;
}
}
